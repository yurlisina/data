<?php
if(!defined("IN_MYBB")) die("Direct initialization of this file is not allowed.");

$plugins->add_hook("index_start", "bf_shoutbox_index");
$plugins->add_hook("xmlhttp", "bf_shoutbox_xmlhttp");
$plugins->add_hook("newthread_do_newthread_end", "bf_shoutbox_new_thread");

function bf_shoutbox_info()
{
    return array(
        "name"          => "BF Shoutbox",
        "description"   => "Premium Discord-style shoutbox.",
        "website"       => "",
        "author"        => "BF",
        "version"       => "2.0",
        "compatibility" => "18*"
    );
}

function bf_shoutbox_activate() {}
function bf_shoutbox_deactivate() {}

function bf_shoutbox_new_thread()
{
    global $mybb, $db, $tid, $thread_info;
    if(empty($tid) && !empty($thread_info['tid'])) $tid = (int)$thread_info['tid'];
    if(empty($tid)) return;

    $uid = (int)$mybb->user['uid'];
    if($uid <= 0) return;

    $thread = $db->fetch_array($db->simple_select('threads', 'subject, fid', "tid={$tid}", array('limit' => 1)));
    if(!$thread) return;

    $forum = $db->fetch_array($db->simple_select('forums', 'name', "fid=" . (int)$thread['fid'], array('limit' => 1)));
    $forum_name = $forum ? $forum['name'] : 'Unknown';

    $subject = my_substr($thread['subject'], 0, 60);
    if(my_strlen($thread['subject']) > 60) $subject .= '...';

    $msg = 'created a new thread: ' . $subject . ' in ' . $forum_name;

    $prefix = $db->table_prefix;
    if(!$db->table_exists('shoutbox')) return;

    $db->insert_query('shoutbox', array(
        'uid' => $uid,
        'username' => $db->escape_string($mybb->user['username']),
        'message' => $db->escape_string($msg),
        'dateline' => TIME_NOW,
    ));
}

function bf_shoutbox_get_color($ug)
{
    $ug = (int)$ug;
    if($ug === 4) return '#ef4444';
    if($ug === 3) return '#f97316';
    if($ug === 6) return '#22c55e';
    if($ug === 8) return '#eab308';
    if($ug === 9) return '#f43f5e';
    if($ug === 10) return '#a855f7';
    return '#94a3b8';
}

function bf_shoutbox_get_badge($ug)
{
    $ug = (int)$ug;
    if($ug === 4) return '<span class="bf-sb-badge bf-sb-badge-owner" title="Owner">OWNER</span>';
    if($ug === 3) return '<span class="bf-sb-badge bf-sb-badge-smod" title="Super Mod">SMOD</span>';
    if($ug === 6) return '<span class="bf-sb-badge bf-sb-badge-mod" title="Moderator">MOD</span>';
    if($ug === 8) return '<span class="bf-sb-badge bf-sb-badge-vip" title="VIP">VIP</span>';
    if($ug === 9) return '<span class="bf-sb-badge bf-sb-badge-prem" title="Premium">PREM</span>';
    if($ug === 10) return '<span class="bf-sb-badge bf-sb-badge-legend" title="Legendary">LEG</span>';
    return '';
}

function bf_shoutbox_parse_mentions($message)
{
    return preg_replace_callback('/@([a-zA-Z0-9_\-]+)/', function($m) {
        global $db;
        $safe = $db->escape_string($m[1]);
        $q = $db->simple_select('users', 'uid, username', "username='{$safe}'", array('limit' => 1));
        if($u = $db->fetch_array($q)) {
            return '<a href="member.php?action=profile&amp;uid=' . (int)$u['uid'] . '" class="bf-mention">@' . htmlspecialchars_uni($u['username']) . '</a>';
        }
        return htmlspecialchars_uni($m[0]);
    }, $message);
}

function bf_shoutbox_xmlhttp()
{
    global $mybb, $db;

    $action = $mybb->get_input('action');

    if($action === 'bf_shout_refresh')
    {
        if($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

        $last_id = $mybb->get_input('last_id', MyBB::INPUT_INT);
        $prefix = $db->table_prefix;

        $where = $last_id > 0 ? "s.id > {$last_id}" : "1=1";

        $query = $db->query("
            SELECT s.id, s.uid, s.username, s.message, s.dateline, u.usergroup, u.avatar
            FROM {$prefix}shoutbox s
            LEFT JOIN {$prefix}users u ON u.uid = s.uid
            WHERE {$where}
            ORDER BY s.dateline DESC
            LIMIT 30
        ");

        $shouts = array();
        while($row = $db->fetch_array($query))
        {
            $msg = htmlspecialchars_uni($row['message']);
            $msg = bf_shoutbox_parse_mentions($msg);

            $ug = (int)($row['usergroup'] ?? 2);
            $shouts[] = array(
                'id' => (int)$row['id'],
                'username' => htmlspecialchars_uni($row['username']),
                'message' => $msg,
                'color' => bf_shoutbox_get_color($ug),
                'badge' => bf_shoutbox_get_badge($ug),
                'uid' => (int)$row['uid'],
                'time' => my_date('g:i A', $row['dateline']),
                'avatar' => !empty($row['avatar']) ? htmlspecialchars_uni($row['avatar']) : '',
            );
        }

        $shouts = array_reverse($shouts);

        header('Content-Type: application/json');
        echo json_encode(array('shouts' => $shouts));
        exit;
    }

    if($action === 'bf_shout_clear')
    {
        if($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }
        $ug = (int)$mybb->user['usergroup'];
        if($mybb->user['uid'] <= 0 || !in_array($ug, array(3, 4)))
        {
            http_response_code(403);
            header('Content-Type: application/json');
            echo json_encode(array('error' => 'Permission denied.'));
            exit;
        }

        verify_post_check($mybb->get_input('my_post_key'));
        $db->query("DELETE FROM {$db->table_prefix}shoutbox");

        header('Content-Type: application/json');
        echo json_encode(array('success' => true, 'cleared' => true));
        exit;
    }

    if($action === 'bf_shout_delete')
    {
        if($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }
        $ug = (int)$mybb->user['usergroup'];
        if($mybb->user['uid'] <= 0 || !in_array($ug, array(3, 4, 6)))
        {
            http_response_code(403);
            header('Content-Type: application/json');
            echo json_encode(array('error' => 'Permission denied.'));
            exit;
        }

        verify_post_check($mybb->get_input('my_post_key'));
        $sid = $mybb->get_input('shout_id', MyBB::INPUT_INT);
        if($sid > 0) $db->delete_query('shoutbox', "id={$sid}");

        header('Content-Type: application/json');
        echo json_encode(array('success' => true));
        exit;
    }

    if($action === 'bf_shout_edit')
    {
        if($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }
        $ug = (int)$mybb->user['usergroup'];
        if($mybb->user['uid'] <= 0 || !in_array($ug, array(3, 4, 6)))
        {
            http_response_code(403);
            header('Content-Type: application/json');
            echo json_encode(array('error' => 'Permission denied.'));
            exit;
        }

        verify_post_check($mybb->get_input('my_post_key'));
        $sid = $mybb->get_input('shout_id', MyBB::INPUT_INT);
        $new_msg = trim($mybb->get_input('new_message'));

        if($sid <= 0 || empty($new_msg) || my_strlen($new_msg) > 300)
        {
            header('Content-Type: application/json');
            echo json_encode(array('error' => 'Invalid input.'));
            exit;
        }

        $db->update_query('shoutbox', array('message' => $db->escape_string($new_msg)), "id={$sid}");

        header('Content-Type: application/json');
        echo json_encode(array('success' => true));
        exit;
    }

    if($action !== 'bf_shout') return;

    if($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

    if($mybb->user['uid'] <= 0)
    {
        xmlhttp_error('You must be logged in.');
        return;
    }

    if(in_array((int)$mybb->user['usergroup'], array(5, 7)))
    {
        xmlhttp_error('You do not have permission to use the shoutbox.');
        return;
    }

    verify_post_check($mybb->get_input('my_post_key'));

    $message = trim($mybb->get_input('shout_message'));
    if(empty($message))
    {
        xmlhttp_error('Message cannot be empty.');
        return;
    }

    if(my_strlen($message) > 300)
    {
        xmlhttp_error('Message too long (max 300 characters).');
        return;
    }

    $prefix = $db->table_prefix;
    $uid = (int)$mybb->user['uid'];

    $rate_check = $db->query("SELECT COUNT(*) as cnt FROM {$prefix}shoutbox WHERE uid = {$uid} AND dateline > " . (TIME_NOW - 5));
    $rate = $db->fetch_array($rate_check);
    if($rate && (int)$rate['cnt'] >= 3)
    {
        xmlhttp_error('You are sending messages too fast. Please wait.');
        return;
    }

    $db->insert_query('shoutbox', array(
        'uid' => $uid,
        'username' => $db->escape_string($mybb->user['username']),
        'message' => $db->escape_string($message),
        'dateline' => TIME_NOW,
    ));

    header('Content-Type: application/json');
    echo json_encode(array('success' => true));
    exit;
}

function bf_shoutbox_index()
{
    global $mybb, $db, $bf_shoutbox_html;

    $prefix = $db->table_prefix;
    $bburl = htmlspecialchars_uni($mybb->settings['bburl']);
    $uid = (int)$mybb->user['uid'];
    $ug = (int)$mybb->user['usergroup'];
    $is_staff = in_array($ug, array(3, 4, 6)) && $uid > 0;
    $is_admin = in_array($ug, array(3, 4)) && $uid > 0;

    $query = $db->query("
        SELECT s.id, s.uid, s.username, s.message, s.dateline, u.usergroup, u.avatar
        FROM {$prefix}shoutbox s
        LEFT JOIN {$prefix}users u ON u.uid = s.uid
        ORDER BY s.dateline DESC
        LIMIT 40
    ");

    $shouts = array();
    while($row = $db->fetch_array($query)) $shouts[] = $row;
    $shouts = array_reverse($shouts);

    $online_q = $db->simple_select('sessions', 'COUNT(DISTINCT ip) as cnt', 'time > ' . (TIME_NOW - 900));
    $online_count = (int)$db->fetch_field($online_q, 'cnt');

    $member_q = $db->simple_select('sessions', 'COUNT(DISTINCT uid) as cnt', 'uid > 0 AND time > ' . (TIME_NOW - 900));
    $member_count = (int)$db->fetch_field($member_q, 'cnt');

    $bf_shoutbox_html = '';

    $bf_shoutbox_html .= '<div class="bf-shoutbox">';

    $bf_shoutbox_html .= '<div class="bf-sb-header">';
    $bf_shoutbox_html .= '<div class="bf-sb-header-left"><i class="fas fa-comments"></i> Shoutbox</div>';
    $bf_shoutbox_html .= '<div class="bf-sb-header-right">';
    $bf_shoutbox_html .= '<span class="bf-sb-stat"><i class="fas fa-users" style="margin-right:3px;font-size:10px;"></i> ' . $member_count . ' members</span>';
    $bf_shoutbox_html .= '<span class="bf-sb-online"><i class="fas fa-circle"></i> ' . $online_count . ' online</span>';
    if($is_admin) {
        $bf_shoutbox_html .= '<button type="button" id="bf-shoutbox-clear" class="bf-sb-hdr-btn" title="Clear all"><i class="fas fa-trash-alt"></i></button>';
    }
    $bf_shoutbox_html .= '</div>';
    $bf_shoutbox_html .= '</div>';

    $bf_shoutbox_html .= '<div class="bf-sb-messages" id="bf-shoutbox-messages">';

    if(empty($shouts)) {
        $bf_shoutbox_html .= '<div class="bf-sb-empty"><i class="fas fa-comment-slash"></i> No messages yet. Be the first to say something!</div>';
    } else {
        foreach($shouts as $shout) {
            $msg = htmlspecialchars_uni($shout['message']);
            $msg = bf_shoutbox_parse_mentions($msg);
            $name_color = bf_shoutbox_get_color($shout['usergroup'] ?? 2);
            $badge = bf_shoutbox_get_badge($shout['usergroup'] ?? 2);
            $shout_uid = (int)$shout['uid'];
            $shout_id = (int)$shout['id'];
            $time_str = my_date('g:i A', $shout['dateline']);

            $staff_btns = '';
            if($is_staff) {
                $staff_btns = '<span class="bf-sb-actions" data-sid="' . $shout_id . '">'
                    . '<a href="#" class="bf-sb-edit" title="Edit"><i class="fas fa-pen"></i></a>'
                    . '<a href="#" class="bf-sb-del" title="Delete"><i class="fas fa-trash"></i></a>'
                    . '</span>';
            }

            $bf_shoutbox_html .= '<div class="bf-sb-msg" data-sid="' . $shout_id . '">';
            $bf_shoutbox_html .= '<span class="bf-sb-time">' . $time_str . '</span>';
            $bf_shoutbox_html .= $badge;
            $bf_shoutbox_html .= '<a href="member.php?action=profile&amp;uid=' . $shout_uid . '" class="bf-sb-user" style="color:' . $name_color . ';">' . htmlspecialchars_uni($shout['username']) . '</a>';
            $bf_shoutbox_html .= '<span class="bf-sb-text">' . $msg . '</span>';
            $bf_shoutbox_html .= $staff_btns;
            $bf_shoutbox_html .= '</div>';
        }
    }

    $bf_shoutbox_html .= '</div>';

    if($uid > 0 && !in_array($ug, array(5, 7))) {
        $bf_shoutbox_html .= '<div class="bf-sb-input">';
        $bf_shoutbox_html .= '<form id="bf-shoutbox-form" method="post" action="javascript:void(0);" onsubmit="return false;">';
        $bf_shoutbox_html .= '<input type="hidden" name="my_post_key" value="' . htmlspecialchars_uni($mybb->post_code) . '" />';
        $bf_shoutbox_html .= '<div class="bf-sb-input-wrap">';
        $bf_shoutbox_html .= '<input type="text" name="shout_message" id="shout_message" placeholder="Type a message... use @ to mention someone" autocomplete="off" maxlength="300" />';
        $bf_shoutbox_html .= '<div class="bf-sb-input-actions">';
        $bf_shoutbox_html .= '<span class="bf-sb-char-count" id="bf-sb-charcount">300</span>';
        $bf_shoutbox_html .= '<button type="submit" class="bf-sb-send"><i class="fas fa-paper-plane"></i> Send</button>';
        $bf_shoutbox_html .= '</div>';
        $bf_shoutbox_html .= '</div>';
        $bf_shoutbox_html .= '</form>';
        $bf_shoutbox_html .= '</div>';
    } else if($uid <= 0) {
        $bf_shoutbox_html .= '<div class="bf-sb-login"><i class="fas fa-lock" style="margin-right:4px;"></i> <a href="' . $bburl . '/member.php?action=login">Log in</a> or <a href="' . $bburl . '/member.php?action=register">register</a> to chat</div>';
    }

    $bf_shoutbox_html .= '</div>';

    $last_id = 0;
    foreach($shouts as $s) {
        if((int)$s['id'] > $last_id) $last_id = (int)$s['id'];
    }

    $post_key_js = $uid > 0 ? htmlspecialchars_uni($mybb->post_code) : '';
    $is_staff_js = $is_staff ? 'true' : 'false';

    $bf_shoutbox_html .= '<script>
document.addEventListener("DOMContentLoaded", function(){
    var form = document.getElementById("bf-shoutbox-form");
    var container = document.getElementById("bf-shoutbox-messages");
    var lastId = ' . $last_id . ';
    var postKey = "' . $post_key_js . '";
    var isStaff = ' . $is_staff_js . ';

    function scrollBottom(){ if(container) container.scrollTop = container.scrollHeight; }
    scrollBottom();

    var charCount = document.getElementById("bf-sb-charcount");
    var shoutInput = document.getElementById("shout_message");
    if(shoutInput && charCount){
        shoutInput.addEventListener("input", function(){
            var rem = 300 - this.value.length;
            charCount.textContent = rem;
            charCount.style.color = rem < 30 ? "#ef4444" : rem < 60 ? "#eab308" : "";
        });
    }

    if(form) {
        var submitting = false;
        form.addEventListener("submit", function(e){
            e.preventDefault();
            if(submitting) return;
            var msg = shoutInput.value.trim();
            if(!msg || msg.length > 300) return;
            submitting = true;
            var btn = form.querySelector(".bf-sb-send");
            if(btn) btn.disabled = true;
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "xmlhttp.php?action=bf_shout", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onload = function(){
                submitting = false;
                if(btn) btn.disabled = false;
                if(xhr.status === 200){
                    shoutInput.value = "";
                    if(charCount){ charCount.textContent = "300"; charCount.style.color = ""; }
                    bfRefreshShoutbox();
                }
            };
            xhr.onerror = function(){ submitting = false; if(btn) btn.disabled = false; };
            xhr.send("shout_message=" + encodeURIComponent(msg) + "&my_post_key=" + encodeURIComponent(postKey));
        });

        shoutInput.addEventListener("keydown", function(e){
            if(e.key === "Enter" && !e.shiftKey) { form.dispatchEvent(new Event("submit")); e.preventDefault(); }
        });
    }

    function staffBtns(sid) {
        if(!isStaff) return "";
        return "<span class=\"bf-sb-actions\" data-sid=\"" + sid + "\">" +
            "<a href=\"#\" class=\"bf-sb-edit\" title=\"Edit\"><i class=\"fas fa-pen\"></i></a>" +
            "<a href=\"#\" class=\"bf-sb-del\" title=\"Delete\"><i class=\"fas fa-trash\"></i></a></span>";
    }

    function bfRefreshShoutbox() {
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "xmlhttp.php?action=bf_shout_refresh", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onload = function() {
            if(xhr.status !== 200) return;
            try {
                var r = JSON.parse(xhr.responseText);
                if(!r.shouts || r.shouts.length === 0) return;
                var empty = container.querySelector(".bf-sb-empty");
                if(empty) empty.remove();
                var added = false;
                for(var i = 0; i < r.shouts.length; i++) {
                    var s = r.shouts[i];
                    if(s.id <= lastId) continue;
                    var div = document.createElement("div");
                    div.className = "bf-sb-msg bf-sb-msg-new";
                    div.setAttribute("data-sid", s.id);
                    div.innerHTML = "<span class=\"bf-sb-time\">" + (s.time || "") + "</span>" +
                        (s.badge || "") +
                        "<a href=\"member.php?action=profile&uid=" + s.uid + "\" class=\"bf-sb-user\" style=\"color:" + s.color + "\">" + s.username + "</a>" +
                        "<span class=\"bf-sb-text\">" + s.message + "</span>" + staffBtns(s.id);
                    container.appendChild(div);
                    lastId = s.id;
                    added = true;
                }
                if(added) scrollBottom();
            } catch(e) {}
        };
        xhr.send("last_id=" + lastId);
    }

    setInterval(bfRefreshShoutbox, 4000);

    if(container) container.addEventListener("click", function(e) {
        var target = e.target.closest(".bf-sb-del");
        if(target) {
            e.preventDefault();
            var sid = target.closest(".bf-sb-actions").getAttribute("data-sid");
            if(!sid || !confirm("Delete this message?")) return;
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "xmlhttp.php?action=bf_shout_delete", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onload = function(){ if(xhr.status === 200){ var m = container.querySelector("[data-sid=\"" + sid + "\"]"); if(m){ m.style.opacity="0"; m.style.transform="translateX(-20px)"; setTimeout(function(){m.remove()},200); } } };
            xhr.send("shout_id=" + sid + "&my_post_key=" + encodeURIComponent(postKey));
            return;
        }
        var editBtn = e.target.closest(".bf-sb-edit");
        if(editBtn) {
            e.preventDefault();
            var sid = editBtn.closest(".bf-sb-actions").getAttribute("data-sid");
            var msgEl = container.querySelector("[data-sid=\"" + sid + "\"]");
            if(!msgEl) return;
            var textEl = msgEl.querySelector(".bf-sb-text");
            if(!textEl) return;
            var oldText = textEl.textContent;
            var newText = prompt("Edit message:", oldText);
            if(newText === null || newText.trim() === "" || newText === oldText) return;
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "xmlhttp.php?action=bf_shout_edit", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onload = function(){ if(xhr.status === 200){ try { var r = JSON.parse(xhr.responseText); if(r.success) textEl.textContent = newText.trim(); } catch(ex){} } };
            xhr.send("shout_id=" + sid + "&new_message=" + encodeURIComponent(newText.trim()) + "&my_post_key=" + encodeURIComponent(postKey));
        }
    });

    var clearBtn = document.getElementById("bf-shoutbox-clear");
    if(clearBtn) {
        clearBtn.addEventListener("click", function(){
            if(!confirm("Clear ALL shoutbox messages? This cannot be undone.")) return;
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "xmlhttp.php?action=bf_shout_clear", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onload = function(){ if(xhr.status === 200){ try { var r = JSON.parse(xhr.responseText); if(r.success){ container.innerHTML = "<div class=\"bf-sb-empty\"><i class=\"fas fa-comment-slash\"></i> Shoutbox cleared.</div>"; lastId = 0; } } catch(e){} } };
            xhr.send("my_post_key=" + encodeURIComponent(postKey));
        });
    }

    if(shoutInput) {
        var mentionBox = null;
        var mentionTimeout = null;

        shoutInput.addEventListener("input", function(){
            var val = this.value;
            var cursor = this.selectionStart;
            var before = val.substring(0, cursor);
            var match = before.match(/@([a-zA-Z0-9_\\-]{1,20})$/);
            if(!match) { hideMentionBox(); return; }
            clearTimeout(mentionTimeout);
            var partial = match[1];
            mentionTimeout = setTimeout(function(){
                var xhr = new XMLHttpRequest();
                xhr.open("GET", "xmlhttp.php?action=get_users&query=" + encodeURIComponent(partial), true);
                xhr.onload = function(){
                    if(xhr.status !== 200) return;
                    try {
                        var users = JSON.parse(xhr.responseText);
                        if(users && users.length > 0) showMentionBox(users, cursor);
                        else hideMentionBox();
                    } catch(e){ hideMentionBox(); }
                };
                xhr.send();
            }, 150);
        });

        function showMentionBox(users, cursor) {
            hideMentionBox();
            mentionBox = document.createElement("div");
            mentionBox.className = "bf-mention-box";
            var header = document.createElement("div");
            header.className = "bf-mention-header";
            header.textContent = "MEMBERS";
            mentionBox.appendChild(header);
            for(var i = 0; i < Math.min(users.length, 6); i++) {
                var uname = users[i].username || users[i];
                var item = document.createElement("div");
                item.className = "bf-mention-item";
                item.innerHTML = "<i class=\"fas fa-at\"></i> <span>" + uname + "</span>";
                item.setAttribute("data-username", uname);
                (function(un){
                    item.addEventListener("click", function(){
                        var val = shoutInput.value;
                        var before = val.substring(0, cursor);
                        var after = val.substring(cursor);
                        var atPos = before.lastIndexOf("@");
                        shoutInput.value = before.substring(0, atPos) + "@" + un + " " + after;
                        shoutInput.focus();
                        hideMentionBox();
                    });
                })(uname);
                mentionBox.appendChild(item);
            }
            var wrap = shoutInput.closest(".bf-sb-input-wrap");
            if(wrap) { wrap.style.position = "relative"; wrap.appendChild(mentionBox); }
        }

        function hideMentionBox() {
            if(mentionBox && mentionBox.parentNode) mentionBox.parentNode.removeChild(mentionBox);
            mentionBox = null;
        }

        document.addEventListener("click", function(e){ if(!e.target.closest(".bf-mention-box") && e.target !== shoutInput) hideMentionBox(); });
    }
});
</script>';
}
