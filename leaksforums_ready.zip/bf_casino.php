<?php
if(!defined("IN_MYBB")) die("Direct initialization of this file is not allowed.");

$plugins->add_hook("misc_start", "bf_casino_page");
$plugins->add_hook("xmlhttp", "bf_casino_xmlhttp");

function bf_casino_info()
{
    return array(
        "name"          => "BF Casino",
        "description"   => "Casino system with Coinflip, Dice & Slots using CR credits.",
        "website"       => "",
        "author"        => "BF",
        "version"       => "1.0",
        "compatibility" => "18*"
    );
}

function bf_casino_activate() {}
function bf_casino_deactivate() {}

function bf_casino_ensure_table()
{
    global $db;
    static $checked = false;
    if($checked) return;
    $checked = true;
    $prefix = $db->table_prefix;
    if(!$db->table_exists('bf_casino_history')) {
        $db->write_query("CREATE TABLE IF NOT EXISTS {$prefix}bf_casino_history (
            hid SERIAL PRIMARY KEY,
            uid INT NOT NULL DEFAULT 0,
            game VARCHAR(20) NOT NULL DEFAULT '',
            bet INT NOT NULL DEFAULT 0,
            result VARCHAR(100) NOT NULL DEFAULT '',
            payout INT NOT NULL DEFAULT 0,
            dateline INT NOT NULL DEFAULT 0
        )");
    }
}

function bf_casino_xmlhttp()
{
    global $mybb, $db;

    $action = $mybb->get_input('action');
    if($action !== 'bf_casino_play') return;

    if($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }
    if($mybb->user['uid'] <= 0) { xmlhttp_error('Login required.'); return; }
    if((int)$mybb->user['usergroup'] === 7 || (int)$mybb->user['usergroup'] === 5) { xmlhttp_error('No permission.'); return; }
    verify_post_check($mybb->get_input('my_post_key'));

    bf_casino_ensure_table();

    $game = trim($mybb->get_input('game'));
    $bet = $mybb->get_input('bet', MyBB::INPUT_INT);
    $uid = (int)$mybb->user['uid'];
    $choice = trim($mybb->get_input('choice'));

    if($bet < 10) { xmlhttp_error('Minimum bet is 10 CR.'); return; }
    if($bet > 50000) { xmlhttp_error('Maximum bet is 50,000 CR.'); return; }

    $recent = (int)$db->fetch_field($db->simple_select('bf_casino_history', 'COUNT(*) as cnt', "uid={$uid} AND dateline > " . (TIME_NOW - 5)), 'cnt');
    if($recent >= 3) { xmlhttp_error('Slow down! Wait a few seconds.'); return; }

    $db->write_query("BEGIN");
    $user_points = (float)$db->fetch_field($db->write_query("SELECT newpoints FROM {$db->table_prefix}users WHERE uid={$uid} FOR UPDATE"), 'newpoints');
    if($user_points < $bet) {
        $db->write_query("ROLLBACK");
        xmlhttp_error('Not enough credits. You have ' . number_format((int)$user_points) . ' CR.');
        return;
    }

    $payout = 0;
    $result_text = '';

    if($game === 'coinflip')
    {
        if($choice !== 'heads' && $choice !== 'tails') { $db->write_query("ROLLBACK"); xmlhttp_error('Pick heads or tails.'); return; }
        $flip = random_int(0, 1) === 0 ? 'heads' : 'tails';
        if($flip === $choice) {
            $payout = $bet * 2;
            $result_text = 'Coin: ' . ucfirst($flip) . ' — You win!';
        } else {
            $payout = 0;
            $result_text = 'Coin: ' . ucfirst($flip) . ' — You lose!';
        }
    }
    elseif($game === 'dice')
    {
        $roll = random_int(1, 6);
        $choice_num = (int)$choice;
        if($choice_num < 1 || $choice_num > 6) { $db->write_query("ROLLBACK"); xmlhttp_error('Pick a number 1-6.'); return; }
        if($roll === $choice_num) {
            $payout = $bet * 5;
            $result_text = 'Dice: ' . $roll . ' — Exact match! 5x win!';
        } elseif(abs($roll - $choice_num) === 1) {
            $payout = (int)($bet * 1.5);
            $result_text = 'Dice: ' . $roll . ' — Close! 1.5x win!';
        } else {
            $payout = 0;
            $result_text = 'Dice: ' . $roll . ' — You lose!';
        }
    }
    elseif($game === 'slots')
    {
        $symbols = array('cherry', 'lemon', 'orange', 'plum', 'bell', 'bar', 'seven');
        $r1 = $symbols[random_int(0, 6)];
        $r2 = $symbols[random_int(0, 6)];
        $r3 = $symbols[random_int(0, 6)];

        if($r1 === 'seven' && $r2 === 'seven' && $r3 === 'seven') {
            $payout = $bet * 50;
            $result_text = $r1 . ' | ' . $r2 . ' | ' . $r3 . ' — JACKPOT! 50x!';
        } elseif($r1 === $r2 && $r2 === $r3) {
            $payout = $bet * 10;
            $result_text = $r1 . ' | ' . $r2 . ' | ' . $r3 . ' — Three of a kind! 10x!';
        } elseif($r1 === $r2 || $r2 === $r3 || $r1 === $r3) {
            $payout = (int)($bet * 2);
            $result_text = $r1 . ' | ' . $r2 . ' | ' . $r3 . ' — Pair! 2x!';
        } else {
            $payout = 0;
            $result_text = $r1 . ' | ' . $r2 . ' | ' . $r3 . ' — No match!';
        }
    }
    elseif($game === 'roulette')
    {
        $spin = random_int(0, 36);
        $spin_color = ($spin === 0) ? 'green' : (($spin % 2 === 0) ? 'black' : 'red');

        if($choice === 'red' || $choice === 'black') {
            if($choice === $spin_color) {
                $payout = $bet * 2;
                $result_text = 'Roulette: ' . $spin . ' (' . $spin_color . ') — You win! 2x!';
            } else {
                $payout = 0;
                $result_text = 'Roulette: ' . $spin . ' (' . $spin_color . ') — You lose!';
            }
        } elseif($choice === 'green') {
            if($spin === 0) {
                $payout = $bet * 14;
                $result_text = 'Roulette: 0 (green) — Green hit! 14x!';
            } else {
                $payout = 0;
                $result_text = 'Roulette: ' . $spin . ' (' . $spin_color . ') — Not green!';
            }
        } else {
            $db->write_query("ROLLBACK"); xmlhttp_error('Pick red, black, or green.'); return;
        }
    }
    else
    {
        $db->write_query("ROLLBACK"); xmlhttp_error('Unknown game.'); return;
    }

    $net = $payout - $bet;
    if($net > 0) {
        $db->write_query("UPDATE {$db->table_prefix}users SET newpoints = newpoints + {$net} WHERE uid = {$uid}");
    } elseif($net < 0) {
        $loss = abs($net);
        $db->write_query("UPDATE {$db->table_prefix}users SET newpoints = GREATEST(0, newpoints - {$loss}) WHERE uid = {$uid}");
    }

    $db->insert_query('bf_casino_history', array(
        'uid' => $uid,
        'game' => $db->escape_string($game),
        'bet' => $bet,
        'result' => $db->escape_string($result_text),
        'payout' => $payout,
        'dateline' => TIME_NOW,
    ));

    $db->write_query("COMMIT");

    $new_balance = (int)$db->fetch_field($db->simple_select('users', 'newpoints', "uid={$uid}"), 'newpoints');

    header('Content-Type: application/json');
    echo json_encode(array(
        'success' => true,
        'result' => $result_text,
        'payout' => $payout,
        'net' => $net,
        'balance' => number_format($new_balance),
        'win' => ($net > 0),
    ));
    exit;
}

function bf_casino_page()
{
    global $mybb, $db, $header, $headerinclude, $footer, $theme;

    if($mybb->get_input('action') !== 'bf_casino') return;

    if($mybb->user['uid'] <= 0) {
        error_no_permission();
        return;
    }

    bf_casino_ensure_table();
    $uid = (int)$mybb->user['uid'];
    $balance = (int)$db->fetch_field($db->simple_select('users', 'newpoints', "uid={$uid}"), 'newpoints');
    $post_key = htmlspecialchars_uni($mybb->post_code);

    $history_html = '';
    $hq = $db->query("SELECT * FROM {$db->table_prefix}bf_casino_history WHERE uid={$uid} ORDER BY dateline DESC LIMIT 15");
    while($h = $db->fetch_array($hq))
    {
        $net = (int)$h['payout'] - (int)$h['bet'];
        $net_class = $net > 0 ? 'w' : 'l';
        $net_text = $net > 0 ? '+' . number_format($net) : number_format($net);
        $history_html .= '<div class="bfc-hist-r">'
            . '<div class="bfc-hist-game">' . htmlspecialchars_uni(ucfirst($h['game'])) . '</div>'
            . '<div class="bfc-hist-bet">' . number_format((int)$h['bet']) . ' CR</div>'
            . '<div class="bfc-hist-result">' . htmlspecialchars_uni($h['result']) . '</div>'
            . '<div class="bfc-hist-net ' . $net_class . '">' . $net_text . '</div>'
            . '<div class="bfc-hist-time">' . my_date('relative', (int)$h['dateline']) . '</div>'
            . '</div>';
    }

    $total_wagered = (int)$db->fetch_field($db->write_query("SELECT COALESCE(SUM(bet),0) as s FROM {$db->table_prefix}bf_casino_history WHERE uid={$uid}"), 's');
    $total_won = (int)$db->fetch_field($db->write_query("SELECT COALESCE(SUM(payout),0) as s FROM {$db->table_prefix}bf_casino_history WHERE uid={$uid}"), 's');
    $total_profit = $total_won - $total_wagered;
    $games_played = (int)$db->fetch_field($db->simple_select('bf_casino_history', 'COUNT(*) as cnt', "uid={$uid}"), 'cnt');
    $profit_color = $total_profit >= 0 ? '#5a9' : '#c55';
    $profit_prefix = $total_profit >= 0 ? '+' : '';

    $page = '<!DOCTYPE html><html><head><title>Casino - LeaksForums</title>';
    $page .= $headerinclude;
    $page .= '<style>
.bfc{max-width:880px;margin:10px auto 30px;font-family:inherit}
.bfc-bal{background:#151a22;border:1px solid #1e2733;padding:20px 24px;margin-bottom:12px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px}
.bfc-bal-left{display:flex;align-items:baseline;gap:10px}
.bfc-bal-n{font-size:28px;font-weight:800;color:#e8b84a}
.bfc-bal-l{font-size:11px;color:#556677;text-transform:uppercase;letter-spacing:.5px}
.bfc-bal-stats{display:flex;gap:20px;font-size:12px;color:#556677}
.bfc-bal-stats span{color:#8a9aaa}
.bfc-games{display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px}
.bfc-g{background:#151a22;border:1px solid #1e2733;overflow:hidden}
.bfc-g-h{padding:12px 16px;border-bottom:1px solid #1e2733;display:flex;align-items:center;justify-content:space-between}
.bfc-g-name{font-size:13px;font-weight:700;color:#c8d0d8}
.bfc-g-multi{font-size:10px;color:#556677;font-family:monospace}
.bfc-g-b{padding:14px 16px}
.bfc-picks{display:flex;gap:4px;margin-bottom:10px;flex-wrap:wrap}
.bfc-pick{background:#0c1018;border:1px solid #222c38;color:#667788;padding:5px 12px;font-size:12px;cursor:pointer;transition:all 120ms;user-select:none}
.bfc-pick:hover{border-color:#3a5060;color:#99aabb}
.bfc-pick.on{border-color:#4a7a6a;color:#7cbba8;background:rgba(90,153,119,0.06)}
.bfc-pick-r{color:#c55}.bfc-pick-b{color:#99aabb}.bfc-pick-g{color:#5a9}
.bfc-row{display:flex;gap:6px;align-items:stretch}
.bfc-inp{flex:1;background:#0c1018;border:1px solid #222c38;color:#c8d0d8;padding:8px 12px;font-size:13px;outline:none;font-family:inherit}
.bfc-inp:focus{border-color:#3a5060}
.bfc-btn{background:#1e3328;border:1px solid #2a5040;color:#7cbba8;padding:8px 16px;font-size:12px;font-weight:700;cursor:pointer;transition:all 120ms;white-space:nowrap}
.bfc-btn:hover{background:#2a5040;color:#a0ddc8}
.bfc-btn:disabled{opacity:.4;cursor:not-allowed}
.bfc-res{margin-top:10px;padding:10px 12px;font-size:13px;font-weight:600;text-align:center;display:none}
.bfc-res.w{background:rgba(90,153,119,0.08);border:1px solid #2a5040;color:#7cbba8}
.bfc-res.l{background:rgba(200,80,80,0.06);border:1px solid #5a2020;color:#c55}
.bfc-hist{background:#151a22;border:1px solid #1e2733;overflow:hidden}
.bfc-hist-h{padding:12px 16px;border-bottom:1px solid #1e2733;font-size:12px;font-weight:700;color:#778899;text-transform:uppercase;letter-spacing:.5px}
.bfc-hist-r{display:flex;align-items:center;padding:8px 16px;border-bottom:1px solid #13171f;font-size:12px;gap:12px}
.bfc-hist-r:last-child{border-bottom:none}
.bfc-hist-game{width:70px;color:#8a9aaa;font-weight:600}
.bfc-hist-bet{width:70px;color:#667788}
.bfc-hist-result{flex:1;color:#8a9aaa}
.bfc-hist-net{width:80px;text-align:right;font-weight:700}
.bfc-hist-net.w{color:#5a9}.bfc-hist-net.l{color:#c55}
.bfc-hist-time{width:80px;text-align:right;color:#445566;font-size:11px}
.bfc-hist-e{padding:20px;text-align:center;color:#445566;font-size:12px}
@media(max-width:700px){.bfc-games{grid-template-columns:1fr}.bfc-bal{flex-direction:column;align-items:flex-start}}
</style>';
    $page .= '</head><body>' . $header . '
    <div class="bfc">
        <div class="bfc-bal">
            <div>
                <div class="bfc-bal-left"><div class="bfc-bal-n" id="bf-casino-bal">' . number_format($balance) . '</div><div class="bfc-bal-l">CR Balance</div></div>
            </div>
            <div class="bfc-bal-stats">
                <div>Played: <span>' . number_format($games_played) . '</span></div>
                <div>Wagered: <span>' . number_format($total_wagered) . '</span></div>
                <div>P/L: <span style="color:' . $profit_color . '">' . $profit_prefix . number_format($total_profit) . '</span></div>
            </div>
        </div>

        <div class="bfc-games">
            <div class="bfc-g">
                <div class="bfc-g-h"><div class="bfc-g-name">Coinflip</div><div class="bfc-g-multi">2x</div></div>
                <div class="bfc-g-b">
                    <div class="bfc-picks">
                        <div class="bfc-pick" data-val="heads" onclick="bfPk(this)">Heads</div>
                        <div class="bfc-pick" data-val="tails" onclick="bfPk(this)">Tails</div>
                    </div>
                    <div class="bfc-row">
                        <input type="number" class="bfc-inp bf-bet" placeholder="Amount" min="10" max="50000" />
                        <button class="bfc-btn" onclick="bfPlay(\'coinflip\',this)">FLIP</button>
                    </div>
                    <div class="bfc-res"></div>
                </div>
            </div>

            <div class="bfc-g">
                <div class="bfc-g-h"><div class="bfc-g-name">Dice</div><div class="bfc-g-multi">5x exact / 1.5x close</div></div>
                <div class="bfc-g-b">
                    <div class="bfc-picks">
                        <div class="bfc-pick" data-val="1" onclick="bfPk(this)">1</div>
                        <div class="bfc-pick" data-val="2" onclick="bfPk(this)">2</div>
                        <div class="bfc-pick" data-val="3" onclick="bfPk(this)">3</div>
                        <div class="bfc-pick" data-val="4" onclick="bfPk(this)">4</div>
                        <div class="bfc-pick" data-val="5" onclick="bfPk(this)">5</div>
                        <div class="bfc-pick" data-val="6" onclick="bfPk(this)">6</div>
                    </div>
                    <div class="bfc-row">
                        <input type="number" class="bfc-inp bf-bet" placeholder="Amount" min="10" max="50000" />
                        <button class="bfc-btn" onclick="bfPlay(\'dice\',this)">ROLL</button>
                    </div>
                    <div class="bfc-res"></div>
                </div>
            </div>

            <div class="bfc-g">
                <div class="bfc-g-h"><div class="bfc-g-name">Slots</div><div class="bfc-g-multi">2x / 10x / 50x jackpot</div></div>
                <div class="bfc-g-b">
                    <div class="bfc-row">
                        <input type="number" class="bfc-inp bf-bet" placeholder="Amount" min="10" max="50000" />
                        <button class="bfc-btn" onclick="bfPlay(\'slots\',this)">SPIN</button>
                    </div>
                    <div class="bfc-res"></div>
                </div>
            </div>

            <div class="bfc-g">
                <div class="bfc-g-h"><div class="bfc-g-name">Roulette</div><div class="bfc-g-multi">2x color / 14x green</div></div>
                <div class="bfc-g-b">
                    <div class="bfc-picks">
                        <div class="bfc-pick bfc-pick-r" data-val="red" onclick="bfPk(this)">Red</div>
                        <div class="bfc-pick bfc-pick-b" data-val="black" onclick="bfPk(this)">Black</div>
                        <div class="bfc-pick bfc-pick-g" data-val="green" onclick="bfPk(this)">Green</div>
                    </div>
                    <div class="bfc-row">
                        <input type="number" class="bfc-inp bf-bet" placeholder="Amount" min="10" max="50000" />
                        <button class="bfc-btn" onclick="bfPlay(\'roulette\',this)">SPIN</button>
                    </div>
                    <div class="bfc-res"></div>
                </div>
            </div>
        </div>

        <div class="bfc-hist">
            <div class="bfc-hist-h">History</div>
            ' . ($history_html ?: '<div class="bfc-hist-e">No games played yet.</div>') . '
        </div>
    </div>

    <input type="hidden" id="bf-pk" value="' . $post_key . '" />
    <script>
    function bfPk(el){var s=el.parentNode.querySelectorAll(".bfc-pick");for(var i=0;i<s.length;i++)s[i].classList.remove("on");el.classList.add("on")}
    function bfPlay(game,btn){
        var card=btn.closest(".bfc-g"),inp=card.querySelector(".bf-bet"),bet=parseInt(inp.value);
        if(!bet||bet<10){alert("Min bet: 10 CR");return}
        if(bet>50000){alert("Max bet: 50,000 CR");return}
        var choice="",ac=card.querySelector(".bfc-pick.on");
        if(ac)choice=ac.getAttribute("data-val");
        if((game==="coinflip"||game==="dice"||game==="roulette")&&!choice){alert("Make a selection");return}
        btn.disabled=true;var orig=btn.textContent;btn.textContent="...";
        var fd=new FormData();
        fd.append("action","bf_casino_play");
        fd.append("my_post_key",document.getElementById("bf-pk")?document.getElementById("bf-pk").value:"");
        fd.append("game",game);fd.append("bet",bet);fd.append("choice",choice);
        fetch("xmlhttp.php",{method:"POST",body:fd}).then(function(r){return r.json()}).then(function(d){
            btn.disabled=false;btn.textContent=orig;
            if(d.error){alert(d.error);return}
            var re=card.querySelector(".bfc-res");re.style.display="block";
            re.className="bfc-res "+(d.win?"w":"l");
            re.textContent=d.result+" ("+(d.net>0?"+":"")+d.net+" CR)";
            document.getElementById("bf-casino-bal").textContent=d.balance;
            var hc=document.getElementById("bf-credits-count");if(hc)hc.textContent=d.balance;
        }).catch(function(){btn.disabled=false;btn.textContent=orig;alert("Request failed.")});
    }
    </script>
    ' . $footer . '</body></html>';

    echo $page;
    exit;
}
