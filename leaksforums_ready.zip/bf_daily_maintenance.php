<?php

function task_bf_daily_maintenance($task)
{
    global $db, $mybb;
    
    $prefix = $db->table_prefix;

    $db->write_query("UPDATE {$prefix}users SET regip='0.0.0.0', lastip='0.0.0.0' WHERE regip != '0.0.0.0' OR lastip != '0.0.0.0'");
    $db->write_query("UPDATE {$prefix}posts SET ipaddress='0.0.0.0' WHERE ipaddress != '0.0.0.0' AND ipaddress != ''");

    $cutoff = TIME_NOW - 86400;
    $db->write_query("DELETE FROM {$prefix}sessions WHERE \"time\" < {$cutoff}");
    $db->write_query("DELETE FROM {$prefix}adminlog WHERE dateline < {$cutoff}");
    $db->write_query("DELETE FROM {$prefix}moderatorlog WHERE dateline < {$cutoff}");
    $db->write_query("DELETE FROM {$prefix}maillogs WHERE dateline < {$cutoff}");
    $db->write_query("DELETE FROM {$prefix}tasklog WHERE dateline < {$cutoff}");

    $old_shouts = TIME_NOW - (30 * 86400);
    $db->write_query("DELETE FROM {$prefix}shoutbox WHERE dateline < {$old_shouts}");

    $backup_dir = realpath(MYBB_ROOT . '/../') . '/backups';
    if(!is_dir($backup_dir)) {
        @mkdir($backup_dir, 0700, true);
    }

    $config_path = MYBB_ROOT . 'inc/config.php';
    $config = array();
    if(file_exists($config_path)) {
        include $config_path;
    }

    $host   = !empty($config['database']['hostname']) ? $config['database']['hostname'] : (getenv('PGHOST') ?: 'helium');
    $port   = getenv('PGPORT') ?: '5432';
    $dbname = !empty($config['database']['database']) ? $config['database']['database'] : (getenv('PGDATABASE') ?: 'heliumdb');
    $dbuser = !empty($config['database']['username']) ? $config['database']['username'] : (getenv('PGUSER') ?: 'postgres');
    $dbpass = !empty($config['database']['password']) ? $config['database']['password'] : (getenv('PGPASSWORD') ?: '');

    $date = date('Y-m-d_H-i-s');
    $filepath = $backup_dir . "/bf_backup_{$date}.sql.gz";

    putenv("PGPASSWORD={$dbpass}");
    $cmd = "pg_dump -h " . escapeshellarg($host)
         . " -p " . escapeshellarg($port)
         . " -U " . escapeshellarg($dbuser)
         . " -d " . escapeshellarg($dbname)
         . " --no-owner --no-privileges"
         . " | gzip > " . escapeshellarg($filepath);
    
    $output = array();
    $ret = 0;
    exec($cmd, $output, $ret);
    putenv("PGPASSWORD=");

    $backup_ok = ($ret === 0 && file_exists($filepath) && filesize($filepath) > 100);

    $backups = glob($backup_dir . '/bf_backup_*.sql.gz');
    usort($backups, function($a, $b) { return filemtime($a) - filemtime($b); });
    while(count($backups) > 7) {
        $old = array_shift($backups);
        @unlink($old);
    }

    $status = $backup_ok ? "Backup OK" : "Backup FAILED (code {$ret})";
    add_task_log($task, "Maintenance complete: IPs anonymized, logs cleaned. {$status}");
}
