<?php
if(!defined("IN_MYBB"))
{
    die("Direct initialization of this file is not allowed.");
}

$plugins->add_hook("global_start", "bf_features_global");
$plugins->add_hook("global_end", "bf_features_global_end");
$plugins->add_hook("index_end", "bf_features_index");
$plugins->add_hook("postbit", "bf_features_postbit");
$plugins->add_hook("member_profile_end", "bf_features_profile");
$plugins->add_hook("misc_start", "bf_features_misc");
$plugins->add_hook("misc_start", "bf_features_landing_page");
$plugins->add_hook("misc_start", "bf_features_canary_page");
$plugins->add_hook("misc_start", "bf_features_warnings_page");
$plugins->add_hook("misc_start", "bf_features_ads_page");
$plugins->add_hook("xmlhttp", "bf_features_xmlhttp");
$plugins->add_hook("xmlhttp", "bf_features_media_xmlhttp");
$plugins->add_hook("misc_start", "bf_features_media_page");
$plugins->add_hook("misc_start", "bf_features_analytics_page");
$plugins->add_hook("misc_start", "bf_features_referrals_page");
$plugins->add_hook("showthread_start", "bf_features_thread");
$plugins->add_hook("parse_message_end", "bf_features_parse_bbcode");
$plugins->add_hook("member_do_register_end", "bf_features_register_referral");

function bf_features_info()
{
    return array(
        "name"          => "BF Features Pack",
        "description"   => "Reputation system, trophies, user profiles stats, thread ratings, @mentions and more.",
        "website"       => "",
        "author"        => "BF",
        "version"       => "1.0",
        "compatibility" => "18*"
    );
}

function bf_features_activate()
{
    global $db;
    $prefix = $db->table_prefix;

    if(!$db->table_exists('bf_reputation'))
    {
        $db->write_query("CREATE TABLE IF NOT EXISTS {$prefix}bf_reputation (
            rid SERIAL PRIMARY KEY,
            uid INT NOT NULL DEFAULT 0,
            adduid INT NOT NULL DEFAULT 0,
            pid INT NOT NULL DEFAULT 0,
            reputation INT NOT NULL DEFAULT 0,
            dateline INT NOT NULL DEFAULT 0,
            comments TEXT
        )");
        $db->write_query("CREATE INDEX IF NOT EXISTS idx_bf_rep_uid ON {$prefix}bf_reputation (uid)");
        $db->write_query("CREATE INDEX IF NOT EXISTS idx_bf_rep_pid ON {$prefix}bf_reputation (pid)");
    }

    if(!$db->table_exists('bf_trophies'))
    {
        $db->write_query("CREATE TABLE IF NOT EXISTS {$prefix}bf_trophies (
            tid SERIAL PRIMARY KEY,
            uid INT NOT NULL DEFAULT 0,
            trophy_key VARCHAR(80) NOT NULL DEFAULT '',
            trophy_name VARCHAR(200) NOT NULL DEFAULT '',
            trophy_icon VARCHAR(80) NOT NULL DEFAULT '',
            trophy_color VARCHAR(20) NOT NULL DEFAULT '',
            dateline INT NOT NULL DEFAULT 0
        )");
        $db->write_query("CREATE UNIQUE INDEX IF NOT EXISTS idx_bf_trophy_unique ON {$prefix}bf_trophies (uid, trophy_key)");
    }

    if(!$db->table_exists('bf_post_likes'))
    {
        $db->write_query("CREATE TABLE IF NOT EXISTS {$prefix}bf_post_likes (
            lid SERIAL PRIMARY KEY,
            pid INT NOT NULL DEFAULT 0,
            uid INT NOT NULL DEFAULT 0,
            dateline INT NOT NULL DEFAULT 0
        )");
        $db->write_query("CREATE UNIQUE INDEX IF NOT EXISTS idx_bf_like_unique ON {$prefix}bf_post_likes (pid, uid)");
        $db->write_query("CREATE INDEX IF NOT EXISTS idx_bf_like_pid ON {$prefix}bf_post_likes (pid)");
    }

    if(!$db->table_exists('bf_paid_content'))
    {
        $db->write_query("CREATE TABLE IF NOT EXISTS {$prefix}bf_paid_content (
            pcid SERIAL PRIMARY KEY,
            pid INT NOT NULL DEFAULT 0,
            uid INT NOT NULL DEFAULT 0,
            dateline INT NOT NULL DEFAULT 0
        )");
        $db->write_query("CREATE UNIQUE INDEX IF NOT EXISTS idx_bf_paid_unique ON {$prefix}bf_paid_content (pid, uid)");
        $db->write_query("CREATE INDEX IF NOT EXISTS idx_bf_paid_pid ON {$prefix}bf_paid_content (pid)");
    }

    if(!$db->table_exists('bf_temp_ads'))
    {
        $db->write_query("CREATE TABLE IF NOT EXISTS {$prefix}bf_temp_ads (
            aid SERIAL PRIMARY KEY,
            title VARCHAR(255) NOT NULL DEFAULT '',
            image_url TEXT NOT NULL DEFAULT '',
            link_url TEXT NOT NULL DEFAULT '',
            position INT NOT NULL DEFAULT 0,
            active INT NOT NULL DEFAULT 1,
            dateline INT NOT NULL DEFAULT 0
        )");
    }
}

function bf_features_deactivate() {}

function bf_features_ensure_tables()
{
    global $db;
    static $checked = false;
    if($checked) return;
    $checked = true;

    if(!$db->table_exists('bf_reputation'))
    {
        bf_features_activate();
    }
}

function bf_features_global()
{
    global $mybb, $db, $headerinclude;

    $headerinclude .= '<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">';

    bf_features_ensure_tables();
    bf_features_ensure_analytics_tables();

    $post_key = '';
    if($mybb->user['uid'] > 0)
    {
        $post_key = htmlspecialchars_uni($mybb->post_code);
    }
    $uid = (int)$mybb->user['uid'];

    $GLOBALS['bf_features_js_code'] = true;

    $prefix = $db->table_prefix;

    if(isset($_GET['ref']))
    {
        $ref_code = preg_replace('/[^a-zA-Z0-9]/', '', $_GET['ref']);
        if(!empty($ref_code))
        {
            $ref_user = $db->fetch_array($db->simple_select('bf_referral_codes', '*', "code='" . $db->escape_string($ref_code) . "'"));
            if($ref_user)
            {
                $ref_uid = (int)$ref_user['uid'];
                $ck = 'bf_ref_' . $ref_code;
                if(!isset($_COOKIE[$ck]))
                {
                    $db->insert_query('bf_referral_clicks', array(
                        'ref_uid' => $ref_uid,
                        'code' => $db->escape_string($ref_code),
                        'visitor_ip' => '0.0.0.0',
                        'visitor_uid' => $uid,
                        'dateline' => TIME_NOW,
                    ));
                    my_setcookie($ck, '1', TIME_NOW + 86400);
                    my_setcookie('bf_ref_code', $ref_code, TIME_NOW + (86400 * 30));
                }
            }
        }
    }
}

function bf_features_register_referral()
{
    global $mybb, $db, $user_info;
    if(empty($user_info['uid']) || $user_info['uid'] <= 0) return;
    $new_uid = (int)$user_info['uid'];

    $ref_code = '';
    if(isset($mybb->cookies['bf_ref_code'])) $ref_code = preg_replace('/[^a-zA-Z0-9]/', '', $mybb->cookies['bf_ref_code']);
    if(empty($ref_code)) return;

    bf_features_ensure_analytics_tables();

    $ref_user = $db->fetch_array($db->simple_select('bf_referral_codes', '*', "code='" . $db->escape_string($ref_code) . "'"));
    if(!$ref_user || (int)$ref_user['uid'] === $new_uid) return;

    $existing = $db->fetch_array($db->simple_select('bf_referral_clicks', '*', "code='" . $db->escape_string($ref_code) . "' AND visitor_uid={$new_uid}"));
    if($existing) return;

    $unlinked = $db->fetch_array($db->simple_select('bf_referral_clicks', '*', "code='" . $db->escape_string($ref_code) . "' AND visitor_uid=0", array('order_by' => 'dateline', 'order_dir' => 'DESC', 'limit' => 1)));
    if($unlinked)
    {
        $db->update_query('bf_referral_clicks', array('visitor_uid' => $new_uid), "ckid=" . (int)$unlinked['ckid']);
    }
    else
    {
        $db->insert_query('bf_referral_clicks', array(
            'ref_uid' => (int)$ref_user['uid'],
            'code' => $db->escape_string($ref_code),
            'visitor_ip' => '0.0.0.0',
            'visitor_uid' => $new_uid,
            'dateline' => TIME_NOW,
        ));
    }
}

function bf_features_global_end()
{
    global $mybb, $footer, $header, $db;

    if(empty($GLOBALS['bf_features_js_code'])) return;

    $post_key = '';
    if($mybb->user['uid'] > 0)
    {
        $post_key = htmlspecialchars_uni($mybb->post_code);
    }
    $uid = (int)$mybb->user['uid'];

    $notif_bar = '';
    static $has_alerts_table = null;
    if($has_alerts_table === null) { $has_alerts_table = $db->table_exists('alerts') ? 1 : 0; }
    if($uid > 0)
    {
        $unread_pms = (int)$mybb->user['unreadpms'];
        $credits = isset($mybb->user['newpoints']) ? (int)$mybb->user['newpoints'] : 0;
        $unread_alerts = 0;
        if($has_alerts_table)
        {
            $unread_alerts = (int)$db->fetch_field($db->simple_select('alerts', 'COUNT(*) as cnt', "uid={$uid} AND unread=1"), 'cnt');
        }
        $pm_badge = $unread_pms > 0 ? '<span class="bf-notif-dot" id="bf-pm-badge">' . $unread_pms . '</span>' : '<span class="bf-notif-dot" id="bf-pm-badge" style="display:none">0</span>';

        $notif_bar = '<div class="bf-hdr-bar" id="bf-header-actions">'
            . '<a href="misc.php?action=upgrades" class="bf-hdr-credits" title="Credits"><i class="fas fa-coins"></i><span id="bf-credits-count">' . number_format($credits) . '</span> CR</a>'
            . '<span class="bf-hdr-sep"></span>'
            . '<a href="private.php" class="bf-hdr-btn" title="Messages">' . $pm_badge . '<i class="fas fa-envelope"></i></a>';

        if($has_alerts_table)
        {
            $alert_badge = $unread_alerts > 0 ? '<span class="bf-notif-dot" id="bf-alert-badge">' . $unread_alerts . '</span>' : '<span class="bf-notif-dot" id="bf-alert-badge" style="display:none">0</span>';
            $notif_bar .= '<a href="alerts.php" class="bf-hdr-btn" title="Alerts">' . $alert_badge . '<i class="fas fa-bell"></i></a>';
        }

        $notif_bar .= '</div>';
    }

    $bf_features_js = '<input type="hidden" id="bf-pk" value="' . $post_key . '" /><script>
var BF_FEATURES = {
    uid: ' . $uid . ',
    gpk: function(){ var e = document.getElementById("bf-pk"); if(!e || !e.value) { alert("Session expired. Please refresh the page."); return null; } return e.value; }
};

function bfLikePost(pid) {
    if(BF_FEATURES.uid <= 0) { alert("You must be logged in."); return; }
    var pk = BF_FEATURES.gpk(); if(!pk) return;
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "xmlhttp.php?action=bf_like_post", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onload = function() {
        if(xhr.status === 200) {
            try {
                var r = JSON.parse(xhr.responseText);
                var el = document.getElementById("bf-like-count-"+pid);
                var btn = document.getElementById("bf-like-btn-"+pid);
                if(el) el.textContent = r.likes;
                if(btn) {
                    if(r.action === "liked") {
                        btn.classList.add("bf-liked");
                        btn.querySelector("i").className = "fas fa-heart";
                    } else {
                        btn.classList.remove("bf-liked");
                        btn.querySelector("i").className = "far fa-heart";
                    }
                }
            } catch(e) {}
        }
    };
    xhr.send("pid="+pid+"&my_post_key="+pk);
}

function bfGiveRep(uid, pid, val) {
    if(BF_FEATURES.uid <= 0) { alert("You must be logged in."); return; }
    if(BF_FEATURES.uid == uid) { alert("You cannot rep yourself."); return; }
    var pk = BF_FEATURES.gpk(); if(!pk) return;
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "xmlhttp.php?action=bf_give_rep", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onload = function() {
        if(xhr.status === 200) {
            try {
                var r = JSON.parse(xhr.responseText);
                var el = document.getElementById("bf-rep-count-"+pid);
                if(el) el.textContent = (r.total >= 0 ? "+":"") + r.total;
            } catch(e) {}
        }
    };
    xhr.send("uid="+uid+"&pid="+pid+"&value="+val+"&my_post_key="+pk);
}
function bfBuyContent(pid, price) {
    if(BF_FEATURES.uid <= 0) { alert("You must be logged in."); return; }
    if(!confirm("Buy this content for " + price + " Credits?")) return;
    var pk = BF_FEATURES.gpk(); if(!pk) return;
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "xmlhttp.php?action=bf_buy_content", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onload = function() {
        if(xhr.status === 200) {
            try {
                var r = JSON.parse(xhr.responseText);
                if(r.success) { alert(r.message); location.reload(); }
                else if(r.errors) { alert(r.errors.join("\\n")); }
            } catch(e) { alert("Error processing purchase."); }
        }
    };
    xhr.send("pid="+pid+"&my_post_key="+pk);
}
(function(){
    var bars = document.querySelector(".sidenav__bars");
    if(!bars) return;
    var menu = document.querySelector(".sidenav__menu");
    if(!menu) return;
    bars.addEventListener("click", function(e){
        e.stopPropagation();
        var open = menu.classList.toggle("bf-mob-open");
        bars.innerHTML = open ? "<i class=\"fas fa-times\"></i>" : "<i class=\"fas fa-bars\"></i>";
        document.body.style.overflow = open ? "hidden" : "";
    });
    menu.addEventListener("click", function(e){
        if(e.target.closest("a") && !e.target.closest(".dropdown-button")){
            menu.classList.remove("bf-mob-open");
            bars.innerHTML = "<i class=\"fas fa-bars\"></i>";
            document.body.style.overflow = "";
        }
    });
    document.addEventListener("click", function(e){
        if(!e.target.closest("#sidenav") && menu.classList.contains("bf-mob-open")){
            menu.classList.remove("bf-mob-open");
            bars.innerHTML = "<i class=\"fas fa-bars\"></i>";
            document.body.style.overflow = "";
        }
    });
    window.addEventListener("resize", function(){
        if(window.innerWidth > 768 && menu.classList.contains("bf-mob-open")){
            menu.classList.remove("bf-mob-open");
            bars.innerHTML = "<i class=\"fas fa-bars\"></i>";
            document.body.style.overflow = "";
        }
    });
})();
</script>';

    if($notif_bar)
    {
        $inject_js = '<script>
(function(){
    var bar = ' . json_encode($notif_bar) . ';
    var ul = document.querySelector("ul.panel__user");
    if(!ul) return;
    var prof = ul.querySelector(".panel__profile-wrap");
    if(prof) {
        var li = document.createElement("li");
        li.style.listStyle = "none";
        li.innerHTML = bar;
        ul.insertBefore(li, prof);
    } else {
        ul.insertAdjacentHTML("beforeend", "<li style=\"list-style:none\">" + bar + "</li>");
    }
})();
</script>';
        $bf_features_js .= $inject_js;

        $poll_js = '<script>
(function(){
    if(!BF_FEATURES.uid) return;
    function bfPollNotifs(){
        var xhr = new XMLHttpRequest();
        xhr.open("GET", "xmlhttp.php?action=bf_notif_poll&my_post_key="+BF_FEATURES.gpk(), true);
        xhr.onload = function(){
            if(xhr.status !== 200) return;
            try {
                var r = JSON.parse(xhr.responseText);
                var c = document.getElementById("bf-credits-count");
                if(c) c.textContent = r.credits_fmt;
                var pb = document.getElementById("bf-pm-badge");
                if(pb){
                    if(r.pms > 0){ pb.textContent = r.pms; pb.style.display = ""; }
                    else { pb.style.display = "none"; }
                }
                var ab = document.getElementById("bf-alert-badge");
                if(ab){
                    if(r.alerts > 0){ ab.textContent = r.alerts; ab.style.display = ""; }
                    else { ab.style.display = "none"; }
                }
            } catch(e){}
        };
        xhr.send();
    }
    setInterval(bfPollNotifs, 30000);
})();
</script>';
        $bf_features_js .= $poll_js;
    }

    $warnings_html = bf_features_get_active_warnings();
    if($warnings_html)
    {
        $inject_warnings = '<script>
(function(){
    var w = ' . json_encode($warnings_html) . ';
    var content = document.getElementById("content");
    if(content) {
        var wrap = content.querySelector(".wrapper");
        if(wrap) { wrap.insertAdjacentHTML("afterbegin", w); }
        else { content.insertAdjacentHTML("afterbegin", w); }
    }
})();
</script>';
        $bf_features_js .= $inject_warnings;
    }

    $footer .= $bf_features_js;

    $current_script = basename($_SERVER['SCRIPT_NAME'] ?? '');
    $nav_map = array(
        'forumdisplay.php' => 'fid',
        'search.php' => 'Search',
        'misc.php' => 'action',
    );
    $active_js = '<script>(function(){var s="' . addslashes($current_script) . '",u=window.location.href,links=document.querySelectorAll(".sidenav__menu > li:not(.sidenav__home):not(.sidenav__extras)");links.forEach(function(li){var a=li.querySelector("a");if(!a)return;var h=a.getAttribute("href")||"";if(s&&h.indexOf(s)!==-1){var match=false;if(s==="forumdisplay.php"){var m1=h.match(/fid=(\d+)/),m2=u.match(/fid=(\d+)/);if(m1&&m2&&m1[1]===m2[1])match=true;}else if(s==="misc.php"){var a1=h.match(/action=([^&]+)/),a2=u.match(/action=([^&]+)/);if(a1&&a2&&a1[1]===a2[1])match=true;else if(!a2&&!a1)match=true;}else{match=true;}if(match)li.classList.add("bf-nav-active");}});})();</script>';
    $footer .= $active_js;

    $dropdown_js = '<script>document.addEventListener("click",function(e){var d=document.getElementById("bf-user-dropdown");if(d&&d.style.display==="block"){var wrap=d.closest(".panel__profile-wrap");if(wrap&&!wrap.contains(e.target)){d.style.display="none";}}});</script>';
    $footer .= $dropdown_js;

}

function bf_features_get_active_warnings()
{
    global $db;
    $now = TIME_NOW;
    $prefix = $db->table_prefix;

    static $warnings_checked = null;
    if($warnings_checked === null) { $warnings_checked = $db->table_exists('bf_warnings'); }
    if(!$warnings_checked) return '';

    $query = $db->query("SELECT * FROM {$prefix}bf_warnings WHERE active=1 AND (expire_date=0 OR expire_date > {$now}) ORDER BY dateline DESC");
    $html = '';
    while($row = $db->fetch_array($query))
    {
        $msg = htmlspecialchars_uni($row['message']);
        $type = htmlspecialchars_uni($row['warning_type']);
        $icon_map = array(
            'info' => 'fa-info-circle',
            'warning' => 'fa-exclamation-triangle',
            'danger' => 'fa-skull-crossbones',
            'success' => 'fa-check-circle',
            'announcement' => 'fa-bullhorn',
        );
        $color_map = array(
            'info' => '#3498db',
            'warning' => '#f39c12',
            'danger' => '#e74c3c',
            'success' => '#2ecc71',
            'announcement' => '#449151',
        );
        $icon = isset($icon_map[$type]) ? $icon_map[$type] : 'fa-info-circle';
        $color = isset($color_map[$type]) ? $color_map[$type] : '#449151';
        $html .= '<div class="bf-warning-banner bf-warning-' . $type . '">'
            . '<i class="fas ' . $icon . '" style="color:' . $color . '"></i>'
            . '<span>' . $msg . '</span>'
            . '</div>';
    }
    return $html;
}

function bf_features_xmlhttp()
{
    global $mybb, $db;

    $action = $mybb->get_input('action');

    if($action === 'bf_like_post')
    {
        if($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

        bf_features_ensure_tables();
        if($mybb->user['uid'] <= 0) { xmlhttp_error('Login required.'); return; }
        if((int)$mybb->user['usergroup'] === 7) { xmlhttp_error('No permission.'); return; }
        verify_post_check($mybb->get_input('my_post_key'));

        $pid = $mybb->get_input('pid', MyBB::INPUT_INT);
        if($pid <= 0) { xmlhttp_error('Invalid post.'); return; }

        $post_check = $db->simple_select('posts', 'pid, uid, visible', "pid={$pid}");
        if($db->num_rows($post_check) == 0) { xmlhttp_error('Post not found.'); return; }
        $post_data = $db->fetch_array($post_check);
        if((int)$post_data['visible'] !== 1) { xmlhttp_error('Post not accessible.'); return; }

        $uid = (int)$mybb->user['uid'];
        $prefix = $db->table_prefix;

        $recent_actions = (int)$db->fetch_field($db->simple_select('bf_post_likes', 'COUNT(*) as cnt', "uid={$uid} AND dateline > " . (TIME_NOW - 10)), 'cnt');
        if($recent_actions >= 15) { xmlhttp_error('You are doing this too fast. Please slow down.'); return; }

        $existing = $db->simple_select('bf_post_likes', 'lid', "pid={$pid} AND uid={$uid}");
        if($db->num_rows($existing) > 0)
        {
            $db->delete_query('bf_post_likes', "pid={$pid} AND uid={$uid}");
            $action_done = 'unliked';
        }
        else
        {
            $db->insert_query('bf_post_likes', array(
                'pid' => $pid,
                'uid' => $uid,
                'dateline' => TIME_NOW,
            ));
            $action_done = 'liked';

            bf_features_check_trophies_likes($uid);
        }

        $count = $db->fetch_field($db->simple_select('bf_post_likes', 'COUNT(*) as cnt', "pid={$pid}"), 'cnt');

        header('Content-Type: application/json');
        echo json_encode(array('action' => $action_done, 'likes' => (int)$count));
        exit;
    }

    if($action === 'bf_give_rep')
    {
        if($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

        bf_features_ensure_tables();
        if($mybb->user['uid'] <= 0) { xmlhttp_error('Login required.'); return; }
        if((int)$mybb->user['usergroup'] === 7) { xmlhttp_error('No permission.'); return; }
        verify_post_check($mybb->get_input('my_post_key'));

        $target_uid = $mybb->get_input('uid', MyBB::INPUT_INT);
        $pid = $mybb->get_input('pid', MyBB::INPUT_INT);
        $value = $mybb->get_input('value', MyBB::INPUT_INT);
        $adduid = (int)$mybb->user['uid'];

        if($target_uid <= 0 || $adduid === $target_uid) { xmlhttp_error('Invalid.'); return; }
        if($value !== 1 && $value !== -1) { xmlhttp_error('Invalid value.'); return; }

        $recent_reps = (int)$db->fetch_field($db->simple_select('bf_reputation', 'COUNT(*) as cnt', "adduid={$adduid} AND dateline > " . (TIME_NOW - 60)), 'cnt');
        if($recent_reps >= 10) { xmlhttp_error('You are giving reputation too fast. Please wait.'); return; }

        $post_check = $db->simple_select('posts', 'pid, uid, visible', "pid={$pid} AND uid={$target_uid}");
        if($db->num_rows($post_check) == 0) { xmlhttp_error('Post not found or user mismatch.'); return; }
        $post_data = $db->fetch_array($post_check);
        if((int)$post_data['visible'] !== 1) { xmlhttp_error('Post not accessible.'); return; }

        $existing = $db->simple_select('bf_reputation', 'rid, reputation', "pid={$pid} AND adduid={$adduid}");
        if($db->num_rows($existing) > 0)
        {
            $ex = $db->fetch_array($existing);
            if((int)$ex['reputation'] === $value)
            {
                $db->delete_query('bf_reputation', "rid=" . (int)$ex['rid']);
            }
            else
            {
                $db->update_query('bf_reputation', array('reputation' => $value, 'dateline' => TIME_NOW), "rid=" . (int)$ex['rid']);
            }
        }
        else
        {
            $db->insert_query('bf_reputation', array(
                'uid' => $target_uid,
                'adduid' => $adduid,
                'pid' => $pid,
                'reputation' => $value,
                'dateline' => TIME_NOW,
            ));
        }

        $total = (int)$db->fetch_field($db->write_query("SELECT COALESCE(SUM(reputation),0) as total FROM {$db->table_prefix}bf_reputation WHERE uid={$target_uid}"), 'total');

        bf_features_check_trophies_rep($target_uid, $total);

        header('Content-Type: application/json');
        echo json_encode(array('total' => $total));
        exit;
    }

    if($action === 'bf_buy_content')
    {
        if($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

        bf_features_ensure_tables();
        if($mybb->user['uid'] <= 0) { xmlhttp_error('Login required.'); return; }
        verify_post_check($mybb->get_input('my_post_key'));

        $pid = $mybb->get_input('pid', MyBB::INPUT_INT);
        $price = $mybb->get_input('price', MyBB::INPUT_INT);
        $uid = (int)$mybb->user['uid'];

        if($pid <= 0 || $price <= 0) { xmlhttp_error('Invalid request.'); return; }

        $post_data = $db->fetch_array($db->simple_select('posts', 'pid, uid, message', "pid={$pid}"));
        if(!$post_data) { xmlhttp_error('Post not found.'); return; }

        $post_author = (int)$post_data['uid'];
        if($uid === $post_author) { xmlhttp_error('You cannot buy your own content.'); return; }

        $already = $db->simple_select('bf_paid_content', 'pcid', "pid={$pid} AND uid={$uid}");
        if($db->num_rows($already) > 0) { xmlhttp_error('You already purchased this content.'); return; }

        if(preg_match('/\[sell=(\d+)\]/si', $post_data['message'], $m))
        {
            $real_price = (int)$m[1];
            if($price !== $real_price) { xmlhttp_error('Price mismatch.'); return; }
        }
        else
        {
            xmlhttp_error('No paid content in this post.'); return;
        }

        $user_points_field = $db->fetch_field($db->simple_select('users', 'newpoints', "uid={$uid}"), 'newpoints');
        $user_points = (float)$user_points_field;

        if($user_points < $real_price) { xmlhttp_error('Not enough credits. You have ' . (int)$user_points . ' but need ' . $real_price . '.'); return; }

        $db->write_query("UPDATE {$db->table_prefix}users SET newpoints = newpoints - {$real_price} WHERE uid = {$uid}");
        $db->write_query("UPDATE {$db->table_prefix}users SET newpoints = newpoints + {$real_price} WHERE uid = {$post_author}");

        $db->insert_query('bf_paid_content', array(
            'pid' => $pid,
            'uid' => $uid,
            'dateline' => TIME_NOW,
        ));

        header('Content-Type: application/json');
        echo json_encode(array('success' => true, 'message' => 'Content purchased! Page will reload.'));
        exit;
    }

    if($action === 'bf_notif_poll')
    {
        if($mybb->user['uid'] <= 0) { http_response_code(403); exit; }
        $uid = (int)$mybb->user['uid'];

        $user_data = $db->fetch_array($db->simple_select('users', 'newpoints, unreadpms', "uid={$uid}"));
        $credits = $user_data ? (int)$user_data['newpoints'] : 0;
        $pms = $user_data ? (int)$user_data['unreadpms'] : 0;
        $alerts = 0;
        if($db->table_exists('alerts'))
        {
            $alerts = (int)$db->fetch_field($db->simple_select('alerts', 'COUNT(*) as cnt', "uid={$uid} AND unread=1"), 'cnt');
        }

        header('Content-Type: application/json');
        echo json_encode(array(
            'credits' => $credits,
            'credits_fmt' => number_format($credits),
            'pms' => $pms,
            'alerts' => $alerts
        ));
        exit;
    }

    if($action === 'bf_admin_edit_user')
    {
        if($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }
        if((int)$mybb->user['usergroup'] !== 4) { xmlhttp_error('Owner only.'); return; }
        verify_post_check($mybb->get_input('my_post_key'));
        bf_features_ensure_tables();

        $target_uid = $mybb->get_input('uid', MyBB::INPUT_INT);
        $field = $mybb->get_input('field');
        $value = $mybb->get_input('value', MyBB::INPUT_INT);
        $prefix = $db->table_prefix;

        if($target_uid <= 0) { xmlhttp_error('Invalid user.'); return; }
        $user = get_user($target_uid);
        if(!$user) { xmlhttp_error('User not found.'); return; }

        $allowed = array('level','xp','reputation','likes','usergroup','credits','delete_posts','reset_password');
        if(!in_array($field, $allowed)) { xmlhttp_error('Invalid field.'); return; }

        $db->write_query("CREATE TABLE IF NOT EXISTS {$prefix}bf_user_overrides (
            oid SERIAL PRIMARY KEY,
            uid INT NOT NULL DEFAULT 0,
            field_name VARCHAR(50) NOT NULL DEFAULT '',
            field_value INT NOT NULL DEFAULT 0,
            UNIQUE(uid, field_name)
        )");

        if($field === 'credits')
        {
            $db->update_query('users', array('newpoints' => max(0, $value)), "uid={$target_uid}");
            header('Content-Type: application/json');
            echo json_encode(array('success' => true, 'message' => 'Credits set to ' . number_format($value) . '.'));
            exit;
        }

        if($field === 'delete_posts')
        {
            require_once MYBB_ROOT . 'inc/class_moderation.php';
            $moderation = new Moderation;

            $thread_query = $db->simple_select('threads', 'tid', "uid={$target_uid}");
            $deleted_threads = 0;
            while($t = $db->fetch_array($thread_query))
            {
                $moderation->delete_thread((int)$t['tid']);
                $deleted_threads++;
            }

            $post_query = $db->simple_select('posts', 'pid', "uid={$target_uid}");
            $deleted_posts = 0;
            while($p = $db->fetch_array($post_query))
            {
                $moderation->delete_post((int)$p['pid']);
                $deleted_posts++;
            }

            header('Content-Type: application/json');
            echo json_encode(array('success' => true, 'message' => "Deleted {$deleted_threads} threads and {$deleted_posts} posts."));
            exit;
        }

        if($field === 'reset_password')
        {
            $new_pass = random_str(12);
            require_once MYBB_ROOT . 'inc/datahandlers/user.php';
            $salt = generate_salt();
            $hashed = md5(md5($salt) . md5($new_pass));
            $db->update_query('users', array(
                'password' => $hashed,
                'salt' => $salt,
                'loginkey' => generate_loginkey()
            ), "uid={$target_uid}");
            header('Content-Type: application/json');
            $masked = substr($new_pass, 0, 3) . str_repeat('*', strlen($new_pass) - 3);
            echo json_encode(array('success' => true, 'message' => 'Password reset. New password: ' . $masked . ' (full password shown once, check server logs)', 'pw' => $new_pass));
            exit;
        }

        if($field === 'usergroup')
        {
            $valid_groups = array(2,3,4,6,7,8,9,10);
            if(!in_array($value, $valid_groups)) { xmlhttp_error('Invalid group.'); return; }
            $db->update_query('users', array('usergroup' => $value), "uid={$target_uid}");
            header('Content-Type: application/json');
            echo json_encode(array('success' => true, 'message' => 'Usergroup updated.'));
            exit;
        }
        elseif($field === 'reputation')
        {
            $db->delete_query('bf_reputation', "uid={$target_uid}");
            if($value != 0)
            {
                $db->insert_query('bf_reputation', array(
                    'uid' => $target_uid,
                    'adduid' => (int)$mybb->user['uid'],
                    'pid' => 0,
                    'reputation' => $value,
                    'dateline' => TIME_NOW,
                    'comments' => 'Set by Owner'
                ));
            }
            header('Content-Type: application/json');
            echo json_encode(array('success' => true, 'message' => 'Reputation set to ' . $value . '.'));
            exit;
        }
        elseif($field === 'likes')
        {
            $current = (int)$db->fetch_field($db->write_query("
                SELECT COUNT(*) as cnt FROM {$prefix}bf_post_likes l
                JOIN {$prefix}posts p ON l.pid = p.pid
                WHERE p.uid = {$target_uid}
            "), 'cnt');
            $diff = $value - $current;
            if($diff > 0)
            {
                for($i = 0; $i < min($diff, 500); $i++)
                {
                    $fake_pid = -1 * (TIME_NOW + $i);
                    $db->insert_query('bf_post_likes', array(
                        'pid' => $fake_pid,
                        'uid' => (int)$mybb->user['uid'],
                        'dateline' => TIME_NOW
                    ));
                    $db->write_query("UPDATE {$prefix}bf_post_likes SET pid = {$fake_pid} WHERE pid = {$fake_pid}");
                }
            }
            $existing = $db->write_query("DELETE FROM {$prefix}bf_user_overrides WHERE uid={$target_uid} AND field_name='likes_override'");
            $db->insert_query('bf_user_overrides', array('uid' => $target_uid, 'field_name' => 'likes_override', 'field_value' => $value));
            header('Content-Type: application/json');
            echo json_encode(array('success' => true, 'message' => 'Likes set to ' . $value . '.'));
            exit;
        }
        else
        {
            $db->write_query("DELETE FROM {$prefix}bf_user_overrides WHERE uid={$target_uid} AND field_name='" . $db->escape_string($field) . "'");
            $db->insert_query('bf_user_overrides', array('uid' => $target_uid, 'field_name' => $field, 'field_value' => $value));
            header('Content-Type: application/json');
            echo json_encode(array('success' => true, 'message' => ucfirst($field) . ' set to ' . $value . '.'));
            exit;
        }
    }

    if($action === 'bf_admin_grant_trophy')
    {
        if($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }
        if((int)$mybb->user['usergroup'] !== 4) { xmlhttp_error('Owner only.'); return; }
        verify_post_check($mybb->get_input('my_post_key'));
        bf_features_ensure_tables();

        $target_uid = $mybb->get_input('uid', MyBB::INPUT_INT);
        $trophy_name = trim($mybb->get_input('trophy_name'));
        $trophy_icon = trim($mybb->get_input('trophy_icon'));
        $trophy_color = trim($mybb->get_input('trophy_color'));

        if($target_uid <= 0 || empty($trophy_name)) { xmlhttp_error('Invalid input.'); return; }

        $allowed_icons = array('fa-trophy','fa-medal','fa-award','fa-star','fa-crown','fa-gem','fa-shield-alt','fa-fire','fa-bolt','fa-pen','fa-comments','fa-skull-crossbones');
        if(!in_array($trophy_icon, $allowed_icons)) $trophy_icon = 'fa-trophy';
        if(!preg_match('/^#[0-9a-fA-F]{6}$/', $trophy_color)) $trophy_color = '#ffd700';

        $trophy_key = 'owner_' . preg_replace('/[^a-z0-9]/', '_', strtolower($trophy_name)) . '_' . TIME_NOW;

        bf_features_award_trophy($target_uid, $trophy_key, $trophy_name, $trophy_icon, $trophy_color);

        header('Content-Type: application/json');
        echo json_encode(array('success' => true, 'message' => 'Trophy "' . htmlspecialchars_uni($trophy_name) . '" granted!'));
        exit;
    }
}

function bf_features_check_trophies_likes($uid)
{
    global $db;
    $count = (int)$db->fetch_field($db->simple_select('bf_post_likes', 'COUNT(*) as cnt', "uid={$uid}"), 'cnt');

    $milestones = array(
        1   => array('first_like', 'First Like', 'fa-heart', '#e74c3c'),
        10  => array('10_likes', 'Popular Poster', 'fa-fire', '#e67e22'),
        50  => array('50_likes', 'Community Star', 'fa-star', '#ffd700'),
        100 => array('100_likes', 'Crowd Favorite', 'fa-crown', '#9b59b6'),
    );

    foreach($milestones as $threshold => $info)
    {
        if($count >= $threshold)
        {
            bf_features_award_trophy($uid, $info[0], $info[1], $info[2], $info[3]);
        }
    }
}

function bf_features_check_trophies_rep($uid, $total_rep)
{
    global $db;

    $milestones = array(
        5   => array('rep_5', 'Respected', 'fa-thumbs-up', '#2ecc71'),
        25  => array('rep_25', 'Well Known', 'fa-award', '#3498db'),
        100 => array('rep_100', 'Legendary Rep', 'fa-gem', '#ffd700'),
    );

    foreach($milestones as $threshold => $info)
    {
        if($total_rep >= $threshold)
        {
            bf_features_award_trophy($uid, $info[0], $info[1], $info[2], $info[3]);
        }
    }
}

function bf_features_check_trophies_posts($uid, $post_count)
{
    $milestones = array(
        1    => array('first_post', 'First Post', 'fa-pencil-alt', '#3498db'),
        10   => array('10_posts', 'Active Member', 'fa-comment-dots', '#2ecc71'),
        50   => array('50_posts', 'Regular', 'fa-comments', '#e67e22'),
        100  => array('100_posts', 'Dedicated', 'fa-trophy', '#ffd700'),
        500  => array('500_posts', 'Forum Veteran', 'fa-medal', '#9b59b6'),
        1000 => array('1000_posts', 'Elite Poster', 'fa-crown', '#e74c3c'),
    );

    foreach($milestones as $threshold => $info)
    {
        if($post_count >= $threshold)
        {
            bf_features_award_trophy($uid, $info[0], $info[1], $info[2], $info[3]);
        }
    }
}

function bf_features_award_trophy($uid, $key, $name, $icon, $color)
{
    global $db;

    $safe_uid = (int)$uid;
    $safe_key = $db->escape_string($key);

    $existing = $db->simple_select('bf_trophies', 'tid', "uid={$safe_uid} AND trophy_key='{$safe_key}'");
    if($db->num_rows($existing) > 0) return;

    $db->insert_query('bf_trophies', array(
        'uid' => $safe_uid,
        'trophy_key' => $key,
        'trophy_name' => $name,
        'trophy_icon' => $icon,
        'trophy_color' => $color,
        'dateline' => TIME_NOW,
    ));
}

function bf_features_parse_bbcode(&$message)
{
    global $mybb, $db;

    bf_features_ensure_tables();

    $tid = 0;
    $pid = 0;
    if(defined('THIS_SCRIPT') && THIS_SCRIPT == 'showthread.php')
    {
        $tid = (int)$mybb->input['tid'];
    }
    if(isset($GLOBALS['post']['tid'])) $tid = (int)$GLOBALS['post']['tid'];
    if(isset($GLOBALS['post']['pid'])) $pid = (int)$GLOBALS['post']['pid'];
    $post_author = isset($GLOBALS['post']['uid']) ? (int)$GLOBALS['post']['uid'] : 0;

    if(preg_match_all('/\[hide=(\d+)\](.*?)\[\/hide\]/si', $message, $hide_paid))
    {
        foreach($hide_paid[0] as $i => $full_match)
        {
            $required_credits = (int)$hide_paid[1][$i];
            $content = $hide_paid[2][$i];
            $can_see = false;

            if($mybb->user['uid'] > 0)
            {
                if((int)$mybb->user['uid'] === $post_author) $can_see = true;
                if(in_array((int)$mybb->user['usergroup'], array(3,4,6))) $can_see = true;
                $user_credits = isset($mybb->user['newpoints']) ? (int)$mybb->user['newpoints'] : 0;
                if(!$can_see && $user_credits >= $required_credits) $can_see = true;
            }

            if($can_see)
            {
                $replacement = '<div class="bf-hidden-content bf-hidden-revealed"><div class="bf-hidden-header"><i class="fas fa-unlock"></i> Hidden Content (Requires ' . number_format($required_credits) . ' CR)</div><div class="bf-hidden-body">' . $content . '</div></div>';
            }
            else
            {
                $user_bal = isset($mybb->user['newpoints']) ? number_format((int)$mybb->user['newpoints']) : '0';
                $replacement = '<div class="bf-hidden-content bf-hidden-locked"><div class="bf-hidden-header"><i class="fas fa-lock"></i> Hidden Content — ' . number_format($required_credits) . ' Credits Required</div><div class="bf-hidden-body">You need at least <strong>' . number_format($required_credits) . ' Credits</strong> to view this content. Your balance: <strong>' . $user_bal . ' CR</strong></div></div>';
            }
            $message = str_replace($full_match, $replacement, $message);
        }
    }

    if(preg_match_all('/\[hide\](.*?)\[\/hide\]/si', $message, $matches))
    {
        foreach($matches[0] as $i => $full_match)
        {
            $content = $matches[1][$i];
            $can_see = false;

            if($mybb->user['uid'] > 0)
            {
                if((int)$mybb->user['uid'] === $post_author) $can_see = true;
                if((int)$mybb->user['usergroup'] == 3 || (int)$mybb->user['usergroup'] == 4 || (int)$mybb->user['usergroup'] == 6) $can_see = true;

                if(!$can_see && $tid > 0)
                {
                    $rq = $db->simple_select('posts', 'pid', "tid={$tid} AND uid=" . (int)$mybb->user['uid'], array('limit' => 1));
                    if($db->num_rows($rq) > 0) $can_see = true;
                }
            }

            if($can_see)
            {
                $replacement = '<div class="bf-hidden-content bf-hidden-revealed"><div class="bf-hidden-header"><i class="fas fa-unlock"></i> Hidden Content</div><div class="bf-hidden-body">' . $content . '</div></div>';
            }
            else
            {
                $replacement = '<div class="bf-hidden-content bf-hidden-locked"><div class="bf-hidden-header"><i class="fas fa-lock"></i> Hidden Content</div><div class="bf-hidden-body">You must reply to this thread to see the hidden content.</div></div>';
            }
            $message = str_replace($full_match, $replacement, $message);
        }
    }

    if(preg_match_all('/\[sell=(\d+)\](.*?)\[\/sell\]/si', $message, $matches))
    {
        foreach($matches[0] as $i => $full_match)
        {
            $price = (int)$matches[1][$i];
            $content = $matches[2][$i];
            $can_see = false;

            if($mybb->user['uid'] > 0)
            {
                if((int)$mybb->user['uid'] === $post_author) $can_see = true;
                if((int)$mybb->user['usergroup'] == 3 || (int)$mybb->user['usergroup'] == 4) $can_see = true;

                if(!$can_see && $pid > 0)
                {
                    $pq = $db->simple_select('bf_paid_content', 'pcid', "pid={$pid} AND uid=" . (int)$mybb->user['uid']);
                    if($db->num_rows($pq) > 0) $can_see = true;
                }
            }

            if($can_see)
            {
                $replacement = '<div class="bf-paid-content bf-paid-revealed"><div class="bf-paid-header"><i class="fas fa-check-circle"></i> Purchased Content (' . $price . ' Credits)</div><div class="bf-paid-body">' . $content . '</div></div>';
            }
            else
            {
                $replacement = '<div class="bf-paid-content bf-paid-locked"><div class="bf-paid-header"><i class="fas fa-coins"></i> Paid Content - ' . $price . ' Credits</div><div class="bf-paid-body"><p>This content costs <strong>' . $price . ' Credits</strong> to view.</p>';
                if($mybb->user['uid'] > 0 && $pid > 0)
                {
                    $replacement .= '<button class="bf-buy-btn" onclick="bfBuyContent(' . $pid . ',' . $price . ')"><i class="fas fa-shopping-cart"></i> Buy Now</button>';
                }
                else
                {
                    $replacement .= '<p><em>Log in to purchase this content.</em></p>';
                }
                $replacement .= '</div></div>';
            }
            $message = str_replace($full_match, $replacement, $message);
        }
    }

    $message = preg_replace('/<img(?![^>]*loading=)([^>]*?)(\s*\/?>)/i', '<img loading="lazy"$1$2', $message);
}

function bf_features_get_role_badge($usergroup, $displaygroup = 0)
{
    $gid = (int)$displaygroup > 0 ? (int)$displaygroup : (int)$usergroup;

    $badges = array(
        4  => array('label' => 'OWNER',         'color' => '#8b0000', 'bg' => 'rgba(139,0,0,0.08)'),
        3  => array('label' => 'ADMINISTRATOR', 'color' => '#cc44cc', 'bg' => 'rgba(204,68,204,0.08)'),
        6  => array('label' => 'MODERATOR',     'color' => '#e67e22', 'bg' => 'rgba(230,126,34,0.08)'),
        10 => array('label' => 'LEGENDARY',     'color' => '#9b59b6', 'bg' => 'rgba(155,89,182,0.08)'),
        9  => array('label' => 'PREMIUM',       'color' => '#e74c3c', 'bg' => 'rgba(231,76,60,0.08)'),
        8  => array('label' => 'VIP',           'color' => '#f1c40f', 'bg' => 'rgba(241,196,15,0.08)'),
        7  => array('label' => 'BANNED',        'color' => '#555555', 'bg' => 'rgba(85,85,85,0.08)'),
        2  => array('label' => 'MEMBER',        'color' => '#4a6a7a', 'bg' => 'rgba(74,106,122,0.08)'),
    );

    if(!isset($badges[$gid])) {
        if($gid == 1 || $gid == 5) return '';
        $gid = 2;
    }

    $b = $badges[$gid];
    global $mybb;
    $rank_images = array(
        4  => 'administrator.png',
        3  => 'administrator.png',
        6  => 'moderator.png',
        10 => 'legendary.png',
        9  => 'premium.png',
        8  => 'vip.png',
        7  => 'banned.png',
        2  => 'member.png',
    );
    $img_file = isset($rank_images[$gid]) ? $rank_images[$gid] : 'member.png';
    return '<img class="bf-role-badge-img" src="' . htmlspecialchars_uni($mybb->settings['bburl']) . '/resources/ranks/' . $img_file . '" alt="' . $b['label'] . '" title="' . $b['label'] . '"/>';
}

function bf_features_postbit(&$post)
{
    global $mybb, $db;

    $pid = (int)$post['pid'];
    $puid = (int)$post['uid'];

    static $loaded_tid = 0;
    static $like_counts = array();
    static $user_likes = array();
    static $rep_totals = array();

    global $tid;
    $thread_id = !empty($tid) ? (int)$tid : (!empty($post['tid']) ? (int)$post['tid'] : 0);

    if($thread_id > 0 && $loaded_tid !== $thread_id)
    {
        $loaded_tid = $thread_id;
        $like_counts = array();
        $user_likes = array();
        $rep_totals = array();
        $prefix = $db->table_prefix;

        $q = $db->write_query("SELECT l.pid, COUNT(*) as cnt FROM {$prefix}bf_post_likes l JOIN {$prefix}posts p ON l.pid = p.pid WHERE p.tid = {$thread_id} GROUP BY l.pid");
        while($r = $db->fetch_array($q)) { $like_counts[(int)$r['pid']] = (int)$r['cnt']; }

        if($mybb->user['uid'] > 0)
        {
            $cuid = (int)$mybb->user['uid'];
            $q2 = $db->write_query("SELECT l.pid FROM {$prefix}bf_post_likes l JOIN {$prefix}posts p ON l.pid = p.pid WHERE p.tid = {$thread_id} AND l.uid = {$cuid}");
            while($r = $db->fetch_array($q2)) { $user_likes[(int)$r['pid']] = true; }
        }

        $q3 = $db->write_query("SELECT r.uid, COALESCE(SUM(r.reputation),0) as total FROM {$prefix}bf_reputation r WHERE r.uid IN (SELECT DISTINCT p2.uid FROM {$prefix}posts p2 WHERE p2.tid = {$thread_id}) GROUP BY r.uid");
        while($r = $db->fetch_array($q3)) { $rep_totals[(int)$r['uid']] = (int)$r['total']; }
    }

    if($thread_id <= 0)
    {
        $like_count = (int)$db->fetch_field($db->simple_select('bf_post_likes', 'COUNT(*) as cnt', "pid={$pid}"), 'cnt');
        $is_liked = false;
        if($mybb->user['uid'] > 0)
        {
            $chk = $db->simple_select('bf_post_likes', 'lid', "pid={$pid} AND uid=" . (int)$mybb->user['uid']);
            $is_liked = $db->num_rows($chk) > 0;
        }
        $rep_total = (int)$db->fetch_field($db->write_query("SELECT COALESCE(SUM(reputation),0) as total FROM {$db->table_prefix}bf_reputation WHERE uid={$puid}"), 'total');
    }
    else
    {
        $like_count = isset($like_counts[$pid]) ? $like_counts[$pid] : 0;
        $is_liked = isset($user_likes[$pid]);
        $rep_total = isset($rep_totals[$puid]) ? $rep_totals[$puid] : 0;
    }
    $rep_class = $rep_total >= 0 ? 'bf-rep-positive' : 'bf-rep-negative';
    $rep_display = ($rep_total >= 0 ? '+' : '') . $rep_total;

    $heart_icon = $is_liked ? 'fas fa-heart' : 'far fa-heart';
    $liked_class = $is_liked ? ' bf-liked' : '';

    $post_count = (int)($post['postnum'] ?? 0);

    $role_badge = bf_features_get_role_badge(
        isset($post['usergroup']) ? $post['usergroup'] : 2,
        isset($post['displaygroup']) ? $post['displaygroup'] : 0
    );
    if($role_badge) {
        $post['usertitle'] = $role_badge;
        $post['userstars'] = '';
        $post['groupimage'] = '';
    }

    $like_btn = '<span class="bf-post-action">
        <a href="javascript:void(0)" onclick="bfLikePost(' . $pid . ')" id="bf-like-btn-' . $pid . '" class="bf-like-btn' . $liked_class . '">
            <i class="' . $heart_icon . '"></i> <span id="bf-like-count-' . $pid . '">' . $like_count . '</span>
        </a>
    </span>';

    $self = ($mybb->user['uid'] > 0 && (int)$mybb->user['uid'] !== $puid);
    $rep_btns = '';
    if($self)
    {
        $rep_btns = '<span class="bf-post-action bf-rep-btns">
            <a href="javascript:void(0)" onclick="bfGiveRep(' . $puid . ',' . $pid . ',1)" class="bf-rep-up" title="Rep+"><i class="fas fa-plus"></i></a>
            <span class="bf-rep-score ' . $rep_class . '" id="bf-rep-count-' . $pid . '">' . $rep_display . '</span>
            <a href="javascript:void(0)" onclick="bfGiveRep(' . $puid . ',' . $pid . ',-1)" class="bf-rep-down" title="Rep-"><i class="fas fa-minus"></i></a>
        </span>';
    }
    else
    {
        $rep_btns = '<span class="bf-post-action bf-rep-btns">
            <span class="bf-rep-score ' . $rep_class . '" id="bf-rep-count-' . $pid . '">' . $rep_display . '</span>
        </span>';
    }

    

    $post['button_rep'] = $like_btn . $rep_btns;
}

function bf_features_profile()
{
    global $db, $mybb, $memprofile, $bf_features_profile_html, $bf_reputation_row, $bf_warning_row;

    bf_features_ensure_tables();

    $uid = (int)$memprofile['uid'];

    $rep_val = (int)$memprofile['reputation'];
    $rep_class = $rep_val > 0 ? 'reputation_positive' : ($rep_val < 0 ? 'reputation_negative' : 'reputation_neutral');
    $bf_reputation_row = '<tr><td class="trow1"><div class="bf-stat-row"><div><span class="profile__info-type">Reputation:</span><strong class="' . $rep_class . '">' . my_number_format($rep_val) . '</strong></div><div><a href="reputation.php?uid=' . $uid . '">Details</a></div></div></td></tr>';

    $warn_pct = round((int)$memprofile['warningpoints'] / max(1, (int)$mybb->settings['maxwarningpoints']) * 100);
    $warn_link = '<a href="warnings.php?uid=' . $uid . '">' . $warn_pct . '%</a>';
    $warn_action = '';
    if($mybb->usergroup['canwarnusers'] == 1) {
        $warn_action = ' <a href="warnings.php?action=warn&amp;uid=' . $uid . '">Warn</a>';
    }
    $bf_warning_row = '<tr><td class="trow1"><div class="bf-stat-row"><div><span class="profile__info-type">Warning Level:</span>' . $warn_link . '</div><div>' . $warn_action . '</div></div></td></tr>';
    $posts = (int)$memprofile['postnum'];
    $threads = (int)$memprofile['threadnum'];
    $regdate = (int)$memprofile['regdate'];
    $days_since = max(1, floor((TIME_NOW - $regdate) / 86400));
    $posts_per_day = round($posts / $days_since, 2);

    $rep_total = (int)$db->fetch_field($db->write_query("SELECT COALESCE(SUM(reputation),0) as total FROM {$db->table_prefix}bf_reputation WHERE uid={$uid}"), 'total');
    $likes_received = (int)$db->fetch_field($db->write_query("
        SELECT COUNT(*) as cnt FROM {$db->table_prefix}bf_post_likes l
        JOIN {$db->table_prefix}posts p ON l.pid = p.pid
        WHERE p.uid = {$uid}
    "), 'cnt');
    $likes_given = (int)$db->fetch_field($db->simple_select('bf_post_likes', 'COUNT(*) as cnt', "uid={$uid}"), 'cnt');

    $trophies_html = '';
    $trophy_count = 0;
    $tq = $db->simple_select('bf_trophies', '*', "uid={$uid}", array('order_by' => 'dateline', 'order_dir' => 'ASC'));
    while($trophy = $db->fetch_array($tq))
    {
        $tname = htmlspecialchars_uni($trophy['trophy_name']);
        $ticon = htmlspecialchars_uni($trophy['trophy_icon']);
        $tcolor = htmlspecialchars_uni($trophy['trophy_color']);
        $trophies_html .= '<div class="bf-trophy-card" style="border-color:' . $tcolor . '">
            <i class="fas ' . $ticon . '" style="color:' . $tcolor . '"></i>
            <span>' . $tname . '</span>
        </div>';
        $trophy_count++;
    }

    $prefix = $db->table_prefix;

    static $overrides_table_checked = false;
    if(!$overrides_table_checked) {
        $overrides_table_checked = true;
        if(!$db->table_exists('bf_user_overrides')) {
            $db->write_query("CREATE TABLE IF NOT EXISTS {$prefix}bf_user_overrides (
                oid SERIAL PRIMARY KEY,
                uid INT NOT NULL DEFAULT 0,
                field_name VARCHAR(50) NOT NULL DEFAULT '',
                field_value INT NOT NULL DEFAULT 0,
                UNIQUE(uid, field_name)
            )");
        }
    }

    $overrides = array();
    $oq = $db->simple_select('bf_user_overrides', '*', "uid={$uid}");
    while($ov = $db->fetch_array($oq))
    {
        $overrides[$ov['field_name']] = (int)$ov['field_value'];
    }

    if(isset($overrides['likes_override']))
    {
        $likes_received = (int)$overrides['likes_override'];
    }

    $xp = $posts * 10 + $rep_total * 5 + $likes_received * 2 + $trophy_count * 20;
    if(isset($overrides['xp']))
    {
        $xp = (int)$overrides['xp'];
    }

    $level = 1;
    $xp_thresholds = array(0,50,150,400,800,1500,3000,6000,12000,25000,50000);
    for($i = count($xp_thresholds)-1; $i >= 0; $i--)
    {
        if($xp >= $xp_thresholds[$i])
        {
            $level = $i + 1;
            break;
        }
    }

    if(isset($overrides['level']))
    {
        $level = max(1, min(11, (int)$overrides['level']));
    }

    $current_threshold = isset($xp_thresholds[$level-1]) ? $xp_thresholds[$level-1] : 0;
    $next_threshold = isset($xp_thresholds[$level]) ? $xp_thresholds[$level] : $xp_thresholds[count($xp_thresholds)-1] * 2;
    $progress = min(100, max(0, round(($xp - $current_threshold) / max(1, $next_threshold - $current_threshold) * 100)));

    $rank_names = array('Newcomer','Beginner','Regular','Active','Dedicated','Veteran','Expert','Master','Elite','Legend','Mythical');
    $rank_name = isset($rank_names[$level-1]) ? $rank_names[$level-1] : 'Mythical';

    $rep_class = $rep_total >= 0 ? 'bf-rep-positive' : 'bf-rep-negative';

    bf_features_media_ensure_table();
    $bburl = htmlspecialchars_uni($mybb->settings['bburl']);

    $banner_media = $db->fetch_array($db->simple_select('bf_user_media', '*', "uid={$uid} AND media_type='banner'"));
    $avatar_media = $db->fetch_array($db->simple_select('bf_user_media', '*', "uid={$uid} AND media_type='avatar'"));

    $profile_role_badge = '';
    if(function_exists('bf_ranks_get_badge'))
    {
        $display_gid = isset($memprofile['displaygroup']) && (int)$memprofile['displaygroup'] > 0 ? (int)$memprofile['displaygroup'] : (int)$memprofile['usergroup'];
        $profile_role_badge = bf_ranks_get_badge($display_gid, 'lg');
    }
    else
    {
        $profile_role_badge = bf_features_get_role_badge(
            (int)$memprofile['usergroup'],
            isset($memprofile['displaygroup']) ? (int)$memprofile['displaygroup'] : 0
        );
    }

    $bf_features_profile_html = '';

    $GLOBALS['bf_profile_role_badge'] = $profile_role_badge;

    if($banner_media) {
        $burl = $bburl . '/uploads/bf_media/' . htmlspecialchars_uni($banner_media['filename']);
        $is_vid = (strpos($banner_media['mime_type'], 'video') !== false);
        if($is_vid) {
            $bf_features_profile_html .= '<div class="bf-profile-banner"><video src="' . $burl . '" autoplay muted loop playsinline></video></div>';
        } else {
            $bf_features_profile_html .= '<div class="bf-profile-banner"><img src="' . $burl . '" alt="Banner" /></div>';
        }
    }

    if($avatar_media) {
        $avurl = $bburl . '/uploads/bf_media/' . htmlspecialchars_uni($avatar_media['filename']);
        $is_av_vid = (strpos($avatar_media['mime_type'], 'video') !== false);
        $bf_features_profile_html .= '<script>document.addEventListener("DOMContentLoaded",function(){
            var tables=document.querySelectorAll("#content .tborder");
            for(var i=0;i<tables.length;i++){
                var cells=tables[i].querySelectorAll("td");
                for(var j=0;j<cells.length;j++){
                    var imgs=cells[j].querySelectorAll("img");
                    for(var k=0;k<imgs.length;k++){
                        if((imgs[k].width>60||imgs[k].naturalWidth>60)&&(imgs[k].src.indexOf("avatar")!==-1||imgs[k].parentElement.tagName==="A")){
                            var parent=imgs[k].parentElement;';
        if($is_av_vid) {
            $bf_features_profile_html .= 'var v=document.createElement("video");v.src="' . $avurl . '";v.autoplay=true;v.muted=true;v.loop=true;v.playsInline=true;v.style.cssText=imgs[k].style.cssText||"";v.style.width=imgs[k].width+"px";v.style.height=imgs[k].height+"px";v.style.objectFit="cover";v.style.borderRadius="10px";v.style.border="2px solid #333";';
        } else {
            $bf_features_profile_html .= 'var v=document.createElement("img");v.src="' . $avurl . '";v.style.cssText=imgs[k].style.cssText||"";v.style.width=imgs[k].width+"px";v.style.height=imgs[k].height+"px";v.style.objectFit="cover";v.style.borderRadius="10px";v.style.border="2px solid #333";';
        }
        $bf_features_profile_html .= 'parent.replaceChild(v,imgs[k]);return;
                        }
                    }
                }
            }
        });</script>';
    }

    $GLOBALS['bf_awards_html'] = '';
    if($trophies_html)
    {
        $GLOBALS['bf_awards_html'] = '
        <tr><td class="trow1">
            <div class="bf-trophy-grid">' . $trophies_html . '</div>
        </td></tr>';
    }
    else
    {
        $GLOBALS['bf_awards_html'] = '
        <tr><td class="trow1">There are currently no awards to display.</td></tr>';
    }

    $GLOBALS['bf_awards_inline'] = $trophies_html ?: '<div class="bf-profile-no-data">No awards yet.</div>';

    $warn_pct2 = round((int)$memprofile['warningpoints'] / max(1, (int)$mybb->settings['maxwarningpoints']) * 100);
    $warn_color = $warn_pct2 > 60 ? '#ef4444' : ($warn_pct2 > 30 ? '#eab308' : '#10b981');
    $GLOBALS['bf_warning_display'] = '<a href="warnings.php?uid=' . $uid . '" style="color:' . $warn_color . ';text-decoration:none;">' . $warn_pct2 . '%</a>';
    if($mybb->usergroup['canwarnusers'] == 1) {
        $GLOBALS['bf_warning_display'] .= ' <a href="warnings.php?action=warn&amp;uid=' . $uid . '" style="font-size:11px;color:var(--text-muted);">(Warn)</a>';
    }

    $GLOBALS['bf_owner_panel_html'] = '';
    if((int)$mybb->user['usergroup'] === 4 && $mybb->user['uid'] > 0)
    {
        $post_key = htmlspecialchars_uni($mybb->post_code);
        $GLOBALS['bf_owner_panel_html'] .= '
        <div class="bf-owner-panel">
            <div class="bf-owner-header" onclick="var b=this.nextElementSibling;var i=this.querySelector(\'.bf-owner-toggle\');if(b.style.display===\'none\'){b.style.display=\'block\';i.className=\'fas fa-chevron-up bf-owner-toggle\';}else{b.style.display=\'none\';i.className=\'fas fa-chevron-down bf-owner-toggle\';}" style="cursor:pointer;">
                <i class="fas fa-user-shield"></i> Owner Admin Panel
                <span class="bf-owner-target">Managing: <strong>' . htmlspecialchars_uni($memprofile['username']) . '</strong> (UID: ' . $uid . ')</span>
                <i class="fas fa-chevron-down bf-owner-toggle"></i>
            </div>
            <div class="bf-owner-body" style="display:none;">
                <div class="bf-owner-section">
                    <div class="bf-owner-section-title"><i class="fas fa-sliders-h"></i> Stats & Level</div>
                    <div class="bf-owner-row">
                        <div class="bf-owner-field">
                            <label>Level</label>
                            <div class="bf-admin-input-row">
                                <input type="number" id="bf_admin_level" min="1" max="11" value="' . $level . '" class="bf-admin-input" />
                                <button onclick="bfAdminUpdate(\'level\', document.getElementById(\'bf_admin_level\').value)" class="bf-owner-save"><i class="fas fa-check"></i></button>
                            </div>
                        </div>
                        <div class="bf-owner-field">
                            <label>XP</label>
                            <div class="bf-admin-input-row">
                                <input type="number" id="bf_admin_xp" min="0" value="' . $xp . '" class="bf-admin-input" />
                                <button onclick="bfAdminUpdate(\'xp\', document.getElementById(\'bf_admin_xp\').value)" class="bf-owner-save"><i class="fas fa-check"></i></button>
                            </div>
                        </div>
                        <div class="bf-owner-field">
                            <label>Reputation</label>
                            <div class="bf-admin-input-row">
                                <input type="number" id="bf_admin_rep" value="' . $rep_total . '" class="bf-admin-input" />
                                <button onclick="bfAdminUpdate(\'reputation\', document.getElementById(\'bf_admin_rep\').value)" class="bf-owner-save"><i class="fas fa-check"></i></button>
                            </div>
                        </div>
                        <div class="bf-owner-field">
                            <label>Likes</label>
                            <div class="bf-admin-input-row">
                                <input type="number" id="bf_admin_likes" min="0" value="' . $likes_received . '" class="bf-admin-input" />
                                <button onclick="bfAdminUpdate(\'likes\', document.getElementById(\'bf_admin_likes\').value)" class="bf-owner-save"><i class="fas fa-check"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="bf-owner-section">
                    <div class="bf-owner-section-title"><i class="fas fa-trophy"></i> Grant Trophy</div>
                    <div class="bf-owner-trophy-row">
                        <input type="text" id="bf_admin_trophy_name" placeholder="Trophy name..." class="bf-admin-input" style="flex:2" />
                        <select id="bf_admin_trophy_icon" class="bf-admin-input bf-owner-select">
                            <option value="fa-trophy">Trophy</option>
                            <option value="fa-medal">Medal</option>
                            <option value="fa-award">Award</option>
                            <option value="fa-star">Star</option>
                            <option value="fa-crown">Crown</option>
                            <option value="fa-gem">Gem</option>
                            <option value="fa-shield-alt">Shield</option>
                            <option value="fa-fire">Fire</option>
                            <option value="fa-bolt">Bolt</option>
                            <option value="fa-pen">Pen</option>
                            <option value="fa-comments">Chat</option>
                            <option value="fa-skull-crossbones">Skull</option>
                        </select>
                        <select id="bf_admin_trophy_color" class="bf-admin-input bf-owner-select">
                            <option value="#ffd700" style="color:#ffd700">Gold</option>
                            <option value="#e74c3c" style="color:#e74c3c">Red</option>
                            <option value="#3498db" style="color:#3498db">Blue</option>
                            <option value="#2ecc71" style="color:#2ecc71">Green</option>
                            <option value="#9b59b6" style="color:#9b59b6">Purple</option>
                            <option value="#e67e22" style="color:#e67e22">Orange</option>
                            <option value="#1abc9c" style="color:#1abc9c">Teal</option>
                            <option value="#c0c0c0" style="color:#c0c0c0">Silver</option>
                        </select>
                        <button onclick="bfAdminGrantTrophy()" class="bf-owner-grant"><i class="fas fa-plus"></i> Grant</button>
                    </div>
                </div>
                <div class="bf-owner-section">
                    <div class="bf-owner-section-title"><i class="fas fa-coins"></i> Credits</div>
                    <div class="bf-admin-input-row">
                        <input type="number" id="bf_admin_credits" min="0" value="' . (isset($memprofile['newpoints']) ? (int)$memprofile['newpoints'] : 0) . '" class="bf-admin-input" style="flex:1" />
                        <button onclick="bfAdminUpdate(\'credits\', document.getElementById(\'bf_admin_credits\').value)" class="bf-owner-save"><i class="fas fa-check"></i></button>
                    </div>
                </div>
                <div class="bf-owner-section">
                    <div class="bf-owner-section-title"><i class="fas fa-users-cog"></i> Usergroup</div>
                    <div class="bf-admin-input-row">
                        <select id="bf_admin_group" class="bf-admin-input" style="flex:1">
                            <option value="2"' . ((int)$memprofile['usergroup']===2?' selected':'') . '>Member</option>
                            <option value="8"' . ((int)$memprofile['usergroup']===8?' selected':'') . '>VIP</option>
                            <option value="9"' . ((int)$memprofile['usergroup']===9?' selected':'') . '>Premium</option>
                            <option value="10"' . ((int)$memprofile['usergroup']===10?' selected':'') . '>Legendary</option>
                            <option value="6"' . ((int)$memprofile['usergroup']===6?' selected':'') . '>Moderator</option>
                            <option value="3"' . ((int)$memprofile['usergroup']===3?' selected':'') . '>Admin</option>
                            <option value="4"' . ((int)$memprofile['usergroup']===4?' selected':'') . '>Owner</option>
                            <option value="7"' . ((int)$memprofile['usergroup']===7?' selected':'') . '>Banned</option>
                        </select>
                        <button onclick="bfAdminUpdate(\'usergroup\', document.getElementById(\'bf_admin_group\').value)" class="bf-owner-save bf-owner-save-danger"><i class="fas fa-check"></i></button>
                    </div>
                </div>
                <div class="bf-owner-section" style="border-color:rgba(220,38,38,0.15)">
                    <div class="bf-owner-section-title" style="color:#f87171"><i class="fas fa-exclamation-triangle"></i> Danger Zone</div>
                    <div style="display:flex;gap:8px;flex-wrap:wrap">
                        <button onclick="if(confirm(\'Ban this user?\'))bfAdminUpdate(\'usergroup\',\'7\')" class="bf-owner-save bf-owner-save-danger" style="flex:1;min-width:100px"><i class="fas fa-ban"></i> Ban User</button>
                        <button onclick="if(confirm(\'Delete ALL posts by this user?\'))bfAdminUpdate(\'delete_posts\',\'1\')" class="bf-owner-save bf-owner-save-danger" style="flex:1;min-width:100px"><i class="fas fa-trash"></i> Delete Posts</button>
                        <button onclick="if(confirm(\'Reset password? A new random password will be generated.\'))bfAdminUpdate(\'reset_password\',\'1\')" class="bf-owner-save bf-owner-save-danger" style="flex:1;min-width:100px"><i class="fas fa-key"></i> Reset Pass</button>
                    </div>
                </div>
            </div>
            <div id="bf_admin_status" class="bf-admin-status"></div>
        </div>
        <script>
        function bfAdminUpdate(field, value) {
            var fd = new FormData();
            fd.append("action", "bf_admin_edit_user");
            fd.append("my_post_key", "' . $post_key . '");
            fd.append("uid", ' . $uid . ');
            fd.append("field", field);
            fd.append("value", value);
            var st = document.getElementById("bf_admin_status");
            st.innerHTML = "<i class=\"fas fa-spinner fa-spin\"></i> Saving...";
            st.className = "bf-admin-status";
            fetch("xmlhttp.php", {method:"POST", body:fd})
            .then(function(r){return r.json()})
            .then(function(d){
                if(d.success){
                    st.innerHTML = "<i class=\"fas fa-check\"></i> " + d.message;
                    st.className = "bf-admin-status bf-admin-ok";
                    setTimeout(function(){ location.reload(); }, 1200);
                } else {
                    st.innerHTML = "<i class=\"fas fa-times\"></i> " + (d.error||"Error");
                    st.className = "bf-admin-status bf-admin-err";
                }
            })
            .catch(function(e){
                st.innerHTML = "<i class=\"fas fa-times\"></i> Request failed";
                st.className = "bf-admin-status bf-admin-err";
            });
        }
        function bfAdminGrantTrophy() {
            var name = document.getElementById("bf_admin_trophy_name").value.trim();
            if(!name){ alert("Enter a trophy name"); return; }
            var fd = new FormData();
            fd.append("action", "bf_admin_grant_trophy");
            fd.append("my_post_key", "' . $post_key . '");
            fd.append("uid", ' . $uid . ');
            fd.append("trophy_name", name);
            fd.append("trophy_icon", document.getElementById("bf_admin_trophy_icon").value);
            fd.append("trophy_color", document.getElementById("bf_admin_trophy_color").value);
            var st = document.getElementById("bf_admin_status");
            st.innerHTML = "<i class=\"fas fa-spinner fa-spin\"></i> Granting trophy...";
            st.className = "bf-admin-status";
            fetch("xmlhttp.php", {method:"POST", body:fd})
            .then(function(r){return r.json()})
            .then(function(d){
                if(d.success){
                    st.innerHTML = "<i class=\"fas fa-check\"></i> " + d.message;
                    st.className = "bf-admin-status bf-admin-ok";
                    setTimeout(function(){ location.reload(); }, 1200);
                } else {
                    st.innerHTML = "<i class=\"fas fa-times\"></i> " + (d.error||"Error");
                    st.className = "bf-admin-status bf-admin-err";
                }
            })
            .catch(function(e){
                st.innerHTML = "<i class=\"fas fa-times\"></i> Request failed";
                st.className = "bf-admin-status bf-admin-err";
            });
        }
        </script>';
    }

}

function bf_features_thread()
{
    global $mybb, $db, $thread;

    bf_features_ensure_tables();

    if(!empty($thread['uid']))
    {
        $author = $db->fetch_array($db->simple_select('users', 'postnum', "uid=" . (int)$thread['uid']));
        if($author)
        {
            bf_features_check_trophies_posts((int)$thread['uid'], (int)$author['postnum']);
        }
    }
}

function bf_features_index()
{
    global $db, $mybb, $boardstats, $index, $footer;

    bf_features_ensure_tables();

    $ads_html = bf_features_get_temp_ads();
    if($ads_html)
    {
        $inject_ads = '<script>
(function(){
    var ads = ' . json_encode($ads_html) . ';
    var tg = document.querySelector(".bf-announcement");
    if(tg) {
        tg.insertAdjacentHTML("beforebegin", ads);
    } else {
        var header = document.getElementById("header");
        if(header) { header.insertAdjacentHTML("afterend", ads); }
        else {
            var content = document.getElementById("content");
            if(content) { content.insertAdjacentHTML("afterbegin", ads); }
        }
    }
})();
</script>';
        $footer .= $inject_ads;
    }

    $forum_icons_js = '<script>
(function(){
    var icons = document.querySelectorAll("td.forum_status, td.forum_on, td.forum_off, td.forum_offlock, td.forum_offlink");
    icons.forEach(function(td){
        if(td.querySelector(".bf-forum-icon")) return;
        var img = td.querySelector("img");
        var isOn = td.classList.contains("forum_on") || (img && img.src && img.src.indexOf("on") > -1);
        var isLock = td.classList.contains("forum_offlock") || (img && img.src && img.src.indexOf("lock") > -1);
        var isLink = td.classList.contains("forum_offlink") || (img && img.src && img.src.indexOf("redirect") > -1);
        var iconClass = "far fa-comment-dots";
        var color = "#555";
        if(isLink) { iconClass = "fas fa-external-link-alt"; color = "#4a7a52"; }
        else if(isLock) { iconClass = "fas fa-lock"; color = "#555"; }
        else if(isOn) { iconClass = "fas fa-comments"; color = "var(--theme-secondary-color,#449151)"; }
        if(img) img.style.display = "none";
        td.insertAdjacentHTML("afterbegin", "<div class=\"bf-forum-icon\" style=\"color:"+color+"\"><i class=\""+iconClass+"\"></i></div>");
    });
})();
</script>';
    $footer .= $forum_icons_js;

    $stats_cache = $mybb->cache->read("stats");
    $total_users = isset($stats_cache['numusers']) ? (int)$stats_cache['numusers'] : 0;
    $total_posts = isset($stats_cache['numposts']) ? (int)$stats_cache['numposts'] : 0;
    $total_threads = isset($stats_cache['numthreads']) ? (int)$stats_cache['numthreads'] : 0;

    $likes_cache = $mybb->cache->read("bf_likes_count");
    if($likes_cache === false || !isset($likes_cache['count']) || ($likes_cache['updated'] ?? 0) < TIME_NOW - 300)
    {
        $total_likes = (int)$db->fetch_field($db->simple_select('bf_post_likes', 'COUNT(*) as cnt'), 'cnt');
        $mybb->cache->update("bf_likes_count", array('count' => $total_likes, 'updated' => TIME_NOW));
    }
    else
    {
        $total_likes = (int)$likes_cache['count'];
    }

    $newest_name = 'N/A';
    $newest_uid = 0;
    if(!empty($stats_cache['lastuid']))
    {
        $newest_uid = (int)$stats_cache['lastuid'];
        $newest_name = htmlspecialchars_uni($stats_cache['lastusername'] ?? 'N/A');
    }

    $top_cache = $mybb->cache->read("bf_top_poster");
    if($top_cache === false || ($top_cache['updated'] ?? 0) < TIME_NOW - 600)
    {
        $top_poster_q = $db->simple_select('users', 'uid, username, postnum', '', array('order_by' => 'postnum', 'order_dir' => 'DESC', 'limit' => 1));
        $top_poster = $db->fetch_array($top_poster_q);
        $top_poster_name = $top_poster ? htmlspecialchars_uni($top_poster['username']) : 'N/A';
        $top_poster_uid = $top_poster ? (int)$top_poster['uid'] : 0;
        $top_poster_count = $top_poster ? (int)$top_poster['postnum'] : 0;
        $mybb->cache->update("bf_top_poster", array('uid' => $top_poster_uid, 'name' => $top_poster_name, 'count' => $top_poster_count, 'updated' => TIME_NOW));
    }
    else
    {
        $top_poster_name = htmlspecialchars_uni($top_cache['name'] ?? 'N/A');
        $top_poster_uid = (int)($top_cache['uid'] ?? 0);
        $top_poster_count = (int)($top_cache['count'] ?? 0);
    }

    $prefix = $db->table_prefix;
    $online_q = $db->query("
        SELECT s.uid, u.username, u.usergroup
        FROM {$prefix}sessions s
        LEFT JOIN {$prefix}users u ON u.uid = s.uid
        WHERE s.time > " . (TIME_NOW - 3600) . "
        AND s.uid > 0
        GROUP BY s.uid, u.username, u.usergroup
        ORDER BY u.username ASC
    ");
    $online_users = array();
    $online_member_count = 0;
    while($ou = $db->fetch_array($online_q)) {
        $online_users[] = $ou;
        $online_member_count++;
    }

    $guest_q = $db->simple_select('sessions', 'COUNT(DISTINCT ip) as cnt', 'uid = 0 AND time > ' . (TIME_NOW - 3600));
    $online_guests = (int)$db->fetch_field($guest_q, 'cnt');
    $online_invisible = 0;
    $online_total = $online_member_count + $online_guests + $online_invisible;

    $user_list_html = '';
    foreach($online_users as $ou) {
        $ou_ug = (int)$ou['usergroup'];
        $ou_name = htmlspecialchars_uni($ou['username']);
        $ou_uid = (int)$ou['uid'];
        $badge = '';
        if($ou_ug === 4) $badge = '<span class="bf-role-badge bf-role-owner">Owner</span>';
        elseif($ou_ug === 3) $badge = '<span class="bf-role-badge bf-role-admin">S.Mod</span>';
        elseif($ou_ug === 6) $badge = '<span class="bf-role-badge bf-role-mod">Mod</span>';
        elseif($ou_ug === 10) $badge = '<span class="bf-role-badge bf-role-legendary">Legendary</span>';
        elseif($ou_ug === 9) $badge = '<span class="bf-role-badge bf-role-premium">Premium</span>';
        elseif($ou_ug === 8) $badge = '<span class="bf-role-badge bf-role-vip">VIP</span>';

        $name_color = '#94a3b8';
        if($ou_ug === 4) $name_color = '#ef4444';
        elseif($ou_ug === 3) $name_color = '#f97316';
        elseif($ou_ug === 6) $name_color = '#22c55e';
        elseif($ou_ug === 8) $name_color = '#eab308';
        elseif($ou_ug === 9) $name_color = '#f43f5e';
        elseif($ou_ug === 10) $name_color = '#a855f7';

        $user_list_html .= $badge . ' <a href="member.php?action=profile&amp;uid=' . $ou_uid . '" style="color:' . $name_color . ';font-weight:600;text-decoration:none;font-size:12px;">' . $ou_name . '</a> ';
    }

    if(empty($user_list_html)) $user_list_html = '<span style="color:var(--text-muted);font-size:12px;">No members currently online.</span>';

    // Board stats are handled by the index_boardstats template - no override needed
}

function bf_features_get_temp_ads()
{
    global $db;
    static $ads_checked = null;
    if($ads_checked === null) { $ads_checked = $db->table_exists('bf_temp_ads'); }
    if(!$ads_checked) return '';

    $prefix = $db->table_prefix;
    $query = $db->query("SELECT * FROM {$prefix}bf_temp_ads WHERE active=1 ORDER BY position ASC, aid ASC");
    $ads = array();
    while($row = $db->fetch_array($query))
    {
        $ads[] = $row;
    }
    if(empty($ads)) return '';

    $items = '';
    foreach($ads as $ad)
    {
        $img = htmlspecialchars_uni($ad['image_url']);
        $link = htmlspecialchars_uni($ad['link_url']);
        $title = htmlspecialchars_uni($ad['title']);
        if($link)
        {
            $items .= '<a href="' . $link . '" target="_blank" rel="noopener" class="bf-ad-item" title="' . $title . '"><img src="' . $img . '" alt="' . $title . '"></a>';
        }
        else
        {
            $items .= '<div class="bf-ad-item" title="' . $title . '"><img src="' . $img . '" alt="' . $title . '"></div>';
        }
    }

    return '<table border="0" cellspacing="0" cellpadding="5" class="tborder" width="100%" style="margin-bottom:10px;">
        <tr><td class="thead" style="text-align:center;font-size:12px;font-weight:600;">Temporary Advertisements</td></tr>
        <tr><td class="trow1" style="padding:8px;"><div class="bf-temp-ads-grid">' . $items . '</div></td></tr>
    </table>';
}

function bf_features_warnings_page()
{
    global $mybb, $db, $headerinclude, $header, $footer;

    if($mybb->get_input('action') !== 'warnings_manage') return;
    if(!in_array((int)$mybb->user['usergroup'], array(3, 4))) { error_no_permission(); exit; }

    $bburl = htmlspecialchars_uni($mybb->settings['bburl']);
    $prefix = $db->table_prefix;

    $db->write_query("CREATE TABLE IF NOT EXISTS {$prefix}bf_warnings (
        wid SERIAL PRIMARY KEY,
        message TEXT NOT NULL DEFAULT '',
        warning_type VARCHAR(20) NOT NULL DEFAULT 'info',
        active INT NOT NULL DEFAULT 1,
        expire_date INT NOT NULL DEFAULT 0,
        dateline INT NOT NULL DEFAULT 0,
        author_uid INT NOT NULL DEFAULT 0
    )");

    if($mybb->get_input('do') === 'add' && $_SERVER['REQUEST_METHOD'] === 'POST')
    {
        verify_post_check($mybb->get_input('my_post_key'));
        $msg = trim($mybb->get_input('message'));
        $type = trim($mybb->get_input('warning_type'));
        $duration = $mybb->get_input('duration', MyBB::INPUT_INT);

        if(empty($msg)) { error("Message cannot be empty."); exit; }

        $valid_types = array('info','warning','danger','success','announcement');
        if(!in_array($type, $valid_types)) $type = 'info';

        $expire = 0;
        if($duration > 0) $expire = TIME_NOW + ($duration * 3600);

        $db->insert_query('bf_warnings', array(
            'message' => $db->escape_string($msg),
            'warning_type' => $db->escape_string($type),
            'active' => 1,
            'expire_date' => $expire,
            'dateline' => TIME_NOW,
            'author_uid' => (int)$mybb->user['uid'],
        ));
        header("Location: {$bburl}/misc.php?action=warnings_manage&done=added");
        exit;
    }

    if($mybb->get_input('do') === 'delete' && $_SERVER['REQUEST_METHOD'] === 'POST')
    {
        verify_post_check($mybb->get_input('my_post_key'));
        $wid = $mybb->get_input('wid', MyBB::INPUT_INT);
        $db->delete_query('bf_warnings', "wid={$wid}");
        header("Location: {$bburl}/misc.php?action=warnings_manage&done=deleted");
        exit;
    }

    if($mybb->get_input('do') === 'toggle' && $_SERVER['REQUEST_METHOD'] === 'POST')
    {
        verify_post_check($mybb->get_input('my_post_key'));
        $wid = $mybb->get_input('wid', MyBB::INPUT_INT);
        $current = $db->fetch_array($db->simple_select('bf_warnings', 'active', "wid={$wid}"));
        if($current)
        {
            $new_active = (int)$current['active'] === 1 ? 0 : 1;
            $db->update_query('bf_warnings', array('active' => $new_active), "wid={$wid}");
        }
        header("Location: {$bburl}/misc.php?action=warnings_manage&done=toggled");
        exit;
    }

    add_breadcrumb("Manage Warnings & Announcements", "misc.php?action=warnings_manage");

    $done_msg = '';
    $d = $mybb->get_input('done');
    if($d === 'added') $done_msg = '<div class="bf-upgrade-success"><i class="fas fa-check-circle"></i> Warning/announcement added successfully.</div>';
    if($d === 'deleted') $done_msg = '<div class="bf-admin-denied"><i class="fas fa-trash-alt"></i> Warning deleted.</div>';
    if($d === 'toggled') $done_msg = '<div class="bf-upgrade-success"><i class="fas fa-toggle-on"></i> Warning status toggled.</div>';

    $rows = '';
    $query = $db->query("SELECT w.*, u.username FROM {$prefix}bf_warnings w LEFT JOIN {$prefix}users u ON u.uid = w.author_uid ORDER BY w.dateline DESC");
    while($row = $db->fetch_array($query))
    {
        $msg = htmlspecialchars_uni($row['message']);
        $type = htmlspecialchars_uni($row['warning_type']);
        $author = htmlspecialchars_uni($row['username'] ?: 'System');
        $date = my_date('M j, Y H:i', (int)$row['dateline']);
        $expire_txt = (int)$row['expire_date'] > 0 ? my_date('M j, Y H:i', (int)$row['expire_date']) : 'Never';
        $status = (int)$row['active'] === 1 ? '<span class="bf-status-active">Active</span>' : '<span class="bf-status-expired">Disabled</span>';
        $toggle_label = (int)$row['active'] === 1 ? 'Disable' : 'Enable';
        $toggle_icon = (int)$row['active'] === 1 ? 'fa-toggle-off' : 'fa-toggle-on';

        $type_badge_colors = array(
            'info' => 'color:#3498db;background:rgba(68,145,81,0.12)',
            'warning' => 'color:#f39c12;background:rgba(243,156,18,0.12)',
            'danger' => 'color:#e74c3c;background:rgba(231,76,60,0.12)',
            'success' => 'color:#2ecc71;background:rgba(46,204,113,0.12)',
            'announcement' => 'color:#449151;background:rgba(68,145,81,0.12)',
        );
        $badge_style = isset($type_badge_colors[$type]) ? $type_badge_colors[$type] : $type_badge_colors['info'];

        $rows .= '<tr>
            <td class="trow1"><span class="bf-type-badge" style="' . $badge_style . '">' . ucfirst($type) . '</span></td>
            <td class="trow1" style="max-width:300px;word-break:break-word">' . $msg . '</td>
            <td class="trow1">' . $author . '</td>
            <td class="trow1">' . $date . '</td>
            <td class="trow1">' . $expire_txt . '</td>
            <td class="trow1">' . $status . '</td>
            <td class="trow1" style="white-space:nowrap">
                <form method="post" action="' . $bburl . '/misc.php?action=warnings_manage&do=toggle" style="display:inline">
                    <input type="hidden" name="wid" value="' . (int)$row['wid'] . '" />
                    <input type="hidden" name="my_post_key" value="' . htmlspecialchars_uni($mybb->post_code) . '" />
                    <button type="submit" class="bf-admin-btn" title="' . $toggle_label . '"><i class="fas ' . $toggle_icon . '"></i></button>
                </form>
                <form method="post" action="' . $bburl . '/misc.php?action=warnings_manage&do=delete" style="display:inline;margin-left:4px" onsubmit="return confirm(\'Delete this warning?\')">
                    <input type="hidden" name="wid" value="' . (int)$row['wid'] . '" />
                    <input type="hidden" name="my_post_key" value="' . htmlspecialchars_uni($mybb->post_code) . '" />
                    <button type="submit" class="bf-admin-btn-red" title="Delete"><i class="fas fa-trash-alt"></i></button>
                </form>
            </td>
        </tr>';
    }

    if(!$rows)
    {
        $rows = '<tr><td class="trow1" colspan="7" style="text-align:center;padding:20px;color:#4a7a52">No warnings or announcements created yet.</td></tr>';
    }

    $page = '<!DOCTYPE html>
<html>
<head>
    <title>Manage Warnings - ' . htmlspecialchars_uni($mybb->settings['bbname']) . '</title>
    ' . $headerinclude . '
</head>
<body>
' . $header . '
<div class="wrapper">
    <div class="container">
        ' . $done_msg . '

        <div class="bf-admin-section">
            <h2><i class="fas fa-plus-circle" style="color:#2ecc71;margin-right:8px"></i> Add New Warning / Announcement</h2>
            <form method="post" action="' . $bburl . '/misc.php?action=warnings_manage&do=add">
                <input type="hidden" name="my_post_key" value="' . htmlspecialchars_uni($mybb->post_code) . '" />
                <div style="display:flex;flex-direction:column;gap:12px">
                    <div>
                        <label style="display:block;font-size:12px;color:#8a8a8a;margin-bottom:4px;font-weight:600"><i class="fas fa-comment-dots" style="margin-right:4px"></i> Message</label>
                        <textarea name="message" rows="3" style="min-height:80px" placeholder="Enter the warning or announcement message..."></textarea>
                    </div>
                    <div style="display:flex;gap:14px;flex-wrap:wrap">
                        <div style="flex:1;min-width:200px">
                            <label style="display:block;font-size:12px;color:#8a8a8a;margin-bottom:4px;font-weight:600"><i class="fas fa-tag" style="margin-right:4px"></i> Type</label>
                            <select name="warning_type" style="width:100%;padding:8px 12px">
                                <option value="info">Info (Blue)</option>
                                <option value="warning">Warning (Orange)</option>
                                <option value="danger">Danger (Red)</option>
                                <option value="success">Success (Green)</option>
                                <option value="announcement">Announcement (Steel)</option>
                            </select>
                        </div>
                        <div style="flex:1;min-width:200px">
                            <label style="display:block;font-size:12px;color:#8a8a8a;margin-bottom:4px;font-weight:600"><i class="fas fa-clock" style="margin-right:4px"></i> Duration (hours, 0 = permanent)</label>
                            <input type="number" name="duration" value="0" min="0" style="width:100%" />
                        </div>
                    </div>
                    <div>
                        <button type="submit" class="bf-plan-btn" style="width:auto;padding:10px 30px"><i class="fas fa-plus" style="margin-right:6px"></i> Add Warning</button>
                    </div>
                </div>
            </form>
        </div>

        <div class="bf-admin-section">
            <h2><i class="fas fa-list" style="color:#449151;margin-right:8px"></i> All Warnings & Announcements</h2>
            <table class="tborder" cellspacing="0" cellpadding="6" style="width:100%">
                <thead><tr>
                    <td class="thead" style="width:90px">Type</td>
                    <td class="thead">Message</td>
                    <td class="thead" style="width:90px">Author</td>
                    <td class="thead" style="width:120px">Created</td>
                    <td class="thead" style="width:120px">Expires</td>
                    <td class="thead" style="width:70px">Status</td>
                    <td class="thead" style="width:80px">Actions</td>
                </tr></thead>
                <tbody>' . $rows . '</tbody>
            </table>
        </div>

        <div class="bf-admin-section" style="background:rgba(0,0,0,0.1);border-color:#b5c4cf">
            <h2 style="font-size:14px"><i class="fas fa-eye" style="color:#4a7a52;margin-right:8px"></i> Preview</h2>
            <p style="color:#4a7a52;font-size:12px;margin-bottom:10px">Active warnings appear as banners at the top of every page:</p>
            <div class="bf-warning-banner bf-warning-info"><i class="fas fa-info-circle" style="color:#3498db"></i><span>Example info banner - visible to all users.</span></div>
            <div class="bf-warning-banner bf-warning-warning"><i class="fas fa-exclamation-triangle" style="color:#f39c12"></i><span>Example warning banner - attention needed.</span></div>
            <div class="bf-warning-banner bf-warning-danger"><i class="fas fa-skull-crossbones" style="color:#e74c3c"></i><span>Example danger banner - critical alert.</span></div>
        </div>
    </div>
</div>
' . $footer . '
</body>
</html>';

    echo $page;
    exit;
}

function bf_features_canary_page()
{
    global $mybb, $headerinclude, $header, $footer;

    if($mybb->get_input('action') !== 'canary') return;

    add_breadcrumb('Canary');

    $canary_file = MYBB_ROOT . 'canary/canary.txt';
    $canary_text = file_exists($canary_file) ? file_get_contents($canary_file) : 'No canary file found.';
    $canary_escaped = htmlspecialchars_uni(trim($canary_text));

    $page = '<html>
<head><title>' . $mybb->settings['bbname'] . ' - Canary</title>' . $headerinclude . '</head>
<body>' . $header . '
<table border="0" cellspacing="0" cellpadding="5" class="tborder" width="100%">
<tr><td class="thead"><strong><i class="fas fa-dove"></i> Warrant Canary</strong></td></tr>
<tr><td class="trow1">
<pre style="white-space:pre-wrap;word-wrap:break-word;font-family:monospace;font-size:13px;color:#c0c0c0;line-height:1.6;margin:0;padding:10px;">' . $canary_escaped . '</pre>
</td></tr>
</table>
' . $footer . '</body></html>';

    output_page($page);
    exit;
}

function bf_features_landing_page()
{
    global $mybb, $db, $headerinclude, $header, $footer;

    if($mybb->get_input('action') !== 'bf_features') return;

    add_breadcrumb("Features", "misc.php?action=bf_features");

    $features = array(
        array('icon' => 'fas fa-trophy',     'color' => '#eab308', 'title' => 'Trophies & Awards',     'desc' => 'Earn trophies and awards for your contributions to the community.'),
        array('icon' => 'fas fa-heart',      'color' => '#ef4444', 'title' => 'Post Likes',            'desc' => 'Like and react to posts. See who appreciated your content.'),
        array('icon' => 'fas fa-star',       'color' => '#f59e0b', 'title' => 'Reputation System',     'desc' => 'Build your reputation through quality contributions.'),
        array('icon' => 'fas fa-chart-line', 'color' => '#10b981', 'title' => 'XP & Leveling',         'desc' => 'Gain experience points and level up your profile.'),
        array('icon' => 'fas fa-crown',      'color' => '#a855f7', 'title' => 'Premium Ranks',         'desc' => 'Unlock exclusive badges and perks with VIP, Premium, or Legendary.'),
        array('icon' => 'fas fa-at',         'color' => 'hsl(208,43%,26%)', 'title' => '@Mentions',             'desc' => 'Tag other users in your posts to get their attention.'),
        array('icon' => 'fas fa-image',      'color' => '#06b6d4', 'title' => 'Custom Media',          'desc' => 'Upload custom avatars and profile banners.'),
        array('icon' => 'fas fa-users',      'color' => '#8b5cf6', 'title' => 'Referral System',       'desc' => 'Invite friends and earn rewards for every referral.'),
        array('icon' => 'fas fa-shield-alt', 'color' => '#f97316', 'title' => 'Warning System',        'desc' => 'Transparent moderation with a clear warning system.'),
        array('icon' => 'fas fa-dove',       'color' => '#10b981', 'title' => 'Warrant Canary',        'desc' => 'Transparency report for law enforcement requests.'),
        array('icon' => 'fas fa-comments',   'color' => 'hsl(208,43%,26%)', 'title' => 'Shoutbox',              'desc' => 'Real-time chat with other community members.'),
        array('icon' => 'fas fa-dice',       'color' => '#eab308', 'title' => 'Casino Games',          'desc' => 'Play games and have fun with your forum currency.'),
    );

    $cards = '';
    foreach($features as $f)
    {
        $hex = ltrim($f['color'], '#');
        $r = hexdec(substr($hex,0,2));
        $g = hexdec(substr($hex,2,2));
        $b = hexdec(substr($hex,4,2));
        $bg_rgba = "rgba({$r},{$g},{$b},0.1)";

        $cards .= '<div style="background:var(--bg-2);border:1px solid var(--border-1);border-radius:8px;padding:24px;">
            <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">
                <div style="width:40px;height:40px;border-radius:8px;background:'.$bg_rgba.';display:flex;align-items:center;justify-content:center;">
                    <i class="' . $f['icon'] . '" style="color:' . $f['color'] . ';font-size:16px;"></i>
                </div>
                <h3 style="margin:0;font-size:15px;font-weight:700;color:var(--main-text-color);">' . $f['title'] . '</h3>
            </div>
            <p style="margin:0;font-size:13px;color:var(--text-muted);line-height:1.5;">' . $f['desc'] . '</p>
        </div>';
    }

    $page = <<<HTML
<html>
<head>
<title>{$mybb->settings['bbname']} - Features</title>
{$headerinclude}
</head>
<body>
{$header}
<div style="text-align:center;padding:40px 0 30px;">
<h1 style="font-size:28px;font-weight:800;color:var(--main-text-color);margin:0 0 8px;"><i class="fas fa-gem" style="color:var(--theme-primary-color);margin-right:8px;"></i>Forum Features</h1>
<p style="color:var(--text-muted);font-size:14px;margin:0;">Everything that makes LeaksForums stand out.</p>
</div>
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px;margin-bottom:30px;">
{$cards}
</div>
{$footer}
</body>
</html>
HTML;

    output_page($page);
    exit;
}

function bf_features_misc()
{
    global $mybb, $db, $headerinclude, $header, $footer;

    if($mybb->get_input('action') !== 'trophies') return;

    bf_features_ensure_tables();

    $uid = $mybb->get_input('uid', MyBB::INPUT_INT);
    if($uid <= 0 && $mybb->user['uid'] > 0) $uid = (int)$mybb->user['uid'];
    if($uid <= 0) return;

    $user = get_user($uid);
    if(!$user) return;

    $username = htmlspecialchars_uni($user['username']);

    add_breadcrumb("{$username}'s Trophies");

    $trophies_html = '';
    $tq = $db->simple_select('bf_trophies', '*', "uid={$uid}", array('order_by' => 'dateline', 'order_dir' => 'ASC'));
    while($trophy = $db->fetch_array($tq))
    {
        $tname = htmlspecialchars_uni($trophy['trophy_name']);
        $ticon = htmlspecialchars_uni($trophy['trophy_icon']);
        $tcolor = htmlspecialchars_uni($trophy['trophy_color']);
        $date = my_date('M j, Y', (int)$trophy['dateline']);
        $trophies_html .= '<div class="bf-trophy-card-full" style="border-color:' . $tcolor . '">
            <div class="bf-trophy-icon-big" style="color:' . $tcolor . '"><i class="fas ' . $ticon . '"></i></div>
            <div class="bf-trophy-details">
                <strong>' . $tname . '</strong>
                <span class="bf-trophy-date">Earned ' . $date . '</span>
            </div>
        </div>';
    }

    if(!$trophies_html)
    {
        $trophies_html = '<div style="text-align:center;padding:30px;color:#4a7a52">No trophies earned yet.</div>';
    }

    $page = '<!DOCTYPE html><html><head><title>' . $username . '\'s Trophies</title>' . $headerinclude . '</head><body>' . $header . '
    <div class="wrapper"><div class="container">
        <table border="0" cellspacing="1" cellpadding="5" class="tborder" style="width:100%">
        <tr><td class="thead"><strong><i class="fas fa-trophy" style="margin-right:6px;color:#ffd700"></i> ' . $username . '\'s Trophies</strong></td></tr>
        <tr><td class="trow1"><div class="bf-trophies-page">' . $trophies_html . '</div></td></tr>
        </table>
    </div></div>
    ' . $footer . '</body></html>';

    echo $page;
    exit;
}

function bf_features_ads_page()
{
    global $mybb, $db, $headerinclude, $header, $footer;

    if($mybb->get_input('action') !== 'manage_ads') return;
    if(!in_array((int)$mybb->user['usergroup'], array(3, 4))) { error_no_permission(); exit; }

    $bburl = htmlspecialchars_uni($mybb->settings['bburl']);
    $prefix = $db->table_prefix;

    $db->write_query("CREATE TABLE IF NOT EXISTS {$prefix}bf_temp_ads (
        aid SERIAL PRIMARY KEY,
        title VARCHAR(255) NOT NULL DEFAULT '',
        image_url TEXT NOT NULL DEFAULT '',
        link_url TEXT NOT NULL DEFAULT '',
        position INT NOT NULL DEFAULT 0,
        active INT NOT NULL DEFAULT 1,
        dateline INT NOT NULL DEFAULT 0
    )");

    if($mybb->request_method === 'post')
    {
        verify_post_check($mybb->get_input('my_post_key'));
        $do = $mybb->get_input('do');

        if($do === 'add')
        {
            $title = $db->escape_string($mybb->get_input('ad_title'));
            $raw_image = $mybb->get_input('ad_image');
            $raw_link = $mybb->get_input('ad_link');
            if(!preg_match('#^https?://#i', $raw_image)) { error('Invalid image URL. Must start with http:// or https://'); }
            if(!empty($raw_link) && !preg_match('#^https?://#i', $raw_link)) { error('Invalid link URL. Must start with http:// or https://'); }
            $image_url = $db->escape_string($raw_image);
            $link_url = $db->escape_string($raw_link);
            $position = (int)$mybb->get_input('ad_position');
            $db->insert_query('bf_temp_ads', array(
                'title' => $title,
                'image_url' => $image_url,
                'link_url' => $link_url,
                'position' => $position,
                'active' => 1,
                'dateline' => TIME_NOW
            ));
        }
        elseif($do === 'toggle')
        {
            $aid = (int)$mybb->get_input('aid');
            $ad = $db->fetch_array($db->simple_select('bf_temp_ads', '*', "aid={$aid}"));
            if($ad)
            {
                $new_active = $ad['active'] ? 0 : 1;
                $db->update_query('bf_temp_ads', array('active' => $new_active), "aid={$aid}");
            }
        }
        elseif($do === 'delete')
        {
            $aid = (int)$mybb->get_input('aid');
            $db->delete_query('bf_temp_ads', "aid={$aid}");
        }
        elseif($do === 'update_position')
        {
            $aid = (int)$mybb->get_input('aid');
            $position = (int)$mybb->get_input('ad_position');
            $db->update_query('bf_temp_ads', array('position' => $position), "aid={$aid}");
        }

        header("Location: {$bburl}/misc.php?action=manage_ads");
        exit;
    }

    $post_key = htmlspecialchars_uni($mybb->post_code);
    add_breadcrumb('Manage Advertisements');

    $ads_list = '';
    $query = $db->simple_select('bf_temp_ads', '*', '', array('order_by' => 'position ASC, aid', 'order_dir' => 'ASC'));
    while($ad = $db->fetch_array($query))
    {
        $aid = (int)$ad['aid'];
        $title = htmlspecialchars_uni($ad['title']);
        $img = htmlspecialchars_uni($ad['image_url']);
        $link = htmlspecialchars_uni($ad['link_url']);
        $pos = (int)$ad['position'];
        $active = (int)$ad['active'];
        $status_label = $active ? '<span style="color:#2ecc71;font-weight:600">Active</span>' : '<span style="color:#e74c3c;font-weight:600">Inactive</span>';
        $toggle_label = $active ? 'Deactivate' : 'Activate';
        $date = my_date('M j, Y g:i A', (int)$ad['dateline']);

        $ads_list .= '<tr>
            <td class="trow1" style="text-align:center">' . $aid . '</td>
            <td class="trow1"><strong>' . $title . '</strong><br><small style="color:#4a7a52">' . $date . '</small></td>
            <td class="trow1" style="text-align:center"><img src="' . $img . '" style="max-width:200px;max-height:60px;border-radius:3px;border:1px solid #b5c4cf"></td>
            <td class="trow1" style="text-align:center">' . $status_label . '</td>
            <td class="trow1" style="text-align:center">
                <form method="post" action="misc.php?action=manage_ads" style="display:inline">
                    <input type="hidden" name="my_post_key" value="' . $post_key . '">
                    <input type="hidden" name="do" value="update_position">
                    <input type="hidden" name="aid" value="' . $aid . '">
                    <input type="number" name="ad_position" value="' . $pos . '" style="width:50px;background:#f0f0f0;border:1px solid #b5c4cf;color:#333;border-radius:3px;padding:2px 4px;text-align:center">
                    <button type="submit" class="bf-btn-sm" title="Update position"><i class="fas fa-check"></i></button>
                </form>
            </td>
            <td class="trow1" style="text-align:center">
                <form method="post" action="misc.php?action=manage_ads" style="display:inline;margin-right:4px">
                    <input type="hidden" name="my_post_key" value="' . $post_key . '">
                    <input type="hidden" name="do" value="toggle">
                    <input type="hidden" name="aid" value="' . $aid . '">
                    <button type="submit" class="bf-btn-sm">' . $toggle_label . '</button>
                </form>
                <form method="post" action="misc.php?action=manage_ads" style="display:inline" onsubmit="return confirm(\'Delete this ad?\')">
                    <input type="hidden" name="my_post_key" value="' . $post_key . '">
                    <input type="hidden" name="do" value="delete">
                    <input type="hidden" name="aid" value="' . $aid . '">
                    <button type="submit" class="bf-btn-sm" style="background:#e74c3c"><i class="fas fa-trash"></i></button>
                </form>
            </td>
        </tr>';
    }

    if(!$ads_list)
    {
        $ads_list = '<tr><td class="trow1" colspan="6" style="text-align:center;padding:20px;color:#4a7a52">No advertisements yet. Add one below.</td></tr>';
    }

    $page = '<!DOCTYPE html><html><head><title>Manage Advertisements</title>' . $headerinclude . '</head><body>' . $header . '
    <div class="wrapper"><div class="container">
        <table border="0" cellspacing="1" cellpadding="5" class="tborder" style="width:100%">
        <tr><td class="thead" colspan="6"><strong><i class="fas fa-ad" style="margin-right:6px"></i> Manage Temporary Advertisements</strong></td></tr>
        <tr>
            <td class="tcat" style="text-align:center;width:40px"><strong>#</strong></td>
            <td class="tcat"><strong>Title</strong></td>
            <td class="tcat" style="text-align:center"><strong>Preview</strong></td>
            <td class="tcat" style="text-align:center;width:80px"><strong>Status</strong></td>
            <td class="tcat" style="text-align:center;width:80px"><strong>Order</strong></td>
            <td class="tcat" style="text-align:center;width:140px"><strong>Actions</strong></td>
        </tr>
        ' . $ads_list . '
        </table>

        <br>
        <table border="0" cellspacing="1" cellpadding="5" class="tborder" style="width:100%">
        <tr><td class="thead" colspan="2"><strong><i class="fas fa-plus-circle" style="margin-right:6px"></i> Add New Advertisement</strong></td></tr>
        <tr>
            <td class="trow1" colspan="2">
                <form method="post" action="misc.php?action=manage_ads">
                    <input type="hidden" name="my_post_key" value="' . $post_key . '">
                    <input type="hidden" name="do" value="add">
                    <div style="display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end">
                        <div style="flex:1;min-width:150px">
                            <label style="display:block;color:#666;font-size:11px;margin-bottom:3px">Title</label>
                            <input type="text" name="ad_title" required placeholder="Ad title..." style="width:100%;background:#f0f0f0;border:1px solid #b5c4cf;color:#333;padding:6px 10px;border-radius:3px">
                        </div>
                        <div style="flex:2;min-width:200px">
                            <label style="display:block;color:#666;font-size:11px;margin-bottom:3px">Image URL</label>
                            <input type="url" name="ad_image" required placeholder="https://example.com/banner.png" style="width:100%;background:#f0f0f0;border:1px solid #b5c4cf;color:#333;padding:6px 10px;border-radius:3px">
                        </div>
                        <div style="flex:2;min-width:200px">
                            <label style="display:block;color:#666;font-size:11px;margin-bottom:3px">Link URL (optional)</label>
                            <input type="url" name="ad_link" placeholder="https://example.com" style="width:100%;background:#f0f0f0;border:1px solid #b5c4cf;color:#333;padding:6px 10px;border-radius:3px">
                        </div>
                        <div style="width:70px">
                            <label style="display:block;color:#666;font-size:11px;margin-bottom:3px">Order</label>
                            <input type="number" name="ad_position" value="0" style="width:100%;background:#f0f0f0;border:1px solid #b5c4cf;color:#333;padding:6px 10px;border-radius:3px;text-align:center">
                        </div>
                        <div>
                            <button type="submit" class="bf-btn-primary"><i class="fas fa-plus"></i> Add Ad</button>
                        </div>
                    </div>
                </form>
            </td>
        </tr>
        </table>

        <div style="margin-top:15px;padding:12px;background:#e8f0f8;border:1px solid #b5c4cf;border-radius:0;color:#666;font-size:12px">
            <i class="fas fa-info-circle" style="margin-right:6px;color:var(--theme-secondary-color,#449151)"></i>
            <strong>Tips:</strong> Ads appear in the "Temporary Advertisements" section on the forum index page.
            Images should be banner-sized (recommended: 300x100 or 468x60). Lower order numbers appear first.
            This page is accessible at <code style="background:#0d1117;padding:2px 5px;border-radius:3px">/misc.php?action=manage_ads</code>
        </div>
    </div></div>
    ' . $footer . '</body></html>';

    echo $page;
    exit;
}

function bf_features_ensure_analytics_tables()
{
    global $db;
    static $done = false;
    if($done) return;
    $done = true;
    $prefix = $db->table_prefix;
    if(!$db->table_exists('bf_visits'))
    {
        $db->write_query("CREATE TABLE {$prefix}bf_visits (
            vid SERIAL PRIMARY KEY,
            uid INT NOT NULL DEFAULT 0,
            ip VARCHAR(45) NOT NULL DEFAULT '',
            page VARCHAR(500) NOT NULL DEFAULT '',
            user_agent VARCHAR(500) NOT NULL DEFAULT '',
            referrer VARCHAR(500) NOT NULL DEFAULT '',
            dateline INT NOT NULL DEFAULT 0
        )");
    }
    if(!$db->table_exists('bf_referral_codes'))
    {
        $db->write_query("CREATE TABLE {$prefix}bf_referral_codes (
            rcid SERIAL PRIMARY KEY,
            uid INT NOT NULL DEFAULT 0,
            code VARCHAR(20) NOT NULL DEFAULT '',
            dateline INT NOT NULL DEFAULT 0
        )");
        $db->write_query("CREATE UNIQUE INDEX idx_bf_refcode_uid ON {$prefix}bf_referral_codes (uid)");
        $db->write_query("CREATE UNIQUE INDEX idx_bf_refcode_code ON {$prefix}bf_referral_codes (code)");
    }
    if(!$db->table_exists('bf_referral_clicks'))
    {
        $db->write_query("CREATE TABLE {$prefix}bf_referral_clicks (
            ckid SERIAL PRIMARY KEY,
            ref_uid INT NOT NULL DEFAULT 0,
            code VARCHAR(20) NOT NULL DEFAULT '',
            visitor_ip VARCHAR(45) NOT NULL DEFAULT '',
            visitor_uid INT NOT NULL DEFAULT 0,
            dateline INT NOT NULL DEFAULT 0
        )");
    }
}

function bf_features_media_ensure_table()
{
    global $db;
    static $done = false;
    if($done) return;
    $done = true;
    $prefix = $db->table_prefix;
    $db->write_query("CREATE TABLE IF NOT EXISTS {$prefix}bf_user_media (
        mid SERIAL PRIMARY KEY,
        uid INT NOT NULL DEFAULT 0,
        media_type VARCHAR(20) NOT NULL DEFAULT 'avatar',
        filename VARCHAR(255) NOT NULL DEFAULT '',
        original_name VARCHAR(255) NOT NULL DEFAULT '',
        mime_type VARCHAR(50) NOT NULL DEFAULT '',
        file_size INT NOT NULL DEFAULT 0,
        dateline INT NOT NULL DEFAULT 0,
        UNIQUE(uid, media_type)
    )");
}

function bf_features_media_xmlhttp()
{
    global $mybb, $db;

    $action = $mybb->get_input('action');

    if($action === 'bf_media_upload')
    {
        if($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }
        if($mybb->user['uid'] <= 0) { xmlhttp_error('Login required.'); return; }
        if((int)$mybb->user['usergroup'] === 7 || (int)$mybb->user['usergroup'] === 5) { xmlhttp_error('No permission.'); return; }
        verify_post_check($mybb->get_input('my_post_key'));

        bf_features_media_ensure_table();

        $uid = (int)$mybb->user['uid'];
        $media_type = trim($mybb->get_input('media_type'));

        if($media_type !== 'avatar' && $media_type !== 'banner') { xmlhttp_error('Invalid media type.'); return; }

        $rl_key = sys_get_temp_dir() . '/bf_upload_rl_' . $uid;
        $rl = @json_decode(@file_get_contents($rl_key), true);
        if(!$rl || $rl['reset'] < TIME_NOW) { $rl = array('count' => 0, 'reset' => TIME_NOW + 300); }
        $rl['count']++;
        @file_put_contents($rl_key, json_encode($rl));
        if($rl['count'] > 10) { xmlhttp_error('Upload rate limit reached. Please wait.'); return; }

        if(!isset($_FILES['media_file']) || $_FILES['media_file']['error'] !== UPLOAD_ERR_OK) { xmlhttp_error('No file uploaded or upload error.'); return; }

        $file = $_FILES['media_file'];
        $max_size = ($media_type === 'avatar') ? 5 * 1024 * 1024 : 10 * 1024 * 1024;
        if($file['size'] > $max_size) { xmlhttp_error('File too large. Max ' . ($max_size / 1024 / 1024) . 'MB.'); return; }

        $allowed_video = array('video/mp4', 'video/webm');
        $allowed_image = array('image/jpeg', 'image/png', 'image/gif', 'image/webp');
        $allowed = array_merge($allowed_video, $allowed_image);

        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $real_mime = finfo_file($finfo, $file['tmp_name']);
        finfo_close($finfo);

        if(!in_array($real_mime, $allowed)) { xmlhttp_error('Invalid file type. Allowed: MP4, WebM, JPG, PNG, GIF, WebP.'); return; }

        $ext_map = array('video/mp4' => 'mp4', 'video/webm' => 'webm', 'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp');
        $ext = isset($ext_map[$real_mime]) ? $ext_map[$real_mime] : 'bin';

        $upload_dir = MYBB_ROOT . 'uploads/bf_media';
        if(!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

        $safe_name = 'bf_' . $media_type . '_' . $uid . '_' . TIME_NOW . '.' . $ext;

        $old = $db->simple_select('bf_user_media', '*', "uid={$uid} AND media_type='" . $db->escape_string($media_type) . "'");
        if($old_row = $db->fetch_array($old))
        {
            $old_filename = basename($old_row['filename']);
            $old_path = $upload_dir . '/' . $old_filename;
            if(strpos(realpath($old_path), realpath($upload_dir)) === 0 && file_exists($old_path)) @unlink($old_path);
            $db->delete_query('bf_user_media', "mid=" . (int)$old_row['mid']);
        }

        if(!move_uploaded_file($file['tmp_name'], $upload_dir . '/' . $safe_name)) { xmlhttp_error('Failed to save file.'); return; }

        $db->insert_query('bf_user_media', array(
            'uid' => $uid,
            'media_type' => $db->escape_string($media_type),
            'filename' => $db->escape_string($safe_name),
            'original_name' => $db->escape_string(basename($file['name'])),
            'mime_type' => $db->escape_string($real_mime),
            'file_size' => (int)$file['size'],
            'dateline' => TIME_NOW,
        ));

        header('Content-Type: application/json');
        echo json_encode(array('success' => true, 'filename' => $safe_name, 'mime' => $real_mime));
        exit;
    }

    if($action === 'bf_media_delete')
    {
        if($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }
        if($mybb->user['uid'] <= 0) { xmlhttp_error('Login required.'); return; }
        verify_post_check($mybb->get_input('my_post_key'));

        bf_features_media_ensure_table();

        $uid = (int)$mybb->user['uid'];
        $media_type = trim($mybb->get_input('media_type'));
        if($media_type !== 'avatar' && $media_type !== 'banner') { xmlhttp_error('Invalid.'); return; }

        $row = $db->fetch_array($db->simple_select('bf_user_media', '*', "uid={$uid} AND media_type='" . $db->escape_string($media_type) . "'"));
        if($row)
        {
            $safe_filename = basename($row['filename']);
            $path = MYBB_ROOT . 'uploads/bf_media/' . $safe_filename;
            $base_dir = realpath(MYBB_ROOT . 'uploads/bf_media');
            if($base_dir && strpos(realpath($path), $base_dir) === 0 && file_exists($path)) @unlink($path);
            $db->delete_query('bf_user_media', "mid=" . (int)$row['mid']);
        }

        header('Content-Type: application/json');
        echo json_encode(array('success' => true));
        exit;
    }
}

function bf_features_media_page()
{
    global $mybb, $db, $header, $headerinclude, $footer;

    if($mybb->get_input('action') !== 'bf_media_settings') return;
    if($mybb->user['uid'] <= 0) { error_no_permission(); return; }

    bf_features_media_ensure_table();

    $uid = (int)$mybb->user['uid'];
    $post_key = htmlspecialchars_uni($mybb->post_code);
    $bburl = htmlspecialchars_uni($mybb->settings['bburl']);

    $avatar_media = $db->fetch_array($db->simple_select('bf_user_media', '*', "uid={$uid} AND media_type='avatar'"));
    $banner_media = $db->fetch_array($db->simple_select('bf_user_media', '*', "uid={$uid} AND media_type='banner'"));

    $avatar_preview = '';
    if($avatar_media) {
        $is_video = (strpos($avatar_media['mime_type'], 'video') !== false);
        $url = $bburl . '/uploads/bf_media/' . htmlspecialchars_uni($avatar_media['filename']);
        if($is_video) {
            $avatar_preview = '<video src="' . $url . '" autoplay muted loop playsinline style="width:120px;height:120px;object-fit:cover;border-radius:10px;border:2px solid #333"></video>';
        } else {
            $avatar_preview = '<img src="' . $url . '" style="width:120px;height:120px;object-fit:cover;border-radius:10px;border:2px solid #333" />';
        }
    }

    $banner_preview = '';
    if($banner_media) {
        $is_video = (strpos($banner_media['mime_type'], 'video') !== false);
        $url = $bburl . '/uploads/bf_media/' . htmlspecialchars_uni($banner_media['filename']);
        if($is_video) {
            $banner_preview = '<video src="' . $url . '" autoplay muted loop playsinline style="width:100%;max-height:200px;object-fit:cover;border-radius:6px;border:1px solid #b5c4cf"></video>';
        } else {
            $banner_preview = '<img src="' . $url . '" style="width:100%;max-height:200px;object-fit:cover;border-radius:6px;border:1px solid #b5c4cf" />';
        }
    }

    $page = '<!DOCTYPE html><html><head><title>Media Settings - LeaksForums</title>';
    $page .= $headerinclude;
    $page .= '<style>
.bf-media-wrap{max-width:700px;margin:0 auto 20px}
.bf-media-section{background:#f5f5f5;border:1px solid #b5c4cf;border-radius:8px;margin-bottom:16px;overflow:hidden}
.bf-media-section-header{padding:12px 18px;font-size:14px;font-weight:700;color:#333;border-bottom:1px solid #ddd;display:flex;align-items:center;gap:8px}
.bf-media-section-header i{color:var(--theme-secondary-color);font-size:16px}
.bf-media-section-body{padding:18px}
.bf-media-preview{margin-bottom:14px;text-align:center}
.bf-media-upload-area{border:2px dashed #333;border-radius:6px;padding:20px;text-align:center;cursor:pointer;transition:all 200ms;color:#4a7a52;font-size:13px}
.bf-media-upload-area:hover{border-color:#449151;color:#449151;background:rgba(68,145,81,0.04)}
.bf-media-upload-area i{font-size:28px;display:block;margin-bottom:8px}
.bf-media-info{font-size:11px;color:#4a7a52;margin-top:8px}
.bf-media-actions{display:flex;gap:8px;margin-top:12px;justify-content:center}
.bf-media-del{background:rgba(231,76,60,0.1);border:1px solid rgba(231,76,60,0.3);color:#e74c3c;padding:6px 14px;border-radius:0;font-size:12px;cursor:pointer;transition:all 200ms}.bf-media-del:hover{background:rgba(231,76,60,0.2)}
.bf-media-status{padding:8px 14px;font-size:12px;text-align:center;display:none;border-radius:0;margin-top:10px}
.bf-media-ok{display:block;background:rgba(46,204,113,0.1);border:1px solid rgba(46,204,113,0.2);color:#2ecc71}
.bf-media-err{display:block;background:rgba(231,76,60,0.1);border:1px solid rgba(231,76,60,0.2);color:#e74c3c}
</style>';
    $page .= '</head><body>' . $header . '
    <div class="bf-media-wrap">
        <div class="bf-media-section">
            <div class="bf-media-section-header"><i class="fas fa-video"></i> Video/Image Avatar</div>
            <div class="bf-media-section-body">
                <div class="bf-media-preview" id="avatar-preview">' . ($avatar_preview ?: '<div style="color:#4a7a52;font-size:12px">No custom avatar set</div>') . '</div>
                <div class="bf-media-upload-area" onclick="document.getElementById(\'avatar-file\').click()">
                    <i class="fas fa-cloud-upload-alt"></i>
                    Click to upload avatar (MP4, WebM, JPG, PNG, GIF — max 5MB)
                </div>
                <input type="file" id="avatar-file" accept="video/mp4,video/webm,image/jpeg,image/png,image/gif,image/webp" style="display:none" onchange="bfMediaUpload(\'avatar\', this)" />
                <div class="bf-media-info">Video avatars will autoplay, loop, and be muted. Recommended: square, under 5MB.</div>
                ' . ($avatar_media ? '<div class="bf-media-actions"><button class="bf-media-del" onclick="bfMediaDelete(\'avatar\')"><i class="fas fa-trash"></i> Remove Avatar</button></div>' : '') . '
                <div class="bf-media-status" id="avatar-status"></div>
            </div>
        </div>

        <div class="bf-media-section">
            <div class="bf-media-section-header"><i class="fas fa-image"></i> Profile Banner</div>
            <div class="bf-media-section-body">
                <div class="bf-media-preview" id="banner-preview">' . ($banner_preview ?: '<div style="color:#4a7a52;font-size:12px">No banner set</div>') . '</div>
                <div class="bf-media-upload-area" onclick="document.getElementById(\'banner-file\').click()">
                    <i class="fas fa-cloud-upload-alt"></i>
                    Click to upload banner (MP4, WebM, JPG, PNG, GIF — max 10MB)
                </div>
                <input type="file" id="banner-file" accept="video/mp4,video/webm,image/jpeg,image/png,image/gif,image/webp" style="display:none" onchange="bfMediaUpload(\'banner\', this)" />
                <div class="bf-media-info">Banner displays at the top of your profile. Recommended: wide format (1200x300), under 10MB.</div>
                ' . ($banner_media ? '<div class="bf-media-actions"><button class="bf-media-del" onclick="bfMediaDelete(\'banner\')"><i class="fas fa-trash"></i> Remove Banner</button></div>' : '') . '
                <div class="bf-media-status" id="banner-status"></div>
            </div>
        </div>
    </div>

    <script>
    function bfMediaUpload(type, input) {
        if(!input.files || !input.files[0]) return;
        var file = input.files[0];
        var maxSize = type === "avatar" ? 5*1024*1024 : 10*1024*1024;
        if(file.size > maxSize) { alert("File too large. Max " + (maxSize/1024/1024) + "MB."); return; }

        var st = document.getElementById(type + "-status");
        st.className = "bf-media-status";
        st.style.display = "block";
        st.innerHTML = "<i class=\"fas fa-spinner fa-spin\"></i> Uploading...";

        var fd = new FormData();
        fd.append("action", "bf_media_upload");
        fd.append("my_post_key", "' . $post_key . '");
        fd.append("media_type", type);
        fd.append("media_file", file);

        fetch("xmlhttp.php", {method:"POST", body:fd})
        .then(function(r){ return r.json(); })
        .then(function(d){
            if(d.success) {
                st.className = "bf-media-status bf-media-ok";
                st.innerHTML = "<i class=\"fas fa-check\"></i> Uploaded! Refreshing...";
                setTimeout(function(){ location.reload(); }, 1000);
            } else {
                st.className = "bf-media-status bf-media-err";
                st.innerHTML = "<i class=\"fas fa-times\"></i> " + (d.error || "Upload failed");
            }
        })
        .catch(function(){ st.className = "bf-media-status bf-media-err"; st.innerHTML = "Request failed."; });
    }

    function bfMediaDelete(type) {
        if(!confirm("Remove your " + type + "?")) return;
        var st = document.getElementById(type + "-status");
        st.className = "bf-media-status";
        st.style.display = "block";
        st.innerHTML = "<i class=\"fas fa-spinner fa-spin\"></i> Removing...";

        var fd = new FormData();
        fd.append("action", "bf_media_delete");
        fd.append("my_post_key", "' . $post_key . '");
        fd.append("media_type", type);

        fetch("xmlhttp.php", {method:"POST", body:fd})
        .then(function(r){ return r.json(); })
        .then(function(d){
            if(d.success) {
                st.className = "bf-media-status bf-media-ok";
                st.innerHTML = "<i class=\"fas fa-check\"></i> Removed! Refreshing...";
                setTimeout(function(){ location.reload(); }, 1000);
            } else {
                st.className = "bf-media-status bf-media-err";
                st.innerHTML = "<i class=\"fas fa-times\"></i> " + (d.error || "Failed");
            }
        })
        .catch(function(){ st.className = "bf-media-status bf-media-err"; st.innerHTML = "Request failed."; });
    }
    </script>
    ' . $footer . '</body></html>';

    echo $page;
    exit;
}

function bf_features_analytics_page()
{
    global $mybb, $db, $header, $headerinclude, $footer;

    if($mybb->get_input('action') !== 'bf_analytics') return;
    error_no_permission();
    return;

    $total_visits = (int)$db->fetch_field($db->simple_select('bf_visits', 'COUNT(*) as cnt'), 'cnt');
    $unique_ips = (int)$db->fetch_field($db->write_query("SELECT COUNT(DISTINCT ip) as cnt FROM {$prefix}bf_visits"), 'cnt');
    $today_visits = (int)$db->fetch_field($db->simple_select('bf_visits', 'COUNT(*) as cnt', "dateline > " . (TIME_NOW - 86400)), 'cnt');
    $today_unique = (int)$db->fetch_field($db->write_query("SELECT COUNT(DISTINCT ip) as cnt FROM {$prefix}bf_visits WHERE dateline > " . (TIME_NOW - 86400)), 'cnt');
    $week_visits = (int)$db->fetch_field($db->simple_select('bf_visits', 'COUNT(*) as cnt', "dateline > " . (TIME_NOW - 604800)), 'cnt');
    $logged_visits = (int)$db->fetch_field($db->simple_select('bf_visits', 'COUNT(*) as cnt', "uid > 0"), 'cnt');

    $total_ref_clicks = (int)$db->fetch_field($db->simple_select('bf_referral_clicks', 'COUNT(*) as cnt'), 'cnt');
    $today_ref = (int)$db->fetch_field($db->simple_select('bf_referral_clicks', 'COUNT(*) as cnt', "dateline > " . (TIME_NOW - 86400)), 'cnt');

    $top_pages_html = '';
    $tpq = $db->write_query("SELECT page, COUNT(*) as hits FROM {$prefix}bf_visits GROUP BY page ORDER BY hits DESC LIMIT 10");
    while($tp = $db->fetch_array($tpq))
    {
        $top_pages_html .= '<tr><td class="trow1" style="padding:6px 12px;font-size:12px">' . htmlspecialchars_uni($tp['page']) . '</td>'
            . '<td class="trow1" style="padding:6px 12px;font-size:12px;text-align:right;font-weight:bold">' . number_format((int)$tp['hits']) . '</td></tr>';
    }

    $top_referrers_html = '';
    $trq = $db->write_query("SELECT u.username, rc.code, COUNT(ck.ckid) as clicks
        FROM {$prefix}bf_referral_clicks ck
        JOIN {$prefix}bf_referral_codes rc ON ck.code = rc.code
        JOIN {$prefix}users u ON rc.uid = u.uid
        GROUP BY u.username, rc.code
        ORDER BY clicks DESC LIMIT 10");
    $rank = 0;
    while($tr = $db->fetch_array($trq))
    {
        $rank++;
        $medal = '';
        if($rank === 1) $medal = '<i class="fas fa-crown" style="color:#ffd700;margin-right:4px"></i>';
        elseif($rank === 2) $medal = '<i class="fas fa-medal" style="color:#c0c0c0;margin-right:4px"></i>';
        elseif($rank === 3) $medal = '<i class="fas fa-medal" style="color:#cd7f32;margin-right:4px"></i>';

        $top_referrers_html .= '<tr>'
            . '<td class="trow1" style="padding:6px 12px;font-size:12px;text-align:center">' . $medal . $rank . '</td>'
            . '<td class="trow1" style="padding:6px 12px;font-size:12px">' . htmlspecialchars_uni($tr['username']) . '</td>'
            . '<td class="trow1" style="padding:6px 12px;font-size:12px;text-align:center"><code>' . htmlspecialchars_uni($tr['code']) . '</code></td>'
            . '<td class="trow1" style="padding:6px 12px;font-size:12px;text-align:right;font-weight:bold;color:#2ecc71">' . number_format((int)$tr['clicks']) . '</td>'
            . '</tr>';
    }

    $recent_html = '';
    $rvq = $db->query("SELECT v.ip, v.page, v.dateline, v.uid, u.username
        FROM {$prefix}bf_visits v
        LEFT JOIN {$prefix}users u ON v.uid = u.uid
        ORDER BY v.dateline DESC LIMIT 20");
    while($rv = $db->fetch_array($rvq))
    {
        $who = (int)$rv['uid'] > 0 ? htmlspecialchars_uni($rv['username']) : '<span style="color:#4a7a52">Guest</span>';
        $recent_html .= '<tr>'
            . '<td class="trow1" style="padding:5px 12px;font-size:11px">' . htmlspecialchars_uni($rv['ip']) . '</td>'
            . '<td class="trow1" style="padding:5px 12px;font-size:11px">' . $who . '</td>'
            . '<td class="trow1" style="padding:5px 12px;font-size:11px">' . htmlspecialchars_uni(substr($rv['page'], 0, 60)) . '</td>'
            . '<td class="trow1" style="padding:5px 12px;font-size:11px;color:#4a7a52">' . my_date('relative', (int)$rv['dateline']) . '</td>'
            . '</tr>';
    }

    $page = '<!DOCTYPE html><html><head><title>Analytics - LeaksForums</title>';
    $page .= $headerinclude;
    $page .= '<style>
.bf-analytics-wrap{max-width:1000px;margin:0 auto 20px}
.bf-analytics-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:20px}
.bf-analytics-card{background:#f5f5f5;border:1px solid #b5c4cf;border-radius:8px;padding:18px;text-align:center}
.bf-analytics-card-num{font-size:28px;font-weight:800;color:#333}
.bf-analytics-card-label{font-size:11px;color:#4a7a52;text-transform:uppercase;letter-spacing:.8px;margin-top:4px}
.bf-analytics-card i{font-size:20px;margin-bottom:8px;display:block}
@media(max-width:700px){.bf-analytics-grid{grid-template-columns:repeat(2,1fr)}}
</style>';
    $page .= '</head><body>' . $header . '
    <div class="bf-analytics-wrap">
        <div class="bf-analytics-grid">
            <div class="bf-analytics-card"><i class="fas fa-eye" style="color:var(--theme-secondary-color)"></i><div class="bf-analytics-card-num">' . number_format($total_visits) . '</div><div class="bf-analytics-card-label">Total Page Views</div></div>
            <div class="bf-analytics-card"><i class="fas fa-users" style="color:#2ecc71"></i><div class="bf-analytics-card-num">' . number_format($unique_ips) . '</div><div class="bf-analytics-card-label">Unique Visitors</div></div>
            <div class="bf-analytics-card"><i class="fas fa-clock" style="color:#f39c12"></i><div class="bf-analytics-card-num">' . number_format($today_visits) . '</div><div class="bf-analytics-card-label">Views Today</div></div>
            <div class="bf-analytics-card"><i class="fas fa-user-clock" style="color:#e74c3c"></i><div class="bf-analytics-card-num">' . number_format($today_unique) . '</div><div class="bf-analytics-card-label">Unique Today</div></div>
            <div class="bf-analytics-card"><i class="fas fa-calendar-week" style="color:#9b59b6"></i><div class="bf-analytics-card-num">' . number_format($week_visits) . '</div><div class="bf-analytics-card-label">Views This Week</div></div>
            <div class="bf-analytics-card"><i class="fas fa-user-check" style="color:#1abc9c"></i><div class="bf-analytics-card-num">' . number_format($logged_visits) . '</div><div class="bf-analytics-card-label">Logged-In Views</div></div>
            <div class="bf-analytics-card"><i class="fas fa-share-alt" style="color:#ffd700"></i><div class="bf-analytics-card-num">' . number_format($total_ref_clicks) . '</div><div class="bf-analytics-card-label">Total Referral Clicks</div></div>
            <div class="bf-analytics-card"><i class="fas fa-share-square" style="color:#3498db"></i><div class="bf-analytics-card-num">' . number_format($today_ref) . '</div><div class="bf-analytics-card-label">Referrals Today</div></div>
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px">
            <table border="0" cellspacing="1" cellpadding="0" class="tborder" style="width:100%">
                <tr><td class="thead" colspan="2"><strong><i class="fas fa-fire" style="margin-right:6px"></i> Top Pages</strong></td></tr>
                <tr><td class="tcat" style="padding:5px 12px;font-size:11px;font-weight:700">Page</td><td class="tcat" style="padding:5px 12px;font-size:11px;font-weight:700;text-align:right">Hits</td></tr>
                ' . ($top_pages_html ?: '<tr><td class="trow1" colspan="2" style="padding:12px;text-align:center;color:#4a7a52;font-size:12px">No data yet</td></tr>') . '
            </table>
            <table border="0" cellspacing="1" cellpadding="0" class="tborder" style="width:100%">
                <tr><td class="thead" colspan="4"><strong><i class="fas fa-trophy" style="margin-right:6px"></i> Top Referrers</strong></td></tr>
                <tr><td class="tcat" style="padding:5px 12px;font-size:11px;font-weight:700;text-align:center">#</td><td class="tcat" style="padding:5px 12px;font-size:11px;font-weight:700">User</td><td class="tcat" style="padding:5px 12px;font-size:11px;font-weight:700;text-align:center">Code</td><td class="tcat" style="padding:5px 12px;font-size:11px;font-weight:700;text-align:right">Clicks</td></tr>
                ' . ($top_referrers_html ?: '<tr><td class="trow1" colspan="4" style="padding:12px;text-align:center;color:#4a7a52;font-size:12px">No referrals yet</td></tr>') . '
            </table>
        </div>

        <table border="0" cellspacing="1" cellpadding="0" class="tborder" style="width:100%">
            <tr><td class="thead" colspan="4"><strong><i class="fas fa-list" style="margin-right:6px"></i> Recent Visitors (Last 20)</strong></td></tr>
            <tr><td class="tcat" style="padding:5px 12px;font-size:11px;font-weight:700">IP</td><td class="tcat" style="padding:5px 12px;font-size:11px;font-weight:700">User</td><td class="tcat" style="padding:5px 12px;font-size:11px;font-weight:700">Page</td><td class="tcat" style="padding:5px 12px;font-size:11px;font-weight:700">Time</td></tr>
            ' . $recent_html . '
        </table>
    </div>
    ' . $footer . '</body></html>';

    echo $page;
    exit;
}

function bf_features_referrals_page()
{
    global $mybb, $db, $header, $headerinclude, $footer;

    if($mybb->get_input('action') !== 'bf_referrals') return;
    if($mybb->user['uid'] <= 0) { error_no_permission(); return; }

    bf_features_ensure_analytics_tables();
    $prefix = $db->table_prefix;
    $uid = (int)$mybb->user['uid'];
    $bburl = htmlspecialchars_uni($mybb->settings['bburl']);

    $ref = $db->fetch_array($db->simple_select('bf_referral_codes', '*', "uid={$uid}"));
    if(!$ref)
    {
        $code = strtolower(substr(md5($uid . TIME_NOW . mt_rand()), 0, 8));
        $db->insert_query('bf_referral_codes', array(
            'uid' => $uid,
            'code' => $db->escape_string($code),
            'dateline' => TIME_NOW,
        ));
        $ref = array('code' => $code);
    }

    $ref_code = htmlspecialchars_uni($ref['code']);
    $ref_link = htmlspecialchars_uni($mybb->settings['bburl']) . '/?ref=' . $ref_code;

    $my_clicks = (int)$db->fetch_field($db->simple_select('bf_referral_clicks', 'COUNT(*) as cnt', "ref_uid={$uid}"), 'cnt');
    $my_today = (int)$db->fetch_field($db->simple_select('bf_referral_clicks', 'COUNT(*) as cnt', "ref_uid={$uid} AND dateline > " . (TIME_NOW - 86400)), 'cnt');
    $my_week = (int)$db->fetch_field($db->simple_select('bf_referral_clicks', 'COUNT(*) as cnt', "ref_uid={$uid} AND dateline > " . (TIME_NOW - 604800)), 'cnt');

    $leaderboard_html = '';
    $lbq = $db->write_query("SELECT u.username, u.uid, u.usergroup, rc.code, COUNT(ck.ckid) as clicks
        FROM {$prefix}bf_referral_clicks ck
        JOIN {$prefix}bf_referral_codes rc ON ck.code = rc.code
        JOIN {$prefix}users u ON rc.uid = u.uid
        GROUP BY u.username, u.uid, u.usergroup, rc.code
        ORDER BY clicks DESC LIMIT 15");
    $rank = 0;
    while($lb = $db->fetch_array($lbq))
    {
        $rank++;
        $medal = '';
        if($rank === 1) $medal = '<i class="fas fa-crown" style="color:#ffd700;margin-right:4px"></i>';
        elseif($rank === 2) $medal = '<i class="fas fa-medal" style="color:#c0c0c0;margin-right:4px"></i>';
        elseif($rank === 3) $medal = '<i class="fas fa-medal" style="color:#cd7f32;margin-right:4px"></i>';

        $ug = (int)$lb['usergroup'];
        $nc = '#e7e7e7';
        if($ug === 4) $nc = '#C00';
        elseif($ug === 3) $nc = '#F60';
        elseif($ug === 6) $nc = '#0C0';
        elseif($ug === 8) $nc = '#f1c40f';
        elseif($ug === 9) $nc = '#e74c3c';
        elseif($ug === 10) $nc = '#9b59b6';

        $is_me_class = ((int)$lb['uid'] === $uid) ? ' me' : '';
        $leaderboard_html .= '<div class="bfr-lb-r' . $is_me_class . '">'
            . '<div class="bfr-lb-rk">' . $medal . ($medal ? '' : $rank) . '</div>'
            . '<div class="bfr-lb-u"><a href="member.php?action=profile&uid=' . (int)$lb['uid'] . '" style="color:' . $nc . ';text-decoration:none">' . htmlspecialchars_uni($lb['username']) . '</a></div>'
            . '<div class="bfr-lb-v">' . number_format((int)$lb['clicks']) . '</div>'
            . '</div>';
    }

    $my_signups = (int)$db->fetch_field($db->simple_select('bf_referral_clicks', 'COUNT(*) as cnt', "ref_uid={$uid} AND visitor_uid > 0"), 'cnt');

    $page = '<!DOCTYPE html><html><head><title>Referrals - LeaksForums</title>';
    $page .= $headerinclude;
    $page .= '<style>
.bfr{max-width:880px;margin:10px auto 30px;font-family:inherit}
.bfr-top{background:#f5f5f5;border:1px solid #b5c4cf;padding:24px 28px 22px;margin-bottom:16px}
.bfr-top-t{font-size:15px;font-weight:700;color:#c8d0d8;margin:0 0 4px}
.bfr-top-s{font-size:12px;color:#556677;margin:0 0 16px}
.bfr-link-wrap{display:flex;align-items:stretch;border:1px solid #b5c4cf;background:#fff;max-width:520px}
.bfr-link-wrap input{flex:1;background:transparent;border:none;color:#449151;padding:10px 14px;font-size:13px;font-family:"Courier New",monospace;outline:none;min-width:0}
.bfr-link-wrap button{background:#e0e0e0;border:none;border-left:1px solid #b5c4cf;color:#666;padding:0 16px;font-size:12px;font-weight:600;cursor:pointer;white-space:nowrap;transition:background 150ms}
.bfr-link-wrap button:hover{background:#c5d5e5}
.bfr-link-wrap button.ok{background:#2ecc71;color:#fff}
.bfr-code{margin-top:10px;font-size:11px;color:#445566}
.bfr-code span{color:#6a8a9f;font-family:monospace}
.bfr-g{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:16px}
.bfr-c{background:#f5f5f5;border:1px solid #b5c4cf;padding:18px 14px;text-align:center}
.bfr-c-n{font-size:22px;font-weight:800;color:#d0d8de;margin-bottom:2px}
.bfr-c-l{font-size:10px;color:#556677;text-transform:uppercase;letter-spacing:.6px}
.bfr-c:nth-child(1) .bfr-c-n{color:#5a9}
.bfr-c:nth-child(4) .bfr-c-n{color:#e8b84a}
.bfr-lb{background:#f5f5f5;border:1px solid #b5c4cf;overflow:hidden}
.bfr-lb-h{padding:12px 18px;border-bottom:1px solid #1e2733;font-size:12px;font-weight:700;color:#778899;text-transform:uppercase;letter-spacing:.5px;display:flex;justify-content:space-between}
.bfr-lb-r{display:flex;align-items:center;padding:10px 18px;border-bottom:1px solid #13171f}
.bfr-lb-r:last-child{border-bottom:none}
.bfr-lb-r:hover{background:#e8f0f8}
.bfr-lb-r.me{background:rgba(90,153,119,0.06)}
.bfr-lb-rk{width:36px;font-size:13px;font-weight:700;color:#445566;text-align:center}
.bfr-lb-u{flex:1;font-size:13px;font-weight:600;padding-left:8px}
.bfr-lb-v{font-size:13px;font-weight:700;color:#5a9;min-width:50px;text-align:right}
.bfr-lb-e{padding:24px;text-align:center;color:#445566;font-size:12px}
@media(max-width:600px){.bfr-g{grid-template-columns:repeat(2,1fr)}}
</style>';
    $page .= '</head><body>' . $header . '
    <div class="bfr">
        <div class="bfr-top">
            <div class="bfr-top-t">Referral Link</div>
            <div class="bfr-top-s">Share this link. Clicks and sign-ups are tracked to your account.</div>
            <div class="bfr-link-wrap">
                <input type="text" id="bfr-l" value="' . $ref_link . '" readonly onclick="this.select()" />
                <button id="bfr-cp" onclick="bfrCp()">COPY</button>
            </div>
            <div class="bfr-code">Code: <span>' . $ref_code . '</span></div>
        </div>

        <div class="bfr-g">
            <div class="bfr-c"><div class="bfr-c-n">' . number_format($my_clicks) . '</div><div class="bfr-c-l">Total Clicks</div></div>
            <div class="bfr-c"><div class="bfr-c-n">' . number_format($my_today) . '</div><div class="bfr-c-l">Today</div></div>
            <div class="bfr-c"><div class="bfr-c-n">' . number_format($my_week) . '</div><div class="bfr-c-l">This Week</div></div>
            <div class="bfr-c"><div class="bfr-c-n">' . number_format($my_signups) . '</div><div class="bfr-c-l">Sign-ups</div></div>
        </div>

        <div class="bfr-lb">
            <div class="bfr-lb-h"><span>Leaderboard</span><span>Clicks</span></div>
            ' . ($leaderboard_html ?: '<div class="bfr-lb-e">No referrals yet.</div>') . '
        </div>
    </div>

    <script>
    function bfrCp(){var i=document.getElementById("bfr-l"),b=document.getElementById("bfr-cp");navigator.clipboard.writeText(i.value).then(function(){b.classList.add("ok");b.textContent="COPIED";setTimeout(function(){b.classList.remove("ok");b.textContent="COPY"},1500)})}
    </script>
    ' . $footer . '</body></html>';

    echo $page;
    exit;
}
