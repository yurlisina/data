<?php
if(!defined("IN_MYBB"))
{
    die("Direct initialization of this file is not allowed.");
}

$plugins->add_hook("global_start", "bf_security_headers");
$plugins->add_hook("global_start", "bf_security_anonymize_session");
$plugins->add_hook("global_start", "bf_security_block_suspicious");
$plugins->add_hook("member_do_login_end", "bf_security_anonymize_login");
$plugins->add_hook("datahandler_user_insert_end", "bf_security_on_user_create");
$plugins->add_hook("datahandler_post_insert_end", "bf_security_on_post_create");
$plugins->add_hook("datahandler_post_update_end", "bf_security_on_post_update");
$plugins->add_hook("private_do_send_end", "bf_security_anonymize_pm");
$plugins->add_hook("polls_vote_end", "bf_security_anonymize_pollvote");
$plugins->add_hook("ratethread_process", "bf_security_anonymize_threadrating");
$plugins->add_hook("admin_page_output_footer", "bf_security_anonymize_adminlog");
$plugins->add_hook("task_logs", "bf_security_sweep_ips");

function bf_security_info()
{
    return array(
        "name"          => "BF Security Hardening",
        "description"   => "Comprehensive security: full IP anonymization across all tables, rate limiting, anti-enumeration.",
        "website"       => "",
        "author"        => "BF",
        "version"       => "2.1",
        "compatibility" => "18*"
    );
}

function bf_security_activate() {}
function bf_security_deactivate() {}

function bf_security_headers()
{
    header_remove('X-Powered-By');
    header_remove('Server');

    if(function_exists('ini_set'))
    {
        ini_set('session.cookie_httponly', 1);
        ini_set('session.cookie_secure', 1);
        ini_set('session.use_strict_mode', 1);
        ini_set('display_errors', 0);
        ini_set('expose_php', 0);
    }
}

function bf_security_block_suspicious()
{
    $ua = isset($_SERVER['HTTP_USER_AGENT']) ? $_SERVER['HTTP_USER_AGENT'] : '';

    if(empty($ua) && !defined('IN_ADMINCP'))
    {
        $uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
        if(strpos($uri, 'xmlhttp.php') === false && strpos($uri, 'task.php') === false && strpos($uri, 'css.php') === false)
        {
        }
    }

    $blocked_patterns = array(
        'sqlmap', 'nikto', 'nessus', 'acunetix', 'havij',
        'w3af', 'openvas', 'netsparker', 'burpsuite',
    );

    $ua_lower = strtolower($ua);
    foreach($blocked_patterns as $pattern)
    {
        if(strpos($ua_lower, $pattern) !== false)
        {
            http_response_code(403);
            exit;
        }
    }

    $request_uri = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : '';
    $sql_patterns = array(
        'UNION%20SELECT', 'UNION+SELECT', 'union%20select', 'union+select',
        'INTO%20OUTFILE', 'into%20outfile', 'LOAD_FILE', 'load_file',
        'benchmark(', 'BENCHMARK(', 'sleep(', 'SLEEP(',
        'information_schema', 'INFORMATION_SCHEMA',
    );

    foreach($sql_patterns as $pattern)
    {
        if(stripos($request_uri, $pattern) !== false)
        {
            http_response_code(403);
            exit;
        }
    }
}

function bf_security_anonymize_session()
{
    global $db, $session;

    if(isset($session->sid) && $session->sid)
    {
        $db->update_query('sessions', array(
            'ip' => $db->escape_binary(pack("N", 0)),
        ), "sid='" . $db->escape_string($session->sid) . "'");
    }
}

function bf_security_anonymize_login()
{
    global $mybb, $db;

    if($mybb->user['uid'] > 0)
    {
        $uid = (int)$mybb->user['uid'];
        $db->update_query('users', array(
            'regip' => $db->escape_binary(pack("N", 0)),
            'lastip' => $db->escape_binary(pack("N", 0)),
        ), "uid={$uid}");
    }
}

function bf_security_on_user_create(&$datahandler)
{
    global $db;

    if(isset($datahandler->return_values['uid']))
    {
        $uid = (int)$datahandler->return_values['uid'];
        $db->update_query('users', array(
            'regip' => $db->escape_binary(pack("N", 0)),
            'lastip' => $db->escape_binary(pack("N", 0)),
        ), "uid={$uid}");
    }
}

function bf_security_on_post_create(&$datahandler)
{
    global $db;

    if(isset($datahandler->return_values['pid']))
    {
        $pid = (int)$datahandler->return_values['pid'];
        $db->update_query('posts', array(
            'ipaddress' => $db->escape_binary(pack("N", 0)),
        ), "pid={$pid}");
    }
}

function bf_security_on_post_update(&$datahandler)
{
    global $db;

    if(isset($datahandler->pid))
    {
        $pid = (int)$datahandler->pid;
        $db->update_query('posts', array(
            'ipaddress' => $db->escape_binary(pack("N", 0)),
        ), "pid={$pid}");
    }
}

function bf_security_anonymize_pm()
{
    global $db;

    $db->update_query('privatemessages', array(
        'ipaddress' => $db->escape_binary(pack("N", 0)),
    ), "ipaddress != " . $db->escape_binary(pack("N", 0)));
}

function bf_security_anonymize_pollvote()
{
    global $db;

    $db->update_query('pollvotes', array(
        'ipaddress' => $db->escape_binary(pack("N", 0)),
    ), "ipaddress != " . $db->escape_binary(pack("N", 0)));
}

function bf_security_anonymize_threadrating()
{
    global $db;

    $db->update_query('threadratings', array(
        'ipaddress' => $db->escape_binary(pack("N", 0)),
    ), "ipaddress != " . $db->escape_binary(pack("N", 0)));
}

function bf_security_anonymize_adminlog()
{
    global $db;

    $zero_ip = $db->escape_binary(pack("N", 0));

    $db->update_query('adminlog', array(
        'ipaddress' => $zero_ip,
    ), "ipaddress != {$zero_ip}");

    $db->update_query('moderatorlog', array(
        'ipaddress' => $zero_ip,
    ), "ipaddress != {$zero_ip}");

    $db->update_query('adminsessions', array(
        'ip' => $zero_ip,
    ), "ip != {$zero_ip}");
}

function bf_security_sweep_ips()
{
    global $db;

    $zero_ip = $db->escape_binary(pack("N", 0));
    $tables = array(
        'sessions' => 'ip',
        'adminsessions' => 'ip',
        'posts' => 'ipaddress',
        'searchlog' => 'ipaddress',
        'pollvotes' => 'ipaddress',
        'threadratings' => 'ipaddress',
        'privatemessages' => 'ipaddress',
        'maillogs' => 'ipaddress',
        'spamlog' => 'ipaddress',
        'adminlog' => 'ipaddress',
        'moderatorlog' => 'ipaddress',
    );

    if($db->table_exists('bf_referral_clicks'))
    {
        $db->update_query('bf_referral_clicks', array(
            'visitor_ip' => '0.0.0.0',
        ), "visitor_ip != '0.0.0.0' AND visitor_ip != ''");
    }

    foreach($tables as $table => $column)
    {
        $db->update_query($table, array(
            $column => $zero_ip,
        ), "{$column} != {$zero_ip}");
    }

    $db->update_query('users', array(
        'regip' => $zero_ip,
        'lastip' => $zero_ip,
    ), "regip != {$zero_ip} OR lastip != {$zero_ip}");
}
