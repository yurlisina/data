<?php
if(!defined("IN_MYBB"))
{
    die("Direct initialization of this file is not allowed.");
}

$plugins->add_hook("misc_start", "bf_upgrades_page");
$plugins->add_hook("misc_start", "bf_upgrades_admin_page");
$plugins->add_hook("global_intermediate", "bf_upgrades_check_expiry");
$plugins->add_hook("postbit", "bf_upgrades_postbit_badge");
$plugins->add_hook("member_profile_end", "bf_upgrades_profile_badge");

function bf_upgrades_info()
{
    return array(
        "name"          => "BF Account Upgrades",
        "description"   => "Account upgrade system with VIP/Premium/Legendary tiers, badges, and payment processing.",
        "website"       => "",
        "author"        => "BF",
        "version"       => "1.0",
        "compatibility" => "18*"
    );
}

function bf_upgrades_activate() {}
function bf_upgrades_deactivate() {}

function bf_upgrades_get_badge_html($gid)
{
    $badges = array(
        4  => '<span class="bf-role-badge bf-role-owner">Owner</span>',
        3  => '<span class="bf-role-badge bf-role-admin">Admin</span>',
        6  => '<span class="bf-role-badge bf-role-mod">Moderator</span>',
        8  => '<span class="bf-role-badge bf-role-vip">VIP</span>',
        9  => '<span class="bf-role-badge bf-role-premium">Premium</span>',
        10 => '<span class="bf-role-badge bf-role-legendary">Legendary</span>',
        2  => '<span class="bf-role-badge bf-role-member">Member</span>',
        7  => '<span class="bf-role-badge bf-role-banned">Banned</span>',
    );

    return isset($badges[$gid]) ? $badges[$gid] : '';
}

function bf_upgrades_postbit_badge(&$post)
{
}

function bf_upgrades_profile_badge()
{
}

function bf_upgrades_get_wallet_display()
{
    global $db;
    $wallets = array('btc' => '', 'eth' => '', 'xmr' => '', 'ltc' => '');
    $wq = $db->simple_select('datacache', 'cache', "title='bf_crypto_wallets'");
    $wdata = $db->fetch_field($wq, 'cache');
    if($wdata)
    {
        $w = @json_decode($wdata, true);
        if(!is_array($w)) $w = @unserialize($wdata);
        if(is_array($w)) $wallets = array_merge($wallets, $w);
    }

    $icons = array('btc' => 'fab fa-bitcoin', 'eth' => 'fab fa-ethereum', 'xmr' => 'fas fa-shield-alt', 'ltc' => 'fas fa-cube');
    $colors = array('btc' => '#f7931a', 'eth' => '#627eea', 'xmr' => '#ff6600', 'ltc' => '#bfbbbb');
    $names = array('btc' => 'Bitcoin', 'eth' => 'Ethereum', 'xmr' => 'Monero', 'ltc' => 'Litecoin');

    $html = '<div class="bf-crypto-wallets">';
    $has_any = false;
    foreach($wallets as $coin => $addr)
    {
        if(empty($addr)) continue;
        $has_any = true;
        $safe_addr = htmlspecialchars_uni($addr);
        $html .= '<div class="bf-wallet-display">
            <div class="bf-wallet-coin"><i class="' . $icons[$coin] . '" style="color:' . $colors[$coin] . '"></i> ' . $names[$coin] . '</div>
            <div class="bf-wallet-addr"><code>' . $safe_addr . '</code> <button class="bf-copy-btn" onclick="navigator.clipboard.writeText(\'' . $safe_addr . '\');this.innerHTML=\'<i class=&quot;fas fa-check&quot;></i> Copied\';setTimeout(function(){this.innerHTML=\'<i class=&quot;fas fa-copy&quot;></i>\'}.bind(this),2000)"><i class="fas fa-copy"></i></button></div>
        </div>';
    }
    if(!$has_any)
    {
        $html .= '<p style="color:#666;font-size:12px;margin:8px 0">Payment addresses will be displayed here once configured by an administrator.</p>';
    }
    $html .= '</div>';
    return $html;
}

function bf_upgrades_check_expiry()
{
    global $db;

    static $checked = false;
    if($checked) return;
    $checked = true;

    $now = TIME_NOW;
    $query = $db->query("
        SELECT u.uid_upgrade, u.uid, u.old_gid, u.new_gid
        FROM {$db->table_prefix}user_upgrades u
        WHERE u.status = 'active' AND u.expire_date > 0 AND u.expire_date < {$now}
    ");

    while($row = $db->fetch_array($query))
    {
        $db->update_query('users', array(
            'usergroup' => (int)$row['old_gid'],
            'displaygroup' => (int)$row['old_gid'],
        ), "uid=" . (int)$row['uid']);

        $db->update_query('user_upgrades', array(
            'status' => 'expired',
        ), "uid_upgrade=" . (int)$row['uid_upgrade']);
    }
}

function bf_upgrades_page()
{
    global $mybb, $db, $lang, $theme, $templates, $headerinclude, $header, $footer;

    if($mybb->get_input('action') !== 'upgrades') return;

    $bburl = htmlspecialchars_uni($mybb->settings['bburl']);

    if($mybb->get_input('do') === 'purchase' && $mybb->user['uid'] > 0)
    {
        if($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

        verify_post_check($mybb->get_input('my_post_key'));

        if((int)$mybb->user['usergroup'] === 7 || (int)$mybb->user['usergroup'] === 5)
        {
            error_no_permission();
            exit;
        }

        $plan_id = $mybb->get_input('plan_id', MyBB::INPUT_INT);
        if($plan_id <= 0) { error_no_permission(); exit; }

        $query = $db->simple_select('upgrade_plans', '*', "pid={$plan_id} AND active=1");
        $plan = $db->fetch_array($query);

        if($plan)
        {
            $uid = (int)$mybb->user['uid'];
            $now = TIME_NOW;

            $recent = (int)$db->fetch_field($db->simple_select('payment_log', 'COUNT(*) as cnt', "uid={$uid} AND dateline > " . ($now - 300)), 'cnt');
            if($recent >= 3)
            {
                error("Too many purchase attempts. Please wait before trying again.");
                exit;
            }

            $expire = $now + ((int)$plan['duration_days'] * 86400);

            $existing = $db->simple_select('user_upgrades', '*', "uid={$uid} AND status='active' AND new_gid=" . (int)$plan['target_gid']);
            if($db->num_rows($existing) > 0)
            {
                $ex = $db->fetch_array($existing);
                $expire = (int)$ex['expire_date'] + ((int)$plan['duration_days'] * 86400);
                $db->update_query('user_upgrades', array(
                    'expire_date' => $expire,
                ), "uid_upgrade=" . (int)$ex['uid_upgrade']);
            }
            else
            {
                $db->insert_query('user_upgrades', array(
                    'uid' => $uid,
                    'plan_id' => $plan_id,
                    'old_gid' => (int)$mybb->user['usergroup'],
                    'new_gid' => (int)$plan['target_gid'],
                    'purchase_date' => $now,
                    'expire_date' => $expire,
                    'payment_method' => 'manual',
                    'status' => 'pending',
                    'amount' => $plan['price_usd'],
                ));
            }

            $txn_id = 'TXN-' . strtoupper(bin2hex(random_bytes(8)));
            $db->insert_query('payment_log', array(
                'uid' => $uid,
                'plan_id' => $plan_id,
                'amount' => $plan['price_usd'],
                'currency' => 'USD',
                'method' => 'manual',
                'transaction_id' => $txn_id,
                'status' => 'pending',
                'dateline' => $now,
                'notes' => 'Upgrade request: ' . $db->escape_string($plan['title']),
            ));

            $plan_title_safe = $db->escape_string($plan['title']);
            $price_safe = number_format((float)$plan['price_usd'], 2);
            $username_safe = $db->escape_string($mybb->user['username']);
            $pm_subject = "New Upgrade Request: {$plan_title_safe}";
            $pm_message = "A new upgrade request has been submitted.\n\n"
                . "[b]User:[/b] [url={$mybb->settings['bburl']}/member.php?action=profile&uid={$uid}]{$username_safe}[/url]\n"
                . "[b]Plan:[/b] {$plan_title_safe}\n"
                . "[b]Price:[/b] \${$price_safe}\n"
                . "[b]Transaction ID:[/b] {$txn_id}\n"
                . "[b]Date:[/b] " . my_date('M j, Y H:i', $now) . "\n\n"
                . "[url={$mybb->settings['bburl']}/misc.php?action=admin_upgrades]Click here to review and approve/deny[/url]";

            $admin_q = $db->simple_select('users', 'uid', "usergroup IN (3,4)");
            while($admin = $db->fetch_array($admin_q))
            {
                $pm_data = array(
                    'uid' => (int)$admin['uid'],
                    'subject' => $pm_subject,
                    'message' => $pm_message,
                    'fromid' => $uid,
                    'toid' => (int)$admin['uid'],
                    'recipients' => serialize(array('to' => array((int)$admin['uid']))),
                    'dateline' => $now,
                    'folder' => 1,
                    'status' => 0,
                    'readtime' => 0,
                    'receipt' => 0,
                    'smilieoff' => 1,
                    'ipaddress' => '',
                );
                $db->insert_query('privatemessages', $pm_data);
                $db->write_query("UPDATE {$db->table_prefix}users SET unreadpms = unreadpms + 1 WHERE uid = " . (int)$admin['uid']);
            }

            header("Location: {$mybb->settings['bburl']}/misc.php?action=upgrades&purchased=1");
            exit;
        }
    }

    add_breadcrumb("Account Upgrades", "misc.php?action=upgrades");

    $query = $db->simple_select('upgrade_plans', '*', 'active=1', array('order_by' => 'sort_order'));

    $plans_html = '';
    while($plan = $db->fetch_array($query))
    {
        $title = htmlspecialchars_uni($plan['title']);
        $desc = htmlspecialchars_uni($plan['description']);
        $price = number_format((float)$plan['price_usd'], 2);
        $days = (int)$plan['duration_days'];
        $badge_label = htmlspecialchars_uni($plan['badge_label']);
        $badge_color = htmlspecialchars_uni($plan['badge_color']);
        $badge_bg = htmlspecialchars_uni($plan['badge_bg']);

        $features_list = '';
        $features = explode(',', $plan['features']);
        foreach($features as $f)
        {
            $f = trim($f);
            if($f) $features_list .= '<li><i class="fas fa-check"></i> ' . htmlspecialchars_uni($f) . '</li>';
        }

        $current_badge = '';
        $action_btn = '';
        if($mybb->user['uid'] > 0)
        {
            $user_gid = (int)$mybb->user['usergroup'];
            if($user_gid == (int)$plan['target_gid'])
            {
                $current_badge = '<span class="bf-plan-current">Current Plan</span>';
                $action_btn = '<button class="bf-plan-btn bf-plan-btn-extend" onclick="document.getElementById(\'extend-form-' . (int)$plan['pid'] . '\').submit();">Extend +' . $days . ' days</button>';
                $action_btn .= '<form id="extend-form-' . (int)$plan['pid'] . '" method="post" action="' . $bburl . '/misc.php?action=upgrades&do=purchase">';
                $action_btn .= '<input type="hidden" name="plan_id" value="' . (int)$plan['pid'] . '" />';
                $action_btn .= '<input type="hidden" name="my_post_key" value="' . htmlspecialchars_uni($mybb->post_code) . '" />';
                $action_btn .= '</form>';
            }
            else
            {
                $action_btn = '<form method="post" action="' . $bburl . '/misc.php?action=upgrades&do=purchase">';
                $action_btn .= '<input type="hidden" name="plan_id" value="' . (int)$plan['pid'] . '" />';
                $action_btn .= '<input type="hidden" name="my_post_key" value="' . htmlspecialchars_uni($mybb->post_code) . '" />';
                $action_btn .= '<button type="submit" class="bf-plan-btn">Upgrade Now</button>';
                $action_btn .= '</form>';
            }
        }
        else
        {
            $action_btn = '<a href="' . $bburl . '/member.php?action=register" class="bf-plan-btn">Register to Upgrade</a>';
        }

        $glow_color = $badge_color;
        $tier_icon = 'fas fa-star';
        $tier_class = 'bf-tier-vip';
        if(stripos($title, 'premium') !== false) { $tier_icon = 'fas fa-crown'; $tier_class = 'bf-tier-premium'; }
        if(stripos($title, 'legendary') !== false) { $tier_icon = 'fas fa-dragon'; $tier_class = 'bf-tier-legendary'; }

        $popular_tag = '';
        if(stripos($title, 'premium') !== false) {
            $popular_tag = '<div class="bf-popular-tag"><i class="fas fa-fire"></i> Most Popular</div>';
        }

        $plans_html .= '<div class="bf-plan-card ' . $tier_class . '" style="--tier-color:' . $badge_color . ';">
            ' . $popular_tag . '
            <div class="bf-plan-header">
                <div class="bf-plan-icon"><i class="' . $tier_icon . '"></i></div>
                <span class="bf-plan-badge" style="color:' . $badge_color . ';background:' . $badge_bg . ';box-shadow:0 0 12px ' . $badge_color . '40;">' . $badge_label . '</span>
                ' . $current_badge . '
                <div class="bf-plan-price"><span class="bf-price-dollar">$</span>' . $price . '<span class="bf-price-period">/month</span></div>
                <p class="bf-plan-desc">' . $desc . '</p>
            </div>
            <div class="bf-plan-divider" style="background:linear-gradient(90deg,transparent,' . $badge_color . ',transparent)"></div>
            <div class="bf-plan-body">
                <ul class="bf-plan-features">' . $features_list . '</ul>
            </div>
            <div class="bf-plan-footer">
                ' . $action_btn . '
            </div>
        </div>';
    }

    $purchased_msg = '';
    if($mybb->get_input('purchased'))
    {
        $purchased_msg = '<div class="bf-upgrade-success"><i class="fas fa-check-circle"></i> Your upgrade request has been submitted. An administrator will review and activate it shortly.</div>';
    }

    $active_upgrades = '';
    if($mybb->user['uid'] > 0)
    {
        $q = $db->query("
            SELECT u.*, p.title as plan_title, p.badge_label, p.badge_color, p.badge_bg
            FROM {$db->table_prefix}user_upgrades u
            JOIN {$db->table_prefix}upgrade_plans p ON p.pid = u.plan_id
            WHERE u.uid = " . (int)$mybb->user['uid'] . " AND u.status = 'active'
            ORDER BY u.purchase_date DESC
        ");

        $rows = '';
        while($ug = $db->fetch_array($q))
        {
            $expire = my_date('M j, Y', (int)$ug['expire_date']);
            $purchased = my_date('M j, Y', (int)$ug['purchase_date']);
            $badge_label = htmlspecialchars_uni($ug['badge_label']);
            $badge_color = htmlspecialchars_uni($ug['badge_color']);
            $badge_bg = htmlspecialchars_uni($ug['badge_bg']);

            $rows .= '<tr>
                <td class="trow1"><span class="bf-plan-badge" style="color:' . $badge_color . ';background:' . $badge_bg . ';">' . $badge_label . '</span></td>
                <td class="trow1">' . $purchased . '</td>
                <td class="trow1">' . $expire . '</td>
                <td class="trow1"><span class="bf-status-active">Active</span></td>
            </tr>';
        }

        if($rows)
        {
            $active_upgrades = '<div class="bf-active-upgrades">
                <h3><i class="fas fa-crown"></i> Your Active Upgrades</h3>
                <table class="tborder" cellspacing="0" cellpadding="5">
                    <thead><tr>
                        <td class="thead">Plan</td>
                        <td class="thead">Purchased</td>
                        <td class="thead">Expires</td>
                        <td class="thead">Status</td>
                    </tr></thead>
                    <tbody>' . $rows . '</tbody>
                </table>
            </div>';
        }
    }

    $page = '<!DOCTYPE html>
<html>
<head>
    <title>Account Upgrades - ' . htmlspecialchars_uni($mybb->settings['bbname']) . '</title>
    ' . $headerinclude . '
</head>
<body>
' . $header . '
<div class="wrapper">
    <div class="container">
        ' . $purchased_msg . '
        ' . $active_upgrades . '
        <div class="bf-upgrades-header">
            <h2><i class="fas fa-gem"></i> Account Upgrades</h2>
            <p>Upgrade your account to unlock premium features, exclusive badges, and more.</p>
        </div>
        <div class="bf-plans-grid">
            ' . $plans_html . '
        </div>
        <div class="bf-payment-info">
            <h3><i class="fas fa-info-circle"></i> Payment Information</h3>
            <p>Payments are processed manually via cryptocurrency. After submitting a request, send the payment to one of the addresses below, then contact staff with your transaction ID.</p>
            <p><strong>Accepted Methods:</strong> Cryptocurrency (BTC, ETH, XMR, LTC)</p>
            ' . bf_upgrades_get_wallet_display() . '
        </div>
    </div>
</div>
' . $footer . '
</body>
</html>';

    echo $page;
    exit;
}

function bf_upgrades_admin_page()
{
    global $mybb, $db, $headerinclude, $header, $footer;

    if($mybb->get_input('action') !== 'admin_upgrades') return;
    if(!in_array((int)$mybb->user['usergroup'], array(3, 4))) { error_no_permission(); exit; }

    $bburl = htmlspecialchars_uni($mybb->settings['bburl']);

    if($mybb->get_input('do') === 'approve' && $_SERVER['REQUEST_METHOD'] === 'POST')
    {
        verify_post_check($mybb->get_input('my_post_key'));
        $upgrade_id = $mybb->get_input('uid_upgrade', MyBB::INPUT_INT);
        $upgrade = $db->fetch_array($db->simple_select('user_upgrades', '*', "uid_upgrade={$upgrade_id} AND status='pending'"));
        if($upgrade)
        {
            $db->update_query('user_upgrades', array('status' => 'active'), "uid_upgrade={$upgrade_id}");
            $db->update_query('users', array(
                'usergroup' => (int)$upgrade['new_gid'],
                'displaygroup' => (int)$upgrade['new_gid'],
            ), "uid=" . (int)$upgrade['uid']);
            $db->update_query('payment_log', array('status' => 'completed'), "uid=" . (int)$upgrade['uid'] . " AND plan_id=" . (int)$upgrade['plan_id'] . " AND status='pending'");
        }
        header("Location: {$bburl}/misc.php?action=admin_upgrades&done=approved");
        exit;
    }

    if($mybb->get_input('do') === 'deny' && $_SERVER['REQUEST_METHOD'] === 'POST')
    {
        verify_post_check($mybb->get_input('my_post_key'));
        $upgrade_id = $mybb->get_input('uid_upgrade', MyBB::INPUT_INT);
        $db->update_query('user_upgrades', array('status' => 'denied'), "uid_upgrade={$upgrade_id}");
        $db->update_query('payment_log', array('status' => 'denied'), "uid_upgrade={$upgrade_id}");
        header("Location: {$bburl}/misc.php?action=admin_upgrades&done=denied");
        exit;
    }

    if($mybb->get_input('do') === 'set_wallets' && $_SERVER['REQUEST_METHOD'] === 'POST')
    {
        verify_post_check($mybb->get_input('my_post_key'));
        $wallets = array(
            'btc' => trim($mybb->get_input('wallet_btc')),
            'eth' => trim($mybb->get_input('wallet_eth')),
            'xmr' => trim($mybb->get_input('wallet_xmr')),
            'ltc' => trim($mybb->get_input('wallet_ltc')),
        );
        $existing = $db->simple_select('datacache', 'title', "title='bf_crypto_wallets'");
        if($db->num_rows($existing) > 0)
        {
            $db->update_query('datacache', array('cache' => $db->escape_string(serialize($wallets))), "title='bf_crypto_wallets'");
        }
        else
        {
            $db->insert_query('datacache', array('title' => 'bf_crypto_wallets', 'cache' => $db->escape_string(serialize($wallets))));
        }
        header("Location: {$bburl}/misc.php?action=admin_upgrades&done=wallets");
        exit;
    }

    add_breadcrumb("Admin: Manage Upgrades", "misc.php?action=admin_upgrades");

    $wallets = array('btc' => '', 'eth' => '', 'xmr' => '', 'ltc' => '');
    $wq = $db->simple_select('datacache', 'cache', "title='bf_crypto_wallets'");
    $wdata = $db->fetch_field($wq, 'cache');
    if($wdata)
    {
        $w = @json_decode($wdata, true);
        if(!is_array($w)) $w = @unserialize($wdata);
        if(is_array($w)) $wallets = array_merge($wallets, $w);
    }

    $done_msg = '';
    if($mybb->get_input('done') === 'approved') $done_msg = '<div class="bf-upgrade-success"><i class="fas fa-check-circle"></i> Upgrade approved and activated.</div>';
    if($mybb->get_input('done') === 'denied') $done_msg = '<div class="bf-admin-denied"><i class="fas fa-times-circle"></i> Upgrade request denied.</div>';
    if($mybb->get_input('done') === 'wallets') $done_msg = '<div class="bf-upgrade-success"><i class="fas fa-check-circle"></i> Crypto wallet addresses updated.</div>';

    $pending_q = $db->query("
        SELECT u.*, usr.username, p.title as plan_title, p.badge_label, p.badge_color, p.badge_bg, p.price_usd
        FROM {$db->table_prefix}user_upgrades u
        JOIN {$db->table_prefix}users usr ON usr.uid = u.uid
        JOIN {$db->table_prefix}upgrade_plans p ON p.pid = u.plan_id
        WHERE u.status = 'pending'
        ORDER BY u.purchase_date DESC
    ");

    $pending_rows = '';
    while($row = $db->fetch_array($pending_q))
    {
        $username = htmlspecialchars_uni($row['username']);
        $plan_title = htmlspecialchars_uni($row['plan_title']);
        $price = number_format((float)$row['price_usd'], 2);
        $date = my_date('M j, Y H:i', (int)$row['purchase_date']);
        $badge_label = htmlspecialchars_uni($row['badge_label']);
        $badge_color = htmlspecialchars_uni($row['badge_color']);
        $badge_bg = htmlspecialchars_uni($row['badge_bg']);

        $pending_rows .= '<tr>
            <td class="trow1"><a href="member.php?action=profile&uid=' . (int)$row['uid'] . '">' . $username . '</a></td>
            <td class="trow1"><span class="bf-plan-badge" style="color:' . $badge_color . ';background:' . $badge_bg . ';">' . $badge_label . '</span> ' . $plan_title . '</td>
            <td class="trow1">$' . $price . '</td>
            <td class="trow1">' . $date . '</td>
            <td class="trow1">
                <form method="post" action="' . $bburl . '/misc.php?action=admin_upgrades&do=approve" style="display:inline">
                    <input type="hidden" name="uid_upgrade" value="' . (int)$row['uid_upgrade'] . '" />
                    <input type="hidden" name="my_post_key" value="' . htmlspecialchars_uni($mybb->post_code) . '" />
                    <button type="submit" class="bf-admin-approve"><i class="fas fa-check"></i> Approve</button>
                </form>
                <form method="post" action="' . $bburl . '/misc.php?action=admin_upgrades&do=deny" style="display:inline;margin-left:6px">
                    <input type="hidden" name="uid_upgrade" value="' . (int)$row['uid_upgrade'] . '" />
                    <input type="hidden" name="my_post_key" value="' . htmlspecialchars_uni($mybb->post_code) . '" />
                    <button type="submit" class="bf-admin-deny"><i class="fas fa-times"></i> Deny</button>
                </form>
            </td>
        </tr>';
    }

    if(!$pending_rows)
    {
        $pending_rows = '<tr><td class="trow1" colspan="5" style="text-align:center;padding:20px;color:#666">No pending upgrade requests.</td></tr>';
    }

    $recent_q = $db->query("
        SELECT u.*, usr.username, p.title as plan_title, p.badge_label, p.badge_color, p.badge_bg
        FROM {$db->table_prefix}user_upgrades u
        JOIN {$db->table_prefix}users usr ON usr.uid = u.uid
        JOIN {$db->table_prefix}upgrade_plans p ON p.pid = u.plan_id
        WHERE u.status IN ('active','expired','denied')
        ORDER BY u.purchase_date DESC
        LIMIT 20
    ");

    $history_rows = '';
    while($row = $db->fetch_array($recent_q))
    {
        $username = htmlspecialchars_uni($row['username']);
        $plan_title = htmlspecialchars_uni($row['plan_title']);
        $status = htmlspecialchars_uni($row['status']);
        $date = my_date('M j, Y', (int)$row['purchase_date']);
        $status_class = $status === 'active' ? 'bf-status-active' : ($status === 'denied' ? 'bf-status-denied' : 'bf-status-expired');
        $history_rows .= '<tr>
            <td class="trow1"><a href="member.php?action=profile&uid=' . (int)$row['uid'] . '">' . $username . '</a></td>
            <td class="trow1">' . $plan_title . '</td>
            <td class="trow1">' . $date . '</td>
            <td class="trow1"><span class="' . $status_class . '">' . ucfirst($status) . '</span></td>
        </tr>';
    }

    $page = '<!DOCTYPE html>
<html>
<head>
    <title>Admin: Manage Upgrades - ' . htmlspecialchars_uni($mybb->settings['bbname']) . '</title>
    ' . $headerinclude . '
</head>
<body>
' . $header . '
<div class="wrapper">
    <div class="container">
        ' . $done_msg . '

        <div class="bf-admin-section">
            <h2><i class="fas fa-wallet" style="color:#f7931a;margin-right:8px"></i> Crypto Wallet Addresses</h2>
            <p style="color:#8a8a8a;font-size:13px;margin-bottom:14px">These addresses are shown to users on the upgrade page.</p>
            <form method="post" action="' . $bburl . '/misc.php?action=admin_upgrades&do=set_wallets">
                <input type="hidden" name="my_post_key" value="' . htmlspecialchars_uni($mybb->post_code) . '" />
                <div class="bf-wallet-grid">
                    <div class="bf-wallet-row"><label><i class="fab fa-bitcoin" style="color:#f7931a"></i> BTC</label><input type="text" name="wallet_btc" value="' . htmlspecialchars_uni($wallets['btc']) . '" placeholder="Bitcoin address" /></div>
                    <div class="bf-wallet-row"><label><i class="fab fa-ethereum" style="color:#627eea"></i> ETH</label><input type="text" name="wallet_eth" value="' . htmlspecialchars_uni($wallets['eth']) . '" placeholder="Ethereum address" /></div>
                    <div class="bf-wallet-row"><label><i class="fas fa-shield-alt" style="color:#ff6600"></i> XMR</label><input type="text" name="wallet_xmr" value="' . htmlspecialchars_uni($wallets['xmr']) . '" placeholder="Monero address" /></div>
                    <div class="bf-wallet-row"><label><i class="fas fa-cube" style="color:#bfbbbb"></i> LTC</label><input type="text" name="wallet_ltc" value="' . htmlspecialchars_uni($wallets['ltc']) . '" placeholder="Litecoin address" /></div>
                </div>
                <button type="submit" class="bf-plan-btn" style="width:auto;margin-top:12px;padding:10px 30px"><i class="fas fa-save"></i> Save Wallets</button>
            </form>
        </div>

        <div class="bf-admin-section">
            <h2><i class="fas fa-clock" style="color:#f39c12;margin-right:8px"></i> Pending Upgrade Requests</h2>
            <table class="tborder" cellspacing="0" cellpadding="6" style="width:100%">
                <thead><tr>
                    <td class="thead">User</td>
                    <td class="thead">Plan</td>
                    <td class="thead">Price</td>
                    <td class="thead">Date</td>
                    <td class="thead">Actions</td>
                </tr></thead>
                <tbody>' . $pending_rows . '</tbody>
            </table>
        </div>

        <div class="bf-admin-section">
            <h2><i class="fas fa-history" style="color:#7c9cb5;margin-right:8px"></i> Recent History</h2>
            <table class="tborder" cellspacing="0" cellpadding="6" style="width:100%">
                <thead><tr>
                    <td class="thead">User</td>
                    <td class="thead">Plan</td>
                    <td class="thead">Date</td>
                    <td class="thead">Status</td>
                </tr></thead>
                <tbody>' . $history_rows . '</tbody>
            </table>
        </div>
    </div>
</div>
' . $footer . '
</body>
</html>';

    echo $page;
    exit;
}
