<?php
// On définit IN_MYBB pour avoir accès aux fichiers protégés
define("IN_MYBB", 1);
require_once "./inc/init.php"; // Charge toute la config, DB incluse

// Liste des domaines à nettoyer
$bad_urls = ['https://breachforums.ac', 'https://breached.rs', 'http://breachforums.ac', 'http://breached.rs'];

// On essaie de détecter la table des pubs (souvent 'advertisements')
$table = TABLE_PREFIX . "advertisements";

echo "Nettoyage de la table : $table ...\n";

foreach ($bad_urls as $url) {
    // On remplace l'URL complète par un chemin relatif '/'
    $db->update_query("advertisements", array(
        "image_url" => "REPLACE(image_url, '$url', '')"
    ), "", "", true); // Le 'true' ici permet d'utiliser la fonction REPLACE SQL
}

echo "Nettoyage terminé ! Les URLs sont maintenant relatives.\n";
echo "N'oublie pas de vider le cache.\n";
?>
