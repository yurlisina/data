<?php

if(!defined("IN_MYBB"))
{
    die("Direct initialization of this file is not allowed.");
}

$plugins->add_hook("index_start", "bf_latestposts_index");

function bf_latestposts_info()
{
    return array(
        "name"          => "BF Latest Posts",
        "description"   => "Shows latest posts sidebar on the index page.",
        "website"       => "",
        "author"        => "BF",
        "authorsite"    => "",
        "version"       => "1.0",
        "compatibility" => "18*"
    );
}

function bf_latestposts_activate() {}
function bf_latestposts_deactivate() {}

function bf_latestposts_index()
{
    global $mybb, $db, $templates, $bf_latest_posts_html;

    $prefix = $db->table_prefix;

    $unviewable = get_unviewable_forums(true);
    $inact_forums = get_inactive_forums();

    $where_extra = '';
    if($unviewable) {
        $where_extra .= " AND t.fid NOT IN ({$unviewable})";
    }
    if($inact_forums) {
        $inact_forums_list = implode(',', $inact_forums);
        $where_extra .= " AND t.fid NOT IN ({$inact_forums_list})";
    }

    $query = $db->query("
        SELECT p.pid, p.tid, p.uid, p.username, p.dateline, p.message,
               t.subject, t.fid, t.replies,
               f.name as forum_name
        FROM {$prefix}posts p
        JOIN {$prefix}threads t ON p.tid = t.tid
        JOIN {$prefix}forums f ON t.fid = f.fid
        JOIN {$prefix}users u ON p.uid = u.uid
        WHERE t.visible = 1 AND p.visible = 1 AND f.type = 'f'{$where_extra}
        ORDER BY p.dateline DESC
        LIMIT 15
    ");

    $posts = array();
    while($post = $db->fetch_array($query))
    {
        $posts[] = $post;
    }

    $avatars = array();
    if(!empty($posts))
    {
        $uids = array();
        foreach($posts as $p) {
            $uids[(int)$p['uid']] = true;
        }
        if(!empty($uids)) {
            $uid_list = implode(',', array_keys($uids));
            $av_query = $db->simple_select('users', 'uid, avatar', "uid IN ({$uid_list})");
            while($av = $db->fetch_array($av_query)) {
                $avatars[(int)$av['uid']] = $av['avatar'];
            }
        }
    }

    $bf_latest_posts_html = '<div class="latestposts lp-box">';
    $bf_latest_posts_html .= '<div class="lp-header"><span class="lp-title"><i class="fas fa-clock" style="margin-right:5px;"></i>Latest Posts</span></div>';
    $bf_latest_posts_html .= '<div class="lp-body">';

    if(empty($posts))
    {
        $bf_latest_posts_html .= '<div style="padding:15px;text-align:center;color:#666;font-size:12px;">No posts yet.</div>';
    }
    else
    {
        foreach($posts as $post)
        {
            $subject = htmlspecialchars_uni($post['subject']);
            $username = htmlspecialchars_uni($post['username']);
            $time = my_date('relative', $post['dateline']);
            $thread_url = 'showthread.php?tid=' . (int)$post['tid'];
            $user_url = 'member.php?action=profile&uid=' . (int)$post['uid'];

            $post_uid = (int)$post['uid'];
            $avatar_url = $mybb->settings['bburl'] . '/images/default_avatar.png';
            if(!empty($avatars[$post_uid]))
            {
                $avatar_url = htmlspecialchars_uni($avatars[$post_uid]);
            }

            $bf_latest_posts_html .= '<div class="lp-item">';
            $bf_latest_posts_html .= '<div class="lp-avatar"><img src="' . $avatar_url . '" alt="" /></div>';
            $bf_latest_posts_html .= '<div class="lp-content">';
            $bf_latest_posts_html .= '<a class="lp-title" href="' . $thread_url . '">' . $subject . '</a>';
            $bf_latest_posts_html .= '<div class="smalltext lp-meta">by <a href="' . $user_url . '"><span class="rf_noob">' . $username . '</span></a> &ndash; ' . $time . '</div>';
            $bf_latest_posts_html .= '</div>';
            $bf_latest_posts_html .= '<div class="lp-count-wrap"><span class="lp-count">' . (int)$post['replies'] . '</span></div>';
            $bf_latest_posts_html .= '</div>';
        }
    }

    $bf_latest_posts_html .= '</div></div>';

    $bf_latest_posts_html .= '<script>
(function(){
var sb=document.getElementById("sidebar");
if(!sb)return;
function applySticky(){
  if(window.innerWidth<=480)return;
  sb.style.setProperty("position","-webkit-sticky");
  sb.style.setProperty("position","sticky");
  sb.style.top="65px";
  sb.style.alignSelf="flex-start";
  sb.style.maxHeight="calc(100vh - 75px)";
  sb.style.overflowY="auto";
}
if(document.readyState==="loading"){
  document.addEventListener("DOMContentLoaded",applySticky);
} else {
  applySticky();
}
window.addEventListener("load",applySticky);
setTimeout(applySticky,500);
})();
</script>';
}
