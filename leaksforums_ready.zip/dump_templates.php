<?php
define("IN_MYBB", 1);
require_once "global.php";

$templates_to_check = ['header', 'index_boardstats', 'index_whosonline', 'welcomeblock_member', 'welcomeblock_guest'];
foreach($templates_to_check as $title) {
    $query = $db->simple_select("templates", "template", "title='" . $db->escape_string($title) . "' AND sid > -2", ["order_by" => "sid", "order_dir" => "desc", "limit" => 1]);
    $template = $db->fetch_field($query, "template");
    echo "--- TEMPLATE: $title ---\n";
    echo $template . "\n\n";
}
