<?php
if(!defined("IN_MYBB"))
{
    die("Direct initialization of this file is not allowed.");
}

$plugins->add_hook("misc_start", "bf_ranks_panel");
$plugins->add_hook("postbit", "bf_ranks_postbit");
$plugins->add_hook("member_profile_end", "bf_ranks_profile");
$plugins->add_hook("global_intermediate", "bf_ranks_navbar");
$plugins->add_hook("xmlhttp", "bf_ranks_ajax");

function bf_ranks_info()
{
    return array(
        "name"          => "BF Rank System",
        "description"   => "Complete rank management panel with badges, user management, and rank display.",
        "website"       => "",
        "author"        => "BF",
        "version"       => "2.0",
        "compatibility" => "18*"
    );
}

function bf_ranks_activate() {}
function bf_ranks_deactivate() {}

function bf_ranks_get_config()
{
    return array(
        4  => array('label' => 'Owner',     'color' => '#ef4444', 'bg' => 'rgba(239,68,68,0.1)',  'border' => 'rgba(239,68,68,0.3)',  'icon' => 'fas fa-crown',       'priority' => 100),
        3  => array('label' => 'Admin',     'color' => '#f472b6', 'bg' => 'rgba(244,114,182,0.1)','border' => 'rgba(244,114,182,0.3)','icon' => 'fas fa-shield-alt',  'priority' => 90),
        6  => array('label' => 'Moderator', 'color' => '#f59e0b', 'bg' => 'rgba(245,158,11,0.1)', 'border' => 'rgba(245,158,11,0.3)', 'icon' => 'fas fa-gavel',       'priority' => 80),
        10 => array('label' => 'Legendary', 'color' => '#a855f7', 'bg' => 'rgba(168,85,247,0.1)', 'border' => 'rgba(168,85,247,0.3)', 'icon' => 'fas fa-gem',         'priority' => 70),
        9  => array('label' => 'Premium',   'color' => '#ef4444', 'bg' => 'rgba(239,68,68,0.1)',  'border' => 'rgba(239,68,68,0.3)',  'icon' => 'fas fa-fire',        'priority' => 60),
        8  => array('label' => 'VIP',       'color' => '#eab308', 'bg' => 'rgba(234,179,8,0.1)',  'border' => 'rgba(234,179,8,0.3)',  'icon' => 'fas fa-star',        'priority' => 50),
        2  => array('label' => 'Member',    'color' => 'hsl(208,43%,26%)', 'bg' => 'hsla(208,43%,26%,0.15)', 'border' => 'hsla(208,40%,67%,0.3)', 'icon' => 'fas fa-user',        'priority' => 10),
        7  => array('label' => 'Banned',    'color' => '#6b7280', 'bg' => 'rgba(107,114,128,0.1)','border' => 'rgba(107,114,128,0.3)','icon' => 'fas fa-ban',         'priority' => 0),
        1  => array('label' => 'Guest',     'color' => '#6b7280', 'bg' => 'rgba(107,114,128,0.1)','border' => 'rgba(107,114,128,0.3)','icon' => 'fas fa-eye',         'priority' => 0),
        5  => array('label' => 'Unverified','color' => '#6b7280', 'bg' => 'rgba(107,114,128,0.1)','border' => 'rgba(107,114,128,0.3)','icon' => 'fas fa-clock',       'priority' => 0),
    );
}

function bf_ranks_get_badge($gid, $size = 'sm')
{
    $config = bf_ranks_get_config();
    if(!isset($config[$gid])) return '';

    $r = $config[$gid];
    $pad = $size === 'lg' ? '5px 12px' : '3px 8px';
    $fs = $size === 'lg' ? '11px' : '10px';

    return '<span class="bf-rank-badge" style="display:inline-flex;align-items:center;gap:4px;padding:'.$pad.';background:'.$r['bg'].';border:1px solid '.$r['border'].';color:'.$r['color'].';font-size:'.$fs.';font-weight:700;border-radius:0;letter-spacing:0.3px;line-height:1;white-space:nowrap;"><i class="'.$r['icon'].'" style="font-size:'.$fs.';"></i> '.$r['label'].'</span>';
}

function bf_ranks_get_user_title($postnum)
{
    global $db;
    $query = $db->simple_select('usertitles', '*', '', array('order_by' => 'posts', 'order_dir' => 'DESC'));
    while($title = $db->fetch_array($query))
    {
        if($postnum >= (int)$title['posts'])
        {
            return $title['title'];
        }
    }
    return 'Newbie';
}

function bf_ranks_postbit(&$post)
{
    $gid = (int)$post['usergroup'];
    $badge = bf_ranks_get_badge($gid);
    if($badge)
    {
        $post['user_details'] = '<div style="margin-bottom:6px;">' . $badge . '</div>' . $post['user_details'];
    }
}

function bf_ranks_profile()
{
    global $memprofile, $db, $awaybit;
    $gid = (int)$memprofile['usergroup'];
    $badge = bf_ranks_get_badge($gid, 'lg');
    $config = bf_ranks_get_config();

    $join_date = my_date('M j, Y', $memprofile['regdate']);
    $posts = my_number_format($memprofile['postnum']);
    $threads = my_number_format($memprofile['threadnum']);
    $rep = my_number_format($memprofile['reputation']);

    $rep_color = 'hsl(208,43%,26%)';
    if($memprofile['reputation'] > 0) $rep_color = '#10b981';
    if($memprofile['reputation'] < 0) $rep_color = '#ef4444';

    $add_groups = '';
    if(!empty($memprofile['additionalgroups']))
    {
        $gids = explode(',', $memprofile['additionalgroups']);
        foreach($gids as $agid)
        {
            $agid = (int)trim($agid);
            if($agid > 0 && isset($config[$agid]))
            {
                $add_groups .= ' ' . bf_ranks_get_badge($agid);
            }
        }
    }

    $rank_card = '<div class="bf-rank-card" style="background:var(--bg-2);border:1px solid var(--border-1);border-radius:8px;overflow:hidden;margin-bottom:16px;">'
        . '<div style="padding:16px 20px;background:var(--bg-3);border-bottom:1px solid var(--border-1);display:flex;align-items:center;justify-content:space-between;">'
        . '<span style="font-size:13px;font-weight:700;color:var(--main-text-color);display:flex;align-items:center;gap:8px;"><i class="fas fa-id-badge" style="color:var(--theme-primary-color);"></i> Rank &amp; Stats</span>'
        . '<span>' . $badge . $add_groups . '</span>'
        . '</div>'
        . '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:0;">'
        . '<div style="padding:16px 14px;text-align:center;border-right:1px solid var(--border-1);"><div style="font-size:18px;font-weight:800;color:var(--main-text-color);">' . $posts . '</div><div style="font-size:10px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px;margin-top:4px;font-weight:600;">Posts</div></div>'
        . '<div style="padding:16px 14px;text-align:center;border-right:1px solid var(--border-1);"><div style="font-size:18px;font-weight:800;color:var(--main-text-color);">' . $threads . '</div><div style="font-size:10px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px;margin-top:4px;font-weight:600;">Threads</div></div>'
        . '<div style="padding:16px 14px;text-align:center;border-right:1px solid var(--border-1);"><div style="font-size:18px;font-weight:800;color:' . $rep_color . ';">' . $rep . '</div><div style="font-size:10px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px;margin-top:4px;font-weight:600;">Reputation</div></div>'
        . '<div style="padding:16px 14px;text-align:center;"><div style="font-size:14px;font-weight:700;color:var(--main-text-color);">' . $join_date . '</div><div style="font-size:10px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px;margin-top:4px;font-weight:600;">Joined</div></div>'
        . '</div></div>';

    $awaybit = $rank_card . $awaybit;
}

function bf_ranks_navbar()
{
    global $mybb, $bf_panel_link;
    $bf_panel_link = '';
    if((int)$mybb->user['usergroup'] === 4 || (int)$mybb->user['usergroup'] === 3)
    {
        $bf_panel_link = '<a href="' . htmlspecialchars_uni($mybb->settings['bburl']) . '/misc.php?action=bf_panel" class="bf-breadcrumb-btn"><i class="fas fa-cog"></i> Panel</a>';
    }
}

function bf_ranks_ajax()
{
    global $mybb, $db;

    if($mybb->get_input('action') !== 'bf_ranks_action') return;

    if((int)$mybb->user['usergroup'] !== 4 && (int)$mybb->user['usergroup'] !== 3)
    {
        header('Content-Type: application/json');
        echo json_encode(array('error' => 'Permission denied'));
        exit;
    }

    verify_post_check($mybb->get_input('my_post_key'));

    $do = $mybb->get_input('do');
    header('Content-Type: application/json');

    if($do === 'set_rank')
    {
        $uid = $mybb->get_input('uid', MyBB::INPUT_INT);
        $new_gid = $mybb->get_input('gid', MyBB::INPUT_INT);

        if($uid <= 0 || $new_gid <= 0)
        {
            echo json_encode(array('error' => 'Invalid parameters'));
            exit;
        }

        $user = get_user($uid);
        if(!$user)
        {
            echo json_encode(array('error' => 'User not found'));
            exit;
        }

        if($uid == 1 && (int)$mybb->user['uid'] !== 1)
        {
            echo json_encode(array('error' => 'Cannot modify the primary admin'));
            exit;
        }

        $my_gid = (int)$mybb->user['usergroup'];
        if($new_gid == 4 && $my_gid != 4)
        {
            echo json_encode(array('error' => 'Only owners can promote to Owner rank'));
            exit;
        }
        if($my_gid != 4 && $my_gid != 3)
        {
            echo json_encode(array('error' => 'Insufficient permissions'));
            exit;
        }

        $db->update_query('users', array(
            'usergroup' => $new_gid,
            'displaygroup' => $new_gid,
        ), "uid={$uid}");

        $config = bf_ranks_get_config();
        $rank_label = isset($config[$new_gid]) ? $config[$new_gid]['label'] : 'Group ' . $new_gid;

        echo json_encode(array('success' => true, 'message' => 'Rank updated to ' . $rank_label));
        exit;
    }

    if($do === 'add_additional')
    {
        $uid = $mybb->get_input('uid', MyBB::INPUT_INT);
        $add_gid = $mybb->get_input('gid', MyBB::INPUT_INT);

        $user = get_user($uid);
        if(!$user) { echo json_encode(array('error' => 'User not found')); exit; }

        $groups = array_filter(explode(',', $user['additionalgroups']));
        if(!in_array($add_gid, $groups))
        {
            $groups[] = $add_gid;
        }

        $db->update_query('users', array(
            'additionalgroups' => implode(',', $groups),
        ), "uid={$uid}");

        echo json_encode(array('success' => true, 'message' => 'Additional group added'));
        exit;
    }

    if($do === 'remove_additional')
    {
        $uid = $mybb->get_input('uid', MyBB::INPUT_INT);
        $rem_gid = $mybb->get_input('gid', MyBB::INPUT_INT);

        $user = get_user($uid);
        if(!$user) { echo json_encode(array('error' => 'User not found')); exit; }

        $groups = array_filter(explode(',', $user['additionalgroups']));
        $groups = array_diff($groups, array($rem_gid));

        $db->update_query('users', array(
            'additionalgroups' => implode(',', $groups),
        ), "uid={$uid}");

        echo json_encode(array('success' => true, 'message' => 'Additional group removed'));
        exit;
    }

    echo json_encode(array('error' => 'Unknown action'));
    exit;
}

function bf_ranks_panel()
{
    global $mybb, $db, $lang, $theme, $templates, $headerinclude, $header, $footer;

    if($mybb->get_input('action') !== 'bf_panel') return;

    if((int)$mybb->user['usergroup'] !== 4 && (int)$mybb->user['usergroup'] !== 3)
    {
        error_no_permission();
        exit;
    }

    $bburl = htmlspecialchars_uni($mybb->settings['bburl']);
    $post_key = htmlspecialchars_uni($mybb->post_code);

    add_breadcrumb("Admin Panel", "misc.php?action=bf_panel");

    $config = bf_ranks_get_config();
    $tab = $mybb->get_input('tab', MyBB::INPUT_STRING);
    if(!in_array($tab, array('ranks', 'users', 'manage', 'stats', 'titles'))) $tab = 'ranks';

    $content = '';

    if($tab === 'ranks')
    {
        $ranks_html = '';
        $query = $db->query("SELECT g.gid, g.title, g.usertitle, g.cancp, g.issupermod, g.canview, g.canpostthreads, g.canpostreplys, (SELECT COUNT(*) FROM {$db->table_prefix}users u WHERE u.usergroup = g.gid) as user_count FROM {$db->table_prefix}usergroups g ORDER BY g.gid");

        while($group = $db->fetch_array($query))
        {
            $gid = (int)$group['gid'];
            $badge = bf_ranks_get_badge($gid, 'lg');
            $count = (int)$group['user_count'];
            $safe_title = htmlspecialchars_uni($group['title']);
            $safe_usertitle = htmlspecialchars_uni($group['usertitle']);
            $perms = array();
            if($group['cancp']) $perms[] = '<span style="color:#10b981;">Admin CP</span>';
            if($group['issupermod']) $perms[] = '<span style="color:#f59e0b;">Super Mod</span>';
            if($group['canview']) $perms[] = '<span style="color:hsl(208,43%,26%);">View</span>';
            if($group['canpostthreads']) $perms[] = '<span style="color:hsl(208,43%,26%);">Post</span>';
            if($group['canpostreplys']) $perms[] = '<span style="color:hsl(208,43%,26%);">Reply</span>';
            $perms_str = implode(' &middot; ', $perms);
            if(empty($perms_str)) $perms_str = '<span style="color:var(--text-muted);">No permissions</span>';

            $ranks_html .= <<<HTML
<tr>
<td class="trow1" style="padding:14px 16px;vertical-align:middle;">{$badge}</td>
<td class="trow1" style="padding:14px 16px;vertical-align:middle;font-weight:600;color:var(--main-text-color);">{$safe_title}</td>
<td class="trow1" style="padding:14px 16px;vertical-align:middle;color:var(--text-muted);">{$safe_usertitle}</td>
<td class="trow1" style="padding:14px 16px;vertical-align:middle;text-align:center;"><span style="background:var(--theme-low-alpha-color);color:var(--theme-primary-color);padding:4px 12px;border-radius:0;font-weight:700;font-size:13px;">{$count}</span></td>
<td class="trow1" style="padding:14px 16px;vertical-align:middle;font-size:11px;">{$perms_str}</td>
</tr>
HTML;
        }

        $content = <<<HTML
<table class="tborder" cellspacing="0" cellpadding="0" width="100%">
<tr><td class="thead" colspan="5"><strong><i class="fas fa-layer-group"></i> All Ranks</strong></td></tr>
<tr class="tcat">
<td style="padding:10px 16px;width:120px;">Badge</td>
<td style="padding:10px 16px;">Group Name</td>
<td style="padding:10px 16px;">User Title</td>
<td style="padding:10px 16px;text-align:center;width:100px;">Users</td>
<td style="padding:10px 16px;width:200px;">Permissions</td>
</tr>
{$ranks_html}
</table>
HTML;
    }
    elseif($tab === 'users')
    {
        $filter_gid = $mybb->get_input('filter_gid', MyBB::INPUT_INT);
        $search = $db->escape_string(trim($mybb->get_input('search')));
        $page = max(1, $mybb->get_input('page', MyBB::INPUT_INT));
        $per_page = 25;
        $offset = ($page - 1) * $per_page;

        $where = '1=1';
        if($filter_gid > 0) $where .= " AND u.usergroup = {$filter_gid}";
        if(!empty($search)) $where .= " AND LOWER(u.username) LIKE '%" . strtolower($search) . "%'";

        $total = (int)$db->fetch_field($db->query("SELECT COUNT(*) as cnt FROM {$db->table_prefix}users u WHERE {$where}"), 'cnt');
        $total_pages = max(1, ceil($total / $per_page));

        $query = $db->query("SELECT u.uid, u.username, u.usergroup, u.additionalgroups, u.postnum, u.reputation, u.regdate, u.lastactive FROM {$db->table_prefix}users u WHERE {$where} ORDER BY u.uid ASC LIMIT {$per_page} OFFSET {$offset}");

        $users_html = '';
        while($user = $db->fetch_array($query))
        {
            $uid = (int)$user['uid'];
            $username = htmlspecialchars_uni($user['username']);
            $badge = bf_ranks_get_badge((int)$user['usergroup']);
            $posts = my_number_format($user['postnum']);
            $rep = my_number_format($user['reputation']);
            $joined = my_date('M j, Y', $user['regdate']);
            $last = $user['lastactive'] > 0 ? my_date('M j, Y', $user['lastactive']) : 'Never';

            $group_options = '';
            foreach($config as $gid => $gcfg)
            {
                $sel = ($gid == (int)$user['usergroup']) ? ' selected' : '';
                $group_options .= '<option value="'.$gid.'"'.$sel.'>'.$gcfg['label'].'</option>';
            }

            $users_html .= <<<HTML
<tr id="user-row-{$uid}">
<td class="trow1" style="padding:12px 16px;vertical-align:middle;">{$uid}</td>
<td class="trow1" style="padding:12px 16px;vertical-align:middle;"><a href="{$bburl}/member.php?action=profile&uid={$uid}" style="font-weight:600;color:var(--theme-secondary-color);">{$username}</a></td>
<td class="trow1" style="padding:12px 16px;vertical-align:middle;">{$badge}</td>
<td class="trow1" style="padding:12px 16px;vertical-align:middle;text-align:center;">{$posts}</td>
<td class="trow1" style="padding:12px 16px;vertical-align:middle;text-align:center;">{$rep}</td>
<td class="trow1" style="padding:12px 16px;vertical-align:middle;">{$joined}</td>
<td class="trow1" style="padding:12px 16px;vertical-align:middle;">
<select onchange="setRank({$uid}, this.value)" style="padding:6px 10px;background:var(--bg-input);border:1px solid var(--border-2);color:var(--main-text-color);border-radius:0;font-size:12px;cursor:pointer;">
{$group_options}
</select>
</td>
</tr>
HTML;
        }

        if(empty($users_html))
        {
            $users_html = '<tr><td class="trow1" colspan="7" style="padding:24px;text-align:center;color:var(--text-muted);">No users found.</td></tr>';
        }

        $filter_options = '<option value="0">All Groups</option>';
        foreach($config as $gid => $gcfg)
        {
            $sel = ($gid == $filter_gid) ? ' selected' : '';
            $filter_options .= '<option value="'.$gid.'"'.$sel.'>'.$gcfg['label'].'</option>';
        }

        $search_val = htmlspecialchars_uni($mybb->get_input('search'));

        $pagination = '';
        if($total_pages > 1)
        {
            $pagination .= '<div style="padding:12px 16px;display:flex;gap:4px;justify-content:center;background:var(--bg-3);border-top:1px solid var(--border-1);">';
            for($i = 1; $i <= $total_pages && $i <= 20; $i++)
            {
                $active = ($i == $page) ? 'background:var(--theme-primary-color);color:#fff;border-color:var(--theme-primary-color);' : 'background:var(--bg-2);color:var(--text-muted);border:1px solid var(--border-1);';
                $pagination .= '<a href="'.$bburl.'/misc.php?action=bf_panel&tab=users&filter_gid='.$filter_gid.'&search='.urlencode($search_val).'&page='.$i.'" style="padding:5px 12px;border-radius:0;font-size:12px;font-weight:600;text-decoration:none;'.$active.'">'.$i.'</a>';
            }
            $pagination .= '</div>';
        }

        $content = <<<HTML
<div style="padding:14px 16px;background:var(--bg-3);border:1px solid var(--border-1);border-radius:8px;margin-bottom:12px;display:flex;gap:10px;align-items:center;flex-wrap:wrap;">
<form method="get" action="{$bburl}/misc.php" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;flex:1;">
<input type="hidden" name="action" value="bf_panel" />
<input type="hidden" name="tab" value="users" />
<input type="text" name="search" value="{$search_val}" placeholder="Search username..." style="padding:8px 14px;flex:1;min-width:200px;" />
<select name="filter_gid" style="padding:8px 12px;">{$filter_options}</select>
<button type="submit" style="background:var(--theme-primary-color);color:#fff;border:none;padding:8px 20px;border-radius:0;cursor:pointer;font-weight:600;font-size:13px;">Filter</button>
</form>
<span style="color:var(--text-muted);font-size:12px;font-weight:500;">{$total} user(s)</span>
</div>
<table class="tborder" cellspacing="0" cellpadding="0" width="100%">
<tr><td class="thead" colspan="7"><strong><i class="fas fa-users"></i> User Management</strong></td></tr>
<tr class="tcat">
<td style="padding:10px 16px;width:60px;">UID</td>
<td style="padding:10px 16px;">Username</td>
<td style="padding:10px 16px;width:120px;">Rank</td>
<td style="padding:10px 16px;text-align:center;width:80px;">Posts</td>
<td style="padding:10px 16px;text-align:center;width:80px;">Rep</td>
<td style="padding:10px 16px;width:120px;">Joined</td>
<td style="padding:10px 16px;width:160px;">Set Rank</td>
</tr>
{$users_html}
</table>
{$pagination}
HTML;
    }
    elseif($tab === 'manage')
    {
        $msg = '';
        if($_SERVER['REQUEST_METHOD'] === 'POST' && $mybb->get_input('do') === 'quick_rank')
        {
            verify_post_check($mybb->get_input('my_post_key'));
            $target_username = trim($mybb->get_input('target_user'));
            $target_gid = $mybb->get_input('target_gid', MyBB::INPUT_INT);

            if(!empty($target_username) && $target_gid > 0)
            {
                $uq = $db->simple_select('users', 'uid, username', "LOWER(username) = '" . $db->escape_string(strtolower($target_username)) . "'");
                $target = $db->fetch_array($uq);

                if($target)
                {
                    $t_uid = (int)$target['uid'];
                    if($t_uid == 1 && (int)$mybb->user['uid'] !== 1)
                    {
                        $msg = '<div style="background:rgba(239,68,68,0.06);border:1px solid rgba(239,68,68,0.15);padding:12px 18px;border-radius:0;color:#ef4444;margin-bottom:12px;font-weight:500;">Cannot modify the primary admin account.</div>';
                    }
                    else
                    {
                        $db->update_query('users', array(
                            'usergroup' => $target_gid,
                            'displaygroup' => $target_gid,
                        ), "uid={$t_uid}");

                        $rank_label = isset($config[$target_gid]) ? $config[$target_gid]['label'] : 'Group ' . $target_gid;
                        $safe_name = htmlspecialchars_uni($target['username']);
                        $msg = '<div style="background:rgba(16,185,129,0.06);border:1px solid rgba(16,185,129,0.15);padding:12px 18px;border-radius:0;color:#10b981;margin-bottom:12px;font-weight:500;"><i class="fas fa-check"></i> '.$safe_name.' has been set to <strong>'.$rank_label.'</strong>.</div>';
                    }
                }
                else
                {
                    $msg = '<div style="background:rgba(239,68,68,0.06);border:1px solid rgba(239,68,68,0.15);padding:12px 18px;border-radius:0;color:#ef4444;margin-bottom:12px;font-weight:500;">User not found.</div>';
                }
            }
        }

        $rank_options = '';
        foreach($config as $gid => $gcfg)
        {
            $rank_options .= '<option value="'.$gid.'">'.$gcfg['label'].'</option>';
        }

        $content = <<<HTML
{$msg}
<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;">
<div class="tborder" style="border-radius:8px;overflow:hidden;">
<div class="thead"><strong><i class="fas fa-user-tag"></i> Quick Rank Assignment</strong></div>
<div style="padding:24px;background:var(--bg-2);">
<form method="post" action="{$bburl}/misc.php?action=bf_panel&tab=manage">
<input type="hidden" name="my_post_key" value="{$post_key}" />
<input type="hidden" name="do" value="quick_rank" />
<div style="margin-bottom:16px;">
<label style="display:block;font-size:12px;font-weight:600;color:var(--text-muted);margin-bottom:6px;text-transform:uppercase;letter-spacing:0.3px;">Username</label>
<input type="text" name="target_user" placeholder="Enter username..." style="width:100%;box-sizing:border-box;" required />
</div>
<div style="margin-bottom:20px;">
<label style="display:block;font-size:12px;font-weight:600;color:var(--text-muted);margin-bottom:6px;text-transform:uppercase;letter-spacing:0.3px;">Rank</label>
<select name="target_gid" style="width:100%;box-sizing:border-box;padding:9px 14px;">{$rank_options}</select>
</div>
<button type="submit" style="background:var(--theme-primary-color);color:#fff;border:none;padding:10px 28px;border-radius:0;cursor:pointer;font-weight:600;font-size:13px;width:100%;">Apply Rank</button>
</form>
</div>
</div>
<div class="tborder" style="border-radius:8px;overflow:hidden;">
<div class="thead"><strong><i class="fas fa-info-circle"></i> Rank Information</strong></div>
<div style="padding:24px;background:var(--bg-2);">
<div style="display:flex;flex-direction:column;gap:10px;">
HTML;

        foreach($config as $gid => $gcfg)
        {
            if($gid == 1 || $gid == 5) continue;
            $badge = bf_ranks_get_badge($gid, 'lg');
            $desc = '';
            if($gid == 4) $desc = 'Full admin access, all permissions';
            elseif($gid == 3) $desc = 'Admin panel access, super moderator';
            elseif($gid == 6) $desc = 'Moderation tools, thread management';
            elseif($gid == 10) $desc = 'Legendary tier, all premium features';
            elseif($gid == 9) $desc = 'Premium tier, enhanced features';
            elseif($gid == 8) $desc = 'VIP tier, basic premium features';
            elseif($gid == 2) $desc = 'Standard registered member';
            elseif($gid == 7) $desc = 'Banned from the forum';

            $content .= '<div style="display:flex;align-items:center;justify-content:space-between;padding:8px 0;border-bottom:1px solid var(--border-1);">';
            $content .= '<span>'.$badge.'</span>';
            $content .= '<span style="font-size:12px;color:var(--text-muted);">'.$desc.'</span>';
            $content .= '</div>';
        }

        $content .= <<<HTML
</div>
</div>
</div>
</div>
HTML;
    }
    elseif($tab === 'stats')
    {
        $stats_html = '';

        $total_users = (int)$db->fetch_field($db->simple_select('users', 'COUNT(*) as cnt'), 'cnt');
        $total_posts = (int)$db->fetch_field($db->simple_select('posts', 'COUNT(*) as cnt'), 'cnt');
        $total_threads = (int)$db->fetch_field($db->simple_select('threads', 'COUNT(*) as cnt'), 'cnt');

        $query = $db->query("SELECT g.gid, g.title, COUNT(u.uid) as cnt FROM {$db->table_prefix}usergroups g LEFT JOIN {$db->table_prefix}users u ON u.usergroup = g.gid GROUP BY g.gid, g.title ORDER BY cnt DESC");

        $group_stats = '';
        while($row = $db->fetch_array($query))
        {
            $gid = (int)$row['gid'];
            $badge = bf_ranks_get_badge($gid);
            $count = (int)$row['cnt'];
            $pct = $total_users > 0 ? round($count / $total_users * 100, 1) : 0;

            $bar_color = isset($config[$gid]) ? $config[$gid]['color'] : 'hsl(208,43%,26%)';

            $group_stats .= <<<HTML
<div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-bottom:1px solid var(--border-1);">
<div style="width:110px;">{$badge}</div>
<div style="flex:1;">
<div style="background:var(--bg-3);border-radius:0;height:8px;overflow:hidden;">
<div style="background:{$bar_color};height:100%;width:{$pct}%;border-radius:0;min-width:2px;"></div>
</div>
</div>
<div style="width:80px;text-align:right;font-weight:700;color:var(--main-text-color);font-size:13px;">{$count}</div>
<div style="width:50px;text-align:right;color:var(--text-muted);font-size:12px;">{$pct}%</div>
</div>
HTML;
        }

        $content = <<<HTML
<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:16px;">
<div style="background:var(--bg-2);border:1px solid var(--border-1);border-radius:8px;padding:24px;text-align:center;">
<div style="font-size:28px;font-weight:800;color:var(--theme-primary-color);">{$total_users}</div>
<div style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px;margin-top:6px;font-weight:600;">Total Users</div>
</div>
<div style="background:var(--bg-2);border:1px solid var(--border-1);border-radius:8px;padding:24px;text-align:center;">
<div style="font-size:28px;font-weight:800;color:var(--green);">{$total_threads}</div>
<div style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px;margin-top:6px;font-weight:600;">Total Threads</div>
</div>
<div style="background:var(--bg-2);border:1px solid var(--border-1);border-radius:8px;padding:24px;text-align:center;">
<div style="font-size:28px;font-weight:800;color:var(--orange);">{$total_posts}</div>
<div style="font-size:11px;color:var(--text-muted);text-transform:uppercase;letter-spacing:0.5px;margin-top:6px;font-weight:600;">Total Posts</div>
</div>
</div>
<div class="tborder" style="border-radius:8px;overflow:hidden;">
<div class="thead"><strong><i class="fas fa-chart-bar"></i> Users by Rank</strong></div>
<div style="padding:16px 20px;background:var(--bg-2);">
{$group_stats}
</div>
</div>
HTML;
    }
    elseif($tab === 'titles')
    {
        $msg = '';
        if($_SERVER['REQUEST_METHOD'] === 'POST')
        {
            verify_post_check($mybb->get_input('my_post_key'));
            $do = $mybb->get_input('do');

            if($do === 'add_title')
            {
                $t_name = trim($mybb->get_input('title_name'));
                $t_posts = $mybb->get_input('title_posts', MyBB::INPUT_INT);
                $t_stars = $mybb->get_input('title_stars', MyBB::INPUT_INT);

                if(!empty($t_name) && $t_posts >= 0)
                {
                    $db->insert_query('usertitles', array(
                        'title' => $db->escape_string($t_name),
                        'posts' => $t_posts,
                        'stars' => max(0, min(10, $t_stars)),
                        'starimage' => '',
                    ));
                    $msg = '<div style="background:rgba(16,185,129,0.06);border:1px solid rgba(16,185,129,0.15);padding:12px 18px;border-radius:0;color:#10b981;margin-bottom:12px;font-weight:500;"><i class="fas fa-check"></i> Title added.</div>';
                }
            }
            elseif($do === 'delete_title')
            {
                $utid = $mybb->get_input('utid', MyBB::INPUT_INT);
                if($utid > 0)
                {
                    $db->delete_query('usertitles', "utid={$utid}");
                    $msg = '<div style="background:rgba(16,185,129,0.06);border:1px solid rgba(16,185,129,0.15);padding:12px 18px;border-radius:0;color:#10b981;margin-bottom:12px;font-weight:500;"><i class="fas fa-check"></i> Title deleted.</div>';
                }
            }
        }

        $titles_html = '';
        $query = $db->simple_select('usertitles', '*', '', array('order_by' => 'posts', 'order_dir' => 'ASC'));
        while($title = $db->fetch_array($query))
        {
            $utid = (int)$title['utid'];
            $name = htmlspecialchars_uni($title['title']);
            $posts = (int)$title['posts'];
            $stars = (int)$title['stars'];
            $stars_display = str_repeat('<i class="fas fa-star" style="color:var(--theme-primary-color);font-size:10px;"></i>', $stars);

            $titles_html .= <<<HTML
<tr>
<td class="trow1" style="padding:12px 16px;font-weight:600;color:var(--main-text-color);">{$name}</td>
<td class="trow1" style="padding:12px 16px;text-align:center;color:var(--text-muted);">{$posts}+</td>
<td class="trow1" style="padding:12px 16px;">{$stars_display}</td>
<td class="trow1" style="padding:12px 16px;text-align:center;">
<form method="post" action="{$bburl}/misc.php?action=bf_panel&tab=titles" style="display:inline;">
<input type="hidden" name="my_post_key" value="{$post_key}" />
<input type="hidden" name="do" value="delete_title" />
<input type="hidden" name="utid" value="{$utid}" />
<button type="submit" onclick="return confirm('Delete this title?');" style="background:rgba(239,68,68,0.08);color:var(--red);border:1px solid rgba(239,68,68,0.15);padding:4px 12px;border-radius:0;cursor:pointer;font-size:11px;font-weight:600;"><i class="fas fa-trash"></i></button>
</form>
</td>
</tr>
HTML;
        }

        $content = <<<HTML
{$msg}
<div style="display:grid;grid-template-columns:2fr 1fr;gap:16px;">
<div class="tborder" style="border-radius:8px;overflow:hidden;">
<div class="thead"><strong><i class="fas fa-trophy"></i> User Titles (Post-Based)</strong></div>
{$titles_html}
</div>
<div class="tborder" style="border-radius:8px;overflow:hidden;align-self:start;">
<div class="thead"><strong><i class="fas fa-plus"></i> Add Title</strong></div>
<div style="padding:20px;background:var(--bg-2);">
<form method="post" action="{$bburl}/misc.php?action=bf_panel&tab=titles">
<input type="hidden" name="my_post_key" value="{$post_key}" />
<input type="hidden" name="do" value="add_title" />
<div style="margin-bottom:14px;">
<label style="display:block;font-size:11px;font-weight:600;color:var(--text-muted);margin-bottom:5px;text-transform:uppercase;letter-spacing:0.3px;">Title Name</label>
<input type="text" name="title_name" placeholder="e.g. Elite Member" style="width:100%;box-sizing:border-box;" required />
</div>
<div style="margin-bottom:14px;">
<label style="display:block;font-size:11px;font-weight:600;color:var(--text-muted);margin-bottom:5px;text-transform:uppercase;letter-spacing:0.3px;">Min. Posts</label>
<input type="text" name="title_posts" placeholder="e.g. 100" style="width:100%;box-sizing:border-box;" required />
</div>
<div style="margin-bottom:16px;">
<label style="display:block;font-size:11px;font-weight:600;color:var(--text-muted);margin-bottom:5px;text-transform:uppercase;letter-spacing:0.3px;">Stars (0-10)</label>
<input type="text" name="title_stars" placeholder="e.g. 3" style="width:100%;box-sizing:border-box;" />
</div>
<button type="submit" style="background:var(--theme-primary-color);color:#fff;border:none;padding:10px;border-radius:0;cursor:pointer;font-weight:600;font-size:13px;width:100%;">Add Title</button>
</form>
</div>
</div>
</div>
HTML;
    }

    $tabs = array(
        'ranks'  => array('icon' => 'fas fa-layer-group', 'label' => 'Ranks'),
        'users'  => array('icon' => 'fas fa-users',       'label' => 'Users'),
        'manage' => array('icon' => 'fas fa-user-tag',    'label' => 'Manage'),
        'titles' => array('icon' => 'fas fa-trophy',      'label' => 'Titles'),
        'stats'  => array('icon' => 'fas fa-chart-bar',   'label' => 'Stats'),
    );

    $tabs_html = '';
    foreach($tabs as $t_key => $t_info)
    {
        $active = ($tab === $t_key) ? 'background:var(--theme-primary-color);color:#fff;border-color:var(--theme-primary-color);' : 'background:var(--bg-2);color:var(--text-muted);border:1px solid var(--border-1);';
        $tabs_html .= '<a href="'.$bburl.'/misc.php?action=bf_panel&tab='.$t_key.'" style="display:inline-flex;align-items:center;gap:6px;padding:8px 18px;border-radius:0;font-size:12px;font-weight:600;text-decoration:none;transition:all .2s;'.$active.'"><i class="'.$t_info['icon'].'"></i> '.$t_info['label'].'</a> ';
    }

    $page_html = <<<HTML
<html>
<head>
<title>{$mybb->settings['bbname']} - Admin Panel</title>
{$headerinclude}
</head>
<body>
{$header}
<div style="margin-bottom:14px;display:flex;gap:6px;flex-wrap:wrap;">
{$tabs_html}
</div>
{$content}
<script>
function setRank(uid, gid) {
    if(!confirm('Change this user\\'s rank?')) return;
    var xhr = new XMLHttpRequest();
    xhr.open('POST', rootpath + '/xmlhttp.php?action=bf_ranks_action&do=set_rank', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
        try {
            var r = JSON.parse(xhr.responseText);
            if(r.success) {
                var row = document.getElementById('user-row-' + uid);
                if(row) row.style.background = 'rgba(16,185,129,0.05)';
                setTimeout(function(){ location.reload(); }, 800);
            } else {
                alert(r.error || 'Error');
            }
        } catch(e) { alert('Error processing request'); }
    };
    xhr.send('my_post_key={$post_key}&uid=' + uid + '&gid=' + gid);
}
</script>
{$footer}
</body>
</html>
HTML;

    output_page($page_html);
    exit;
}
