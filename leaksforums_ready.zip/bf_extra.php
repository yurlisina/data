<?php
if(!defined("IN_MYBB"))
{
    die("Direct initialization of this file is not allowed.");
}

$plugins->add_hook("parse_message_end", "bf_extra_parse");
$plugins->add_hook("postbit", "bf_extra_postbit");
$plugins->add_hook("showthread_start", "bf_extra_bookmark_btn");
$plugins->add_hook("xmlhttp", "bf_extra_xmlhttp");
$plugins->add_hook("misc_start", "bf_extra_misc");

function bf_extra_info()
{
    return array(
        "name"          => "BF Extra Features",
        "description"   => "@Mentions, [spoiler] BBCode, thread bookmarks, online indicator, who-liked display, AJAX quick reply.",
        "website"       => "",
        "author"        => "BF",
        "version"       => "1.0",
        "compatibility" => "18*"
    );
}

function bf_extra_activate()
{
    global $db;
    $prefix = $db->table_prefix;

    if(!$db->table_exists('bf_bookmarks'))
    {
        $db->write_query("CREATE TABLE IF NOT EXISTS {$prefix}bf_bookmarks (
            bid SERIAL PRIMARY KEY,
            uid INT NOT NULL DEFAULT 0,
            tid INT NOT NULL DEFAULT 0,
            dateline INT NOT NULL DEFAULT 0
        )");
        $db->write_query("CREATE UNIQUE INDEX IF NOT EXISTS idx_bf_bookmark_unique ON {$prefix}bf_bookmarks (uid, tid)");
        $db->write_query("CREATE INDEX IF NOT EXISTS idx_bf_bookmark_uid ON {$prefix}bf_bookmarks (uid)");
    }
}

function bf_extra_deactivate() {}

function bf_extra_ensure_tables()
{
    global $db;
    static $checked = false;
    if($checked) return;
    $checked = true;
    if(!$db->table_exists('bf_bookmarks'))
    {
        bf_extra_activate();
    }
}

function bf_extra_parse($message)
{
    $message = bf_extra_mentions($message);
    $message = bf_extra_spoiler($message);
    return $message;
}

function bf_extra_mentions($message)
{
    global $db;

    if(strpos($message, '@') === false) return $message;

    static $user_cache = array();

    $parts = preg_split('/(<[^>]*>)/', $message, -1, PREG_SPLIT_DELIM_CAPTURE);
    $rebuilt = '';
    foreach($parts as $i => $part)
    {
        if($i % 2 === 1)
        {
            $rebuilt .= $part;
            continue;
        }

        if(strpos($part, '@') !== false && preg_match_all('/@([a-zA-Z0-9_\-]{3,30})/', $part, $all_matches))
        {
            $processed = array();
            foreach($all_matches[1] as $username)
            {
                $lower = my_strtolower($username);
                if(isset($processed[$lower])) continue;
                $processed[$lower] = true;

                if(!isset($user_cache[$lower]))
                {
                    $q = $db->simple_select('users', 'uid, username, usergroup', "LOWER(username)='" . $db->escape_string($lower) . "'", array('limit' => 1));
                    if($db->num_rows($q) > 0)
                    {
                        $user_cache[$lower] = $db->fetch_array($q);
                    }
                    else
                    {
                        $user_cache[$lower] = false;
                    }
                }

                if($user_cache[$lower] === false) continue;

                $u = $user_cache[$lower];
                $safe_name = htmlspecialchars_uni($u['username']);
                $uid = (int)$u['uid'];
                $gid = (int)$u['usergroup'];

                $color = '#7c9cb5';
                if($gid === 4) $color = '#e74c3c';
                elseif($gid === 3) $color = '#9b59b6';
                elseif($gid === 6) $color = '#e67e22';
                elseif($gid === 8) $color = '#f1c40f';
                elseif($gid === 9) $color = '#e74c3c';
                elseif($gid === 10) $color = '#9b59b6';

                $replacement = '<a href="member.php?action=profile&amp;uid=' . $uid . '" class="bf-mention" style="color:' . $color . '">@' . $safe_name . '</a>';
                $part = str_replace('@' . $username, $replacement, $part);
            }
        }
        $rebuilt .= $part;
    }

    return $rebuilt;
}

function bf_extra_spoiler($message)
{
    $count = 0;
    $max_iterations = 10;

    while(stripos($message, '[spoiler') !== false && $count < $max_iterations)
    {
        $message = preg_replace(
            '/\[spoiler\](.*?)\[\/spoiler\]/is',
            '<div class="bf-spoiler">
                <div class="bf-spoiler-header" onclick="this.parentNode.classList.toggle(\'bf-spoiler-open\')">
                    <i class="fas fa-eye-slash"></i> Spoiler <i class="fas fa-chevron-down bf-spoiler-arrow"></i>
                </div>
                <div class="bf-spoiler-content">$1</div>
            </div>',
            $message
        );

        $message = preg_replace(
            '/\[spoiler=([^\]]*)\](.*?)\[\/spoiler\]/is',
            '<div class="bf-spoiler">
                <div class="bf-spoiler-header" onclick="this.parentNode.classList.toggle(\'bf-spoiler-open\')">
                    <i class="fas fa-eye-slash"></i> $1 <i class="fas fa-chevron-down bf-spoiler-arrow"></i>
                </div>
                <div class="bf-spoiler-content">$2</div>
            </div>',
            $message
        );

        $count++;
    }

    if(stripos($message, '[alert') !== false)
    {
        $alert_types = array(
            'info'    => array('fa-info-circle', '#3498db'),
            'warning' => array('fa-exclamation-triangle', '#f39c12'),
            'danger'  => array('fa-times-circle', '#e74c3c'),
            'success' => array('fa-check-circle', '#2ecc71'),
        );

        foreach($alert_types as $type => $info)
        {
            $message = preg_replace(
                '/\[alert=' . $type . '\](.*?)\[\/alert\]/is',
                '<div class="bf-alert bf-alert-' . $type . '">
                    <i class="fas ' . $info[0] . '"></i> $1
                </div>',
                $message
            );
        }

        $message = preg_replace(
            '/\[alert\](.*?)\[\/alert\]/is',
            '<div class="bf-alert bf-alert-info">
                <i class="fas fa-info-circle"></i> $1
            </div>',
            $message
        );
    }

    if(stripos($message, '[progress') !== false)
    {
        $message = preg_replace_callback(
            '/\[progress=(\d{1,3})\](.*?)\[\/progress\]/is',
            'bf_extra_progress_callback',
            $message
        );
    }

    return $message;
}

function bf_extra_progress_callback($m)
{
    $val = min(100, max(0, (int)$m[1]));
    $label = $m[2];
    return '<div class="bf-progress-wrap">
        <div class="bf-progress-label">' . $label . '</div>
        <div class="bf-progress-bar">
            <div class="bf-progress-fill" style="width:' . $val . '%">' . $val . '%</div>
        </div>
    </div>';
}

function bf_extra_postbit(&$post)
{
    global $mybb, $db;

    $puid = (int)$post['uid'];
    $pid = (int)$post['pid'];

    $online_threshold = TIME_NOW - 900;
    $lastactive = (int)($post['lastactive'] ?? 0);
    if($lastactive > $online_threshold)
    {
        $online_dot = '<span class="bf-online-dot bf-online" title="Online"></span>';
    }
    else
    {
        $online_dot = '<span class="bf-online-dot bf-offline" title="Offline"></span>';
    }
    $post['profilelink'] = $online_dot . $post['profilelink'];

    $likers_html = '';
    $lq = $db->query("
        SELECT l.uid, u.username, u.usergroup
        FROM {$db->table_prefix}bf_post_likes l
        JOIN {$db->table_prefix}users u ON l.uid = u.uid
        WHERE l.pid = {$pid}
        ORDER BY l.dateline DESC
        LIMIT 5
    ");
    $liker_names = array();
    $total_likers = 0;
    while($liker = $db->fetch_array($lq))
    {
        $liker_names[] = '<a href="member.php?action=profile&uid=' . (int)$liker['uid'] . '" class="bf-liker-name">' . htmlspecialchars_uni($liker['username']) . '</a>';
        $total_likers++;
    }

    if(!empty($liker_names))
    {
        $total_all = (int)$db->fetch_field($db->simple_select('bf_post_likes', 'COUNT(*) as cnt', "pid={$pid}"), 'cnt');
        $names_str = implode(', ', $liker_names);
        if($total_all > 5)
        {
            $names_str .= ' and ' . ($total_all - 5) . ' others';
        }
        $likers_html = '<div class="bf-likers"><i class="fas fa-heart" style="color:#e74c3c;margin-right:4px;font-size:10px"></i>' . $names_str . ' liked this</div>';
    }

    if(!isset($post['bf_likers_html']))
    {
        $post['bf_likers_html'] = $likers_html;
    }

    if(!empty($post['edituid']) && (int)$post['edituid'] > 0 && !empty($post['edittime']))
    {
        $edit_user = get_user((int)$post['edituid']);
        $edit_name = $edit_user ? htmlspecialchars_uni($edit_user['username']) : 'Unknown';
        $edit_time = my_date('relative', (int)$post['edittime']);
        $edit_reason = !empty($post['editreason']) ? ' — ' . htmlspecialchars_uni($post['editreason']) : '';

        $post['post_meta'] = (isset($post['post_meta']) ? $post['post_meta'] : '') .
            '<div class="bf-edit-info"><i class="fas fa-pen" style="margin-right:4px"></i>Last edited by <strong>' . $edit_name . '</strong> ' . $edit_time . $edit_reason . '</div>';
    }
}

function bf_extra_bookmark_btn()
{
    global $mybb, $db, $thread, $footer;

    bf_extra_ensure_tables();

    if($mybb->user['uid'] <= 0 || empty($thread['tid'])) return;

    $tid = (int)$thread['tid'];
    $uid = (int)$mybb->user['uid'];

    $is_bookmarked = false;
    $chk = $db->simple_select('bf_bookmarks', 'bid', "uid={$uid} AND tid={$tid}");
    if($db->num_rows($chk) > 0) $is_bookmarked = true;

    $btn_class = $is_bookmarked ? 'bf-bookmarked' : '';
    $btn_icon = $is_bookmarked ? 'fas fa-bookmark' : 'far fa-bookmark';
    $btn_text = $is_bookmarked ? 'Bookmarked' : 'Bookmark';

    $bookmark_html = '<div class="bf-bookmark-wrap">
        <a href="javascript:void(0)" onclick="bfToggleBookmark(' . $tid . ')" id="bf-bookmark-btn" class="bf-bookmark-btn ' . $btn_class . '">
            <i class="' . $btn_icon . '" id="bf-bookmark-icon"></i>
            <span id="bf-bookmark-text">' . $btn_text . '</span>
        </a>
    </div>';

    $post_key = htmlspecialchars_uni($mybb->post_code);
    $bookmark_js = '<script>
function bfToggleBookmark(tid) {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "xmlhttp.php?action=bf_bookmark", true);
    xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
    xhr.onload = function() {
        if(xhr.status === 200) {
            try {
                var r = JSON.parse(xhr.responseText);
                var btn = document.getElementById("bf-bookmark-btn");
                var icon = document.getElementById("bf-bookmark-icon");
                var text = document.getElementById("bf-bookmark-text");
                if(r.action === "added") {
                    btn.classList.add("bf-bookmarked");
                    icon.className = "fas fa-bookmark";
                    text.textContent = "Bookmarked";
                } else {
                    btn.classList.remove("bf-bookmarked");
                    icon.className = "far fa-bookmark";
                    text.textContent = "Bookmark";
                }
            } catch(e) {}
        }
    };
    xhr.send("tid="+tid+"&my_post_key=' . $post_key . '");
}
</script>';

    $footer .= $bookmark_html . $bookmark_js;
}

function bf_extra_xmlhttp()
{
    global $mybb, $db;

    $action = $mybb->get_input('action');

    if($action === 'bf_bookmark')
    {
        if($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); exit; }

        bf_extra_ensure_tables();
        if($mybb->user['uid'] <= 0) { xmlhttp_error('Login required.'); return; }
        if((int)$mybb->user['usergroup'] === 7) { xmlhttp_error('No permission.'); return; }
        verify_post_check($mybb->get_input('my_post_key'));

        $tid = $mybb->get_input('tid', MyBB::INPUT_INT);
        if($tid <= 0) { xmlhttp_error('Invalid thread.'); return; }

        $thread_check = $db->simple_select('threads', 'tid, visible, fid', "tid={$tid}");
        if($db->num_rows($thread_check) == 0) { xmlhttp_error('Thread not found.'); return; }
        $tdata = $db->fetch_array($thread_check);
        if((int)$tdata['visible'] !== 1) { xmlhttp_error('Thread not accessible.'); return; }

        $forumpermissions = forum_permissions((int)$tdata['fid']);
        if(!$forumpermissions['canview'] || !$forumpermissions['canviewthreads'])
        {
            xmlhttp_error('No permission to access this thread.');
            return;
        }

        $uid = (int)$mybb->user['uid'];

        $existing = $db->simple_select('bf_bookmarks', 'bid', "uid={$uid} AND tid={$tid}");
        if($db->num_rows($existing) > 0)
        {
            $db->delete_query('bf_bookmarks', "uid={$uid} AND tid={$tid}");
            $result_action = 'removed';
        }
        else
        {
            $bookmark_count = (int)$db->fetch_field($db->simple_select('bf_bookmarks', 'COUNT(*) as cnt', "uid={$uid}"), 'cnt');
            if($bookmark_count >= 200)
            {
                xmlhttp_error('You have reached the maximum number of bookmarks (200).');
                return;
            }

            $db->insert_query('bf_bookmarks', array(
                'uid' => $uid,
                'tid' => $tid,
                'dateline' => TIME_NOW,
            ));
            $result_action = 'added';
        }

        header('Content-Type: application/json');
        echo json_encode(array('action' => $result_action));
        exit;
    }

}

function bf_extra_misc()
{
    global $mybb, $db, $headerinclude, $header, $footer;

    if($mybb->get_input('action') !== 'bookmarks') return;

    bf_extra_ensure_tables();

    if($mybb->user['uid'] <= 0)
    {
        error_no_permission();
        exit;
    }

    $uid = (int)$mybb->user['uid'];

    add_breadcrumb("My Bookmarks", "misc.php?action=bookmarks");

    $unviewable = get_unviewable_forums(true);
    $inactiveforums = get_inactive_forums();
    $forum_where = '';
    if($unviewable)
    {
        $forum_where .= " AND t.fid NOT IN ({$unviewable})";
    }
    if($inactiveforums)
    {
        $inactive_list = implode(',', $inactiveforums);
        $forum_where .= " AND t.fid NOT IN ({$inactive_list})";
    }

    $query = $db->query("
        SELECT b.bid, b.tid, b.dateline, t.subject, t.replies, t.views, t.lastpost, t.lastposter, t.fid,
               f.name as forum_name, u.username as thread_author
        FROM {$db->table_prefix}bf_bookmarks b
        JOIN {$db->table_prefix}threads t ON b.tid = t.tid
        JOIN {$db->table_prefix}forums f ON t.fid = f.fid
        LEFT JOIN {$db->table_prefix}users u ON t.uid = u.uid
        WHERE b.uid = {$uid} AND t.visible = 1{$forum_where}
        ORDER BY b.dateline DESC
        LIMIT 50
    ");

    $rows_html = '';
    $count = 0;
    while($row = $db->fetch_array($query))
    {
        $subject = htmlspecialchars_uni($row['subject']);
        $forum_name = htmlspecialchars_uni($row['forum_name']);
        $author = htmlspecialchars_uni($row['thread_author'] ?? 'Unknown');
        $replies = number_format((int)$row['replies']);
        $views = number_format((int)$row['views']);
        $lastpost_date = my_date('relative', (int)$row['lastpost']);
        $lastposter = htmlspecialchars_uni($row['lastposter']);
        $tid = (int)$row['tid'];
        $fid = (int)$row['fid'];
        $trow = ($count % 2 == 0) ? 'trow1' : 'trow2';

        $rows_html .= '<tr>
            <td class="' . $trow . '" style="padding:10px 12px">
                <div><a href="showthread.php?tid=' . $tid . '" style="font-weight:bold;font-size:13px">' . $subject . '</a></div>
                <div style="font-size:11px;color:#666;margin-top:3px">
                    <a href="forumdisplay.php?fid=' . $fid . '" style="color:#666">' . $forum_name . '</a> &middot; by ' . $author . '
                </div>
            </td>
            <td class="' . $trow . '" style="text-align:center;font-size:12px">' . $replies . '</td>
            <td class="' . $trow . '" style="text-align:center;font-size:12px">' . $views . '</td>
            <td class="' . $trow . '" style="font-size:11px;color:#8a8a8a;padding:10px 12px">
                <div>' . $lastpost_date . '</div>
                <div style="color:#666">by ' . $lastposter . '</div>
            </td>
            <td class="' . $trow . '" style="text-align:center">
                <a href="javascript:void(0)" onclick="bfRemoveBookmark(' . $tid . ',this)" class="bf-remove-bookmark" title="Remove"><i class="fas fa-times"></i></a>
            </td>
        </tr>';
        $count++;
    }

    if(!$rows_html)
    {
        $rows_html = '<tr><td class="trow1" colspan="5" style="text-align:center;padding:30px;color:#666;font-size:13px">
            <i class="far fa-bookmark" style="font-size:24px;display:block;margin-bottom:10px"></i>
            You have no bookmarked threads yet. Click the bookmark icon on any thread to save it here.
        </td></tr>';
    }

    $post_key = htmlspecialchars_uni($mybb->post_code);

    $page = '<!DOCTYPE html><html><head><title>My Bookmarks</title>' . $headerinclude . '</head><body>' . $header . '
    <div class="wrapper"><div class="container">
        <table border="0" cellspacing="1" cellpadding="0" class="tborder" style="width:100%">
        <tr>
            <td class="thead" colspan="5"><strong><i class="fas fa-bookmark" style="margin-right:6px"></i> My Bookmarks (' . $count . ')</strong></td>
        </tr>
        <tr>
            <td class="tcat" style="width:50%"><strong>Thread</strong></td>
            <td class="tcat" style="text-align:center;width:10%"><strong>Replies</strong></td>
            <td class="tcat" style="text-align:center;width:10%"><strong>Views</strong></td>
            <td class="tcat" style="width:22%"><strong>Last Post</strong></td>
            <td class="tcat" style="text-align:center;width:8%"></td>
        </tr>
        ' . $rows_html . '
        </table>
    </div></div>
    <script>
    function bfRemoveBookmark(tid, el) {
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "xmlhttp.php?action=bf_bookmark", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onload = function() {
            if(xhr.status === 200) {
                var row = el.closest("tr");
                if(row) row.style.display = "none";
            }
        };
        xhr.send("tid="+tid+"&my_post_key=' . $post_key . '");
    }
    </script>
    ' . $footer . '</body></html>';

    echo $page;
    exit;
}
