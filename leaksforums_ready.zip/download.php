<?php
$key = $_GET['k'] ?? '';
if($key !== 'bf_deploy_2024_x9k') { http_response_code(403); die('Forbidden'); }

$file = $_GET['f'] ?? '';
$allowed = array(
    'bf_shoutbox.php' => __DIR__ . '/../inc/plugins/bf_shoutbox.php',
    'bf_features.php' => __DIR__ . '/../inc/plugins/bf_features.php',
    'bf_ranks.php' => __DIR__ . '/../inc/plugins/bf_ranks.php',
    'bf_upgrades.php' => __DIR__ . '/../inc/plugins/bf_upgrades.php',
    'custom.min.css' => __DIR__ . '/../cache/themes/theme3/custom.min.css',
);

if(!isset($allowed[$file])) { http_response_code(404); die('Not found'); }

$path = realpath($allowed[$file]);
if(!$path || !file_exists($path)) { http_response_code(404); die('File not found'); }

header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . basename($file) . '"');
header('Content-Length: ' . filesize($path));
readfile($path);
