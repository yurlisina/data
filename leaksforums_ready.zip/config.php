<?php
/**
 * Database configuration
 *
 * MyBB 1.8 - PostgreSQL configuration for Replit
 */

$config['database']['type'] = 'pgsql';
$config['database']['database'] = getenv('PGDATABASE') ?: 'heliumdb';
$config['database']['table_prefix'] = 'mybb_';

$config['database']['hostname'] = getenv('PGHOST') ?: 'localhost';
$config['database']['username'] = getenv('PGUSER') ?: 'runner';
$config['database']['password'] = getenv('PGPASSWORD') ?: '';

/**
 * Admin CP directory
 */
$config['admin_dir'] = 'bf_s3cur3_p4n3l_x7k9m2v8q1';

/**
 * Hide all Admin CP links
 */
$config['hide_admin_links'] = 1;

/**
 * Data-cache configuration
 */
$config['cache_store'] = 'db';

/**
 * Memcache configuration
 */
$config['memcache']['host'] = 'localhost';
$config['memcache']['port'] = 11211;

/**
 * Redis configuration
 */
$config['redis']['host'] = 'localhost';
$config['redis']['port'] = 6379;

/**
 * Super Administrators
 */
$config['super_admins'] = '1';

/**
 * Automatic Log Pruning
 */
$config['log_pruning'] = array(
        'admin_logs' => 365,
        'mod_logs' => 365,
        'task_logs' => 30,
        'mail_logs' => 180,
        'user_mail_logs' => 180,
        'promotion_logs' => 180
);

/**
 * Disallowed Remote Hosts
 */
$config['disallowed_remote_hosts'] = array(
        'localhost',
);

/**
 * Disallowed Remote Addresses
 */
$config['disallowed_remote_addresses'] = array(
        '0.0.0.0',
        '127.0.0.0/8',
        '10.0.0.0/8',
        '172.16.0.0/12',
        '192.168.0.0/16',
);
